@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo [GraphWay EDU] Python virtual environment setup...
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 -m venv .venv
) else (
  python -m venv .venv
)
if not exist ".venv\Scripts\python.exe" (
  echo Could not create a Python environment. Install Python 3.10+ and retry.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
  echo Package installation failed. Please check your network connection.
  pause
  exit /b 1
)
echo.
echo Setup complete. Double-click run_windows.bat to start the app.
pause

"""Local web service and first-release data compatibility."""
import json
import re
import subprocess
import threading
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import pytest

from graphway.model import CampusGraph, Edge
from graphway.repository import GraphRepository
from graphway.sample_data import build_demo_graph
from graphway.server import create_server


def test_http_local_api(tmp_path):
    server,state=create_server(0,tmp_path/'campus.db')
    thread=threading.Thread(target=server.serve_forever,daemon=True)
    thread.start()
    base=f'http://127.0.0.1:{server.server_address[1]}'
    def get(path):return urlopen(base+path,timeout=3)
    def post(path,body):
        req=Request(base+path,data=json.dumps(body,ensure_ascii=False).encode(),headers={'Content-Type':'application/json'},method='POST')
        return urlopen(req,timeout=3)
    try:
        assert get('/').status==200
        assert b'GraphWay' in get('/').read()
        assert 'text/css' in get('/style.css').headers['Content-Type']
        assert 'text/javascript' in get('/app.js').headers['Content-Type']
        resp=json.load(get('/api/state'))
        assert len(resp['graph']['nodes'])==48
        route=json.load(post('/api/search',{'start':'A19','goal':'C1','algorithm':'Dijkstra'}))
        assert route['found'] and route['distance']>0
        assert route['steps'][0]['kind']=='init'
        update=json.load(post('/api/edit',{'action':'add_place','id':'G1','name':'새 장소','x':200,'y':200}))
        assert any(n['name']=='새 장소' for n in update['graph']['nodes'])
        assert b'G1' in get('/api/export').read()
        with pytest.raises(HTTPError) as invalid:
            post('/api/edit',{'action':'connect','source':'notfound','target':'G1','distance':2})
        assert invalid.value.code==400
        with pytest.raises(HTTPError) as missing:
            get('/../../etc/passwd')
        assert missing.value.code==404
    finally:
        server.shutdown();server.server_close();thread.join(timeout=4);state.repo.close()


def test_v1_unedited_map_migrates_but_custom_map_survives(tmp_path):
    legacy_path=Path(__file__).resolve().parents[1]/'graphway'/'resources'/'legacy_v1.json'
    legacy=CampusGraph.from_dict(json.loads(legacy_path.read_text(encoding='utf-8')))
    db=tmp_path/'legacy.db'
    repo=GraphRepository(db);repo.save(legacy);repo.close()
    server,state=create_server(0,db)
    assert state.graph.nodes['C1'].name=='도서관'
    server.server_close();state.repo.close()
    db2=tmp_path/'edited.db'
    repo=GraphRepository(db2)
    legacy.add_edge(Edge('A19','C1',99))
    repo.save(legacy);repo.close()
    server,state=create_server(0,db2)
    assert state.graph.nodes['C1'].name==legacy.nodes['C1'].name
    assert ('A19','C1') in state.graph.edges
    server.server_close();state.repo.close()


def test_user_interface_control_ids_and_js_syntax():
    root=Path(__file__).resolve().parents[1]/'graphway'/'web'
    page=(root/'index.html').read_text(encoding='utf-8')
    js=(root/'app.js').read_text(encoding='utf-8')
    ids=set(re.findall(r'\bid="([^"]+)"',page+js))
    referenced=set(re.findall(r"\$\('([a-zA-Z][a-zA-Z0-9]+)'\)",js))
    assert not (referenced-ids),referenced-ids
    assert 'GraphWay' in page
    assert '내 지도 파일로 저장' in page
    assert 'JSON 열기' not in page
    assert '메타' not in page
    assert 'https://www.scnu.ac.kr/images/web/engNew/sub/campus_map.jpg' in page
    command=subprocess.run(['node','--check',str(root/'app.js')],capture_output=True,text=True)
    assert command.returncode==0,command.stderr

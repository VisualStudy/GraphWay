"""GraphWay EDU 2.0: campus identifiers, algorithms and persistence."""
import json
import random
import sqlite3
from math import isclose
from concurrent.futures import ThreadPoolExecutor
import pytest
import networkx as nx
from graphway.algorithms import search, dijkstra, bfs, astar
from graphway.model import Node, Edge, CampusGraph
from graphway.repository import GraphRepository
from graphway.sample_data import build_demo_graph, SOURCE
from graphway.server import State


def test_official_building_names_and_layout():
    graph=build_demo_graph()
    assert len(graph.nodes)==48
    assert len(graph.edges)==77
    assert graph.nodes['A19'].name=='정문'
    assert graph.nodes['A18'].name=='열린광장'
    assert graph.nodes['A3'].name=='천연물의약소재개발연구센터'
    assert graph.nodes['C1'].name=='도서관'
    assert graph.nodes['D2'].name=='공과대학 1호관'
    assert graph.nodes['E1'].name=='학생회관'
    assert SOURCE.startswith('https://www.scnu.ac.kr/')
    assert graph.nodes['A19'].y>graph.nodes['E1'].y
    assert graph.nodes['C1'].x>graph.nodes['A19'].x


def test_graph_dijkstra_astar_consistency():
    graph=build_demo_graph()
    for start,goal in [('A19','C1'),('A19','E1'),('F1','D4'),('B1','E8'),('A10','C3')]:
        a=astar(graph,start,goal)
        d=dijkstra(graph,start,goal)
        assert a.distance==d.distance
        assert graph.path_distance(a.path)==a.distance
        assert a.steps[0].kind=='init' and a.steps[-1].kind=='done'
        assert d.visit_order[0]==start
    assert dijkstra(graph,'A19','C1').found


def test_bfs_minimizes_hops_not_weight():
    g=CampusGraph([Node('A','출발',0,0),Node('B','중간',1,0),Node('C','도착',2,0)],
        [Edge('A','B',1),Edge('B','C',1),Edge('A','C',100)])
    assert dijkstra(g,'A','C').path==('A','B','C')
    assert bfs(g,'A','C').path==('A','C')
    assert astar(g,'A','C').distance==2


def test_unreachable_same_node():
    g=CampusGraph([Node('A','한',1,1),Node('B','두',10,10)],[])
    for fn in (dijkstra,bfs,astar):
        assert not fn(g,'A','B').found
        same=fn(g,'A','A')
        assert same.found and same.path==('A',) and same.distance==0
    with pytest.raises(ValueError): search(g,'nothing','A')
    with pytest.raises(ValueError): search(g,'A','B','nonsense')


def test_reject_invalid_nodes_edges():
    for val in [0,-1,float('inf'),float('nan')]:
        with pytest.raises(ValueError):Edge('A','B',val)
    with pytest.raises(ValueError):Edge('A','A',1)


def test_json_round_trip_invalid_records():
    g=build_demo_graph()
    new=CampusGraph.from_dict(json.loads(json.dumps(g.to_dict(),ensure_ascii=False)))
    assert new.nodes==g.nodes
    assert new.edges==g.edges
    with pytest.raises(ValueError):CampusGraph.from_dict({'nodes':[],'edges':[{'source':'A','target':'B','distance':50}]})
    with pytest.raises(ValueError):CampusGraph.from_dict({'nodes':[{'id':'X','name':'점','x':0,'y':0}]*2,'edges':[]})


def test_sqlite_survives_restart_and_foreign_keys(tmp_path):
    path=tmp_path/'sample.db'
    repo=GraphRepository(path)
    g=repo.load()
    assert len(g.nodes)==48
    g.add_node(Node('Z1','새로운 지점',410,320,'Z'))
    g.add_edge(Edge('Z1','A19',22))
    repo.save(g)
    assert repo.conn.execute('PRAGMA foreign_keys').fetchone()[0]==1
    with pytest.raises(sqlite3.IntegrityError):
        with repo.conn:repo.conn.execute("INSERT INTO edges VALUES ('AAA','ZZZ',44)")
    repo.close()
    repo=GraphRepository(path)
    persisted=repo.load()
    assert persisted.nodes['Z1'].name=='새로운 지점'
    assert persisted.edges[('A19','Z1')].distance==22
    persisted.remove_node('Z1')
    repo.save(persisted)
    assert all('Z1' not in key for key in repo.load().edges)
    repo.close()


def test_graphway_service_edit_save_import(tmp_path):
    state=State(tmp_path/'campus.db')
    assert state.do_search({'start':'A19','goal':'C1'})['found']
    assert state.do_search({'start':'A19','goal':'C1'})['distance']>0
    state.mutate({'action':'add_place','id':'G1','name':'음악관','x':400,'y':510})
    state.mutate({'action':'connect','source':'G1','target':'A19','distance':60})
    assert state.do_search({'start':'G1','goal':'A19'})['distance']==60
    state.mutate({'action':'rename_place','id':'G1','name':'음악 연습실'})
    state.mutate({'action':'move_place','id':'G1','x':301,'y':401})
    assert state.graph.nodes['G1'].x==301
    with pytest.raises(ValueError):state.mutate({'action':'connect','source':'G1','target':'G1','distance':5})
    exported=state.graph.to_dict()
    state.mutate({'action':'delete_place','id':'G1'})
    assert 'G1' not in state.graph.nodes
    state.mutate({'action':'import','graph':exported})
    assert state.graph.nodes['G1'].name=='음악 연습실'
    state.repo.close()
    state=State(tmp_path/'campus.db')
    assert state.graph.nodes['G1'].name=='음악 연습실'
    state.mutate({'action':'reset'})
    assert 'G1' not in state.graph.nodes
    state.repo.close()


def test_networkx_25_random_graphs():
    rng=random.Random(42)
    for _ in range(25):
        nodes=[Node(str(i),f'정점{i}',rng.uniform(0,1000),rng.uniform(0,800)) for i in range(14)]
        edges=[Edge(str(i-1),str(i),rng.randint(1,200)) for i in range(1,14)]
        used={tuple(sorted((e.source,e.target))) for e in edges}
        for _ in range(26):
            i,j=rng.sample(range(14),2);key=tuple(sorted((str(i),str(j))))
            if key not in used:
                edges.append(Edge(str(i),str(j),rng.randint(1,200)))
                used.add(key)
        g=CampusGraph(nodes,edges)
        ref=nx.Graph();ref.add_weighted_edges_from((e.source,e.target,e.distance) for e in edges)
        for _ in range(5):
            a,b=map(str,rng.sample(range(14),2))
            optimal=nx.shortest_path_length(ref,a,b,weight='weight')
            assert isclose(dijkstra(g,a,b).distance,optimal)
            assert isclose(astar(g,a,b).distance,optimal)

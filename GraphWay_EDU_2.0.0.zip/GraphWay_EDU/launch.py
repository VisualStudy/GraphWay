"""Windows / macOS / Linux GraphWay launcher."""
from graphway.server import main

if __name__=='__main__':
    main()

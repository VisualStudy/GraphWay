"""Sunchon National University place names and teaching graph.

Building identifiers/names: Sunchon National University official campus map.
Layout coordinates: hand-transcribed relative positions from the official campus
illustration; they are *not* latitude/longitude or surveyed building entrances.
Edges and weights: illustrative campus connections, *not* surveyed paths.
"""
from math import hypot
from .model import CampusGraph, Node, Edge

SOURCE = 'https://www.scnu.ac.kr/neweng/cm/cntnts/cntntsView.do?cntntsId=4400&mi=7473'
OFFICIAL_MAP = 'https://www.scnu.ac.kr/campusmap.jsp'

# Official building IDs and names are retained as printed by the university.
# Plan coordinates follow the official illustrated campus layout (south at bottom).
PLACES = {
    'A1':('대학본부',620,338), 'A2':('약학대학',533,362),
    'A3':('천연물의약소재개발연구센터',544,288),
    'A4':('학생생활관 부속동',428,278), 'A5':('진리관',350,307),
    'A6':('창조관',349,185), 'A7':('학생생활관 관리동',379,250),
    'A8':('향림관',284,251), 'A9':('청운관',273,187),
    'A10':('인재관',328,194), 'A11':('제2중앙공급실',351,159),
    'A12':('우정원',315,140), 'A13':('웅지관',236,347),
    'A14':('남문',215,355), 'A15':('운동장',364,428),
    'A16':('교직원 테니스장',235,537), 'A17':('체육관',259,569),
    'A18':('열린광장',277,578), 'A19':('정문',438,677),
    'B1':('박물관',571,589), 'B2':('70주년기념관',600,483),
    'B3':('생명산업과학대학 1호관',712,557),
    'B4':('생명산업과학대학 2호관',693,409),
    'B5':('생명산업과학대학 온실',745,497),
    'B6':('제1중앙공급실',782,415),
    'B7':('원예학과 온실',854,636),
    'C1':('도서관',789,283), 'C2':('친환경농업센터',815,356),
    'C3':('공동실험실습관',865,278),
    'C4':('친환경물질공장 기술혁신센터',853,367),
    'C5':('국립순천대학교 어린이집',916,375), 'C6':('북문',912,325),
    'D1':('창업보육센터',864,253), 'D2':('공과대학 1호관',908,193),
    'D3':('공과대학 2호관',787,135), 'D4':('공과대학 3호관',814,87),
    'E1':('학생회관',608,237), 'E2':('기초교육관',517,162),
    'E3':('사범대학 1호관',709,175), 'E4':('사범대학 2호관',732,176),
    'E5':('사범대학 3호관',609,129),
    'E6':('미래창조관',421,94), 'E7':('사회과학대학',536,54),
    'E8':('인문예술대학',654,68),
    'F1':('국제문화컨벤션관',48,451), 'F2':('평생교육원',113,501),
    'F3':('학생 테니스장',136,451), 'F4':('교직원 관사',112,403),
}

# Edges follow groupings and corridors visible in the university campus
# illustration. They do not make claims about accessibility or surveyed metres.
LINKS = '''
A19 A18; A19 B1; A18 A17; A18 A16; A18 A15; A18 F2;
A17 A15; A15 A13; A15 A2; A15 A3; A15 A1; A15 B2;
A13 A14; A13 A5; A14 F4; A14 F3; F4 F1; F1 F2; F2 F3;
A5 A8; A5 A4; A5 A7; A4 A3; A4 A7; A7 A8; A7 A6;
A8 A9; A9 A10; A10 A11; A10 A6; A11 A12; A12 E6;
A6 E6; E6 E7; E7 E8; E7 E2; E8 E5; E5 E2;
E5 E3; E3 E4; E4 E1; E2 E1; E2 A3; E1 A3;
E1 A1; E1 C1; E1 B4; A3 A2; A2 A1; A1 B2;
B1 B2; B1 B3; B2 B4; B2 B3; B4 B5; B4 B6;
B5 B3; B5 B7; B6 C2; B4 C2; B4 C1;
C1 C2; C1 C3; C1 D1; C2 C4; C3 C4; C3 D1;
C4 C5; C5 C6; C3 C6; D1 D2; D1 D3; D2 D3;
D3 D4; E4 D3; E3 D3; F3 A13
'''


def build_demo_graph() -> CampusGraph:
    nodes = [Node(code,name,float(x),float(y),code[0]) for code,(name,x,y) in PLACES.items()]
    # Distance cost scaled from the relative campus diagram. Deliberately
    # marked approximate throughout the interface; not actual walking data.
    edges=[]
    seen=set()
    for item in LINKS.replace('\n',' ').split(';'):
        parts=item.split()
        if not parts: continue
        if len(parts)!=2 or parts[0] not in PLACES or parts[1] not in PLACES:
            raise ValueError('캠퍼스 연결 설정 오류: '+item)
        a,b=parts
        key=tuple(sorted((a,b)))
        if key in seen:continue
        seen.add(key)
        ax,ay=PLACES[a][1:];bx,by=PLACES[b][1:]
        # A consistent educational cost scale, not metres from navigation.
        cost=max(10,round(hypot(ax-bx,ay-by)*1.1/5)*5)
        edges.append(Edge(a,b,float(cost)))
    return CampusGraph(nodes,edges)

"""Reproducible, step-by-step graph algorithms for discrete mathematics classes."""
from collections import deque
from heapq import heappush, heappop
from math import inf, hypot
from .model import CampusGraph, RouteResult, SearchStep


def _path(prev: dict[str, str], start: str, goal: str) -> tuple[str, ...]:
    if goal == start:
        return (start,)
    if goal not in prev:
        return ()
    out = [goal]
    while out[-1] != start:
        out.append(prev[out[-1]])
    return tuple(reversed(out))


def dijkstra(graph: CampusGraph, start: str, goal: str) -> RouteResult:
    _check(graph, start, goal)
    distances = {n: inf for n in graph.nodes}
    distances[start] = 0.0
    prev = {}
    queue = [(0.0, start)]
    visited = set()
    order = []
    steps = [SearchStep(None, (), (start,), {start: 0.0}, f"시작 정점 {start}의 거리를 0으로 설정합니다.", 'init')]
    while queue:
        d, u = heappop(queue)
        if u in visited or d > distances[u]:
            continue
        visited.add(u)
        order.append(u)
        steps.append(SearchStep(u, tuple(order), tuple(sorted({v for _, v in queue if v not in visited})), dict(distances), f"정점 {u} 확정: 시작점에서 {d:g} m", 'visit'))
        if u == goal:
            break
        improved = []
        for v, weight in graph.neighbors(u):
            if v in visited:
                continue
            nd = d + weight
            if nd < distances[v]:
                distances[v] = nd
                prev[v] = u
                improved.append(v)
                heappush(queue, (nd, v))
                steps.append(SearchStep(u, tuple(order), tuple(sorted({x for _, x in queue if x not in visited})), dict(distances), f"간선 {u} → {v}: {d:g} + {weight:g} = {nd:g} m로 거리 갱신", 'relax', (v,)))
    path = _path(prev, start, goal) if goal in visited else ()
    distance = graph.path_distance(path) if path else None
    steps.append(SearchStep(goal if path else None, tuple(order), (), dict(distances), f"최단경로 발견: {' → '.join(path)} ({distance:g} m)" if path else "도달할 수 있는 경로가 없습니다.", 'done'))
    return RouteResult('Dijkstra', start, goal, path, distance, tuple(steps), tuple(order))


def bfs(graph: CampusGraph, start: str, goal: str) -> RouteResult:
    """Minimizes edge count, NOT weighted distance. Important educational distinction."""
    _check(graph, start, goal)
    queue = deque([start])
    discovered = {start}
    prev = {}
    order = []
    steps = [SearchStep(None, (), (start,), {start: 0}, f"BFS 큐에 {start} 삽입 (간선 수가 기준).", 'init')]
    hop = {start: 0}
    while queue:
        u = queue.popleft()
        order.append(u)
        steps.append(SearchStep(u, tuple(order), tuple(queue), dict(hop), f"큐에서 {u} 꺼냄: {hop[u]}개 간선 통과", 'visit'))
        if u == goal:
            break
        for v, _ in graph.neighbors(u):
            if v not in discovered:
                discovered.add(v)
                prev[v] = u
                hop[v] = hop[u] + 1
                queue.append(v)
                steps.append(SearchStep(u, tuple(order), tuple(queue), dict(hop), f"이웃 정점 {v}를 큐에 추가 (간선 {hop[v]}개)", 'relax', (v,)))
    path = _path(prev, start, goal) if goal in order else ()
    distance = graph.path_distance(path) if path else None
    steps.append(SearchStep(goal if path else None, tuple(order), (), dict(hop), f"최소 간선 수 경로: {' → '.join(path)} / 학습용 거리 합계 {distance:g}" if path else "도달 가능한 경로가 없습니다.", 'done'))
    return RouteResult('BFS', start, goal, path, distance, tuple(steps), tuple(order))


def astar(graph: CampusGraph, start: str, goal: str) -> RouteResult:
    """Optimal A* with an automatically admissible geometric lower bound.

    The campus coordinates are a schematic. We derive a conservative
    distance-per-layout-unit factor from the currently edited edges:
       k = min(weight(u,v) / Euclidean(u,v)).
    Then h(n) = k * Euclidean(n, goal) is admissible and consistent for
    any nonnegative editable weights and positions. If all edges have zero
    layout length, h is zero (the safe Dijkstra fallback).
    """
    _check(graph, start, goal)
    ratios = []
    for e in graph.edges.values():
        a, b = graph.nodes[e.source], graph.nodes[e.target]
        graphical_length = hypot(a.x-b.x, a.y-b.y)
        if graphical_length > 0:
            ratios.append(e.distance / graphical_length)
    meter_per_unit = min(ratios, default=0.0)
    goal_node = graph.nodes[goal]
    def h(node_id):
        n = graph.nodes[node_id]
        return meter_per_unit * hypot(n.x-goal_node.x, n.y-goal_node.y)

    dist = {start: 0.0}
    prev = {}
    queue = [(h(start), start)]
    visited = set()
    order = []
    steps = [SearchStep(None, (), (start,), dict(dist), f"A* 시작: 보수적 거리 휴리스틱 h(n)={meter_per_unit:.3f} × 직선거리", 'init')]
    while queue:
        _, u = heappop(queue)
        if u in visited:
            continue
        visited.add(u)
        order.append(u)
        steps.append(SearchStep(u, tuple(order), tuple(sorted({v for _, v in queue if v not in visited})), dict(dist), f"정점 {u} 선택: g={dist[u]:g}, h={h(u):.1f}, f={dist[u]+h(u):.1f}", 'visit'))
        if u == goal:
            break
        for v, w in graph.neighbors(u):
            candidate = dist[u] + w
            if candidate < dist.get(v, inf):
                dist[v] = candidate
                prev[v] = u
                heappush(queue, (candidate+h(v), v))
                steps.append(SearchStep(u, tuple(order), tuple(sorted({x for _, x in queue if x not in visited})), dict(dist), f"{v}: g={candidate:g}, h={h(v):.1f}, f={candidate+h(v):.1f}로 갱신", 'relax', (v,)))
    path = _path(prev, start, goal) if goal in visited else ()
    total = graph.path_distance(path) if path else None
    steps.append(SearchStep(goal if path else None, tuple(order), (), dict(dist), f"A* 최단경로: {' → '.join(path)} ({total:g} m)" if path else "도달할 수 없습니다.", 'done'))
    return RouteResult('A*', start, goal, path, total, tuple(steps), tuple(order))


def search(graph: CampusGraph, start: str, goal: str, algorithm: str = 'Dijkstra') -> RouteResult:
    if algorithm == 'Dijkstra':
        return dijkstra(graph, start, goal)
    if algorithm == 'BFS':
        return bfs(graph, start, goal)
    if algorithm == 'A*':
        return astar(graph, start, goal)
    raise ValueError('알 수 없는 알고리즘: ' + algorithm)


def _check(graph: CampusGraph, start: str, goal: str) -> None:
    if start not in graph.nodes or goal not in graph.nodes:
        raise ValueError("출발지와 도착지는 존재하는 정점이어야 합니다.")

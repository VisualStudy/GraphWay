'use strict';
const $ = id => document.getElementById(id);
const NS = 'http://www.w3.org/2000/svg';
const ZONES = {A:'중앙 · 운동장 · 생활관',B:'정문 동쪽 · 생명과학',C:'도서관 · 북문',D:'공과대학',E:'학생회관 · 사범대학',F:'서쪽 · 체육시설'};
const COLORS = {A:'#2d72c4',B:'#9a69b0',C:'#187f8c',D:'#d7786c',E:'#c58b45',F:'#7f996c'};
const DESCRIPTIONS = {
  'Dijkstra':'길마다 이동 거리를 더해 가장 짧은 경로를 찾습니다.',
  'A*':'목적지까지의 남은 거리를 추정해 탐색 순서를 결정합니다.',
  'BFS':'방문하는 길의 개수가 가장 적은 경로를 찾습니다. 가장 짧은 거리는 아닐 수 있습니다.'
};
const $S = (tag,attrs={},parent=null,text=null)=>{const e=document.createElementNS(NS,tag);for(const [k,v] of Object.entries(attrs))e.setAttribute(k,String(v));if(text!==null)e.textContent=text;if(parent)parent.appendChild(e);return e};
const esc = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const state={graph:null,result:null,mode:'map',step:-1,selected:null,picked:null,zoom:{x:0,y:0,w:1000,h:760},drag:null,moveMode:false,play:null,modalTab:'places',toast:null};
function n(id){return state.graph?.nodes.find(p=>p.id===id)}
function neighbors(id){return state.graph?.edges.filter(e=>e.source===id||e.target===id)||[]}
function fmt(d){return Number.isFinite(d)? Math.round(d).toLocaleString('ko-KR'):'—'}
function errText(error){return error?.message||'요청을 완료하지 못했습니다.'}
async function api(path,payload){const resp=await fetch(path,payload?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}:{});const data=await resp.json();if(!resp.ok)throw new Error(data.error||'처리하지 못했습니다.');return data}
function toast(text){$('toast').textContent=text;$('toast').classList.remove('hidden');clearTimeout(state.toast);state.toast=setTimeout(()=>$('toast').classList.add('hidden'),3700)}
function sortNodes(){return [...(state.graph?.nodes||[])].sort((a,b)=>a.id.localeCompare(b.id,'en',{numeric:true}))}
function nodeOpts(){return sortNodes().map(p=>`<option value="${esc(p.id)}">${esc(p.name)} (${esc(p.id)})</option>`).join('')}
function setupChoices(start,goal){const options=Object.entries(ZONES).map(([z,label])=>`<optgroup label="${esc(label)}">${sortNodes().filter(p=>p.zone===z).map(p=>`<option value="${esc(p.id)}">${esc(p.name)} · ${esc(p.id)}</option>`).join('')}</optgroup>`).join('')+sortNodes().filter(p=>!ZONES[p.zone]).map(p=>`<option value="${esc(p.id)}">${esc(p.name)} · ${esc(p.id)}</option>`).join('');
 const a=$('startSelect'),b=$('goalSelect');a.innerHTML=options;b.innerHTML=options;a.value=start||a.options[0]?.value||'';b.value=goal||b.options[0]?.value||'';}
function showPlaces(){const q=$('placeSearch').value.trim().toLocaleLowerCase();const places=sortNodes().filter(p=>(p.name+' '+p.id).toLocaleLowerCase().includes(q));
 $('placeResults').innerHTML=places.length? places.slice(0,50).map(p=>`<button class="placeItem ${state.selected===p.id?'selected':''}" data-id="${esc(p.id)}"><span class="placeIcon">${esc(p.id)}</span><span><strong>${esc(p.name)}</strong><small>${esc(ZONES[p.zone]||'캠퍼스 장소')}</small></span></button>`).join(''):'<p class="miniInfo">일치하는 장소가 없습니다.</p>';
 document.querySelectorAll('.placeItem').forEach(btn=>btn.onclick=()=>selectPlace(btn.dataset.id,true));}
function setMode(mode){state.mode=mode;for(const [id,m] of [['mapTab','map'],['graphTab','graph'],['officialTab','official']]){const active=m===mode;$(id).classList.toggle('active',active);$(id).setAttribute('aria-selected',String(active))}
 $('officialMapPanel').classList.toggle('hidden',mode!=='official');$('mapSvg').classList.toggle('hidden',mode==='official');$('mapLegend').classList.toggle('hidden',mode==='official');$('mapBanner').classList.toggle('hidden',mode==='official');$('placePopover').classList.add('hidden');
 $('zoomInBtn').disabled=$('zoomOutBtn').disabled=$('fitBtn').disabled=mode==='official';
 $('bannerTitle').textContent=mode==='graph'?'그래프 탐색 구조':'캠퍼스 길찾기';$('bannerSub').textContent=mode==='graph'?'정점 · 간선 · 가중치 시각화':'건물을 클릭하면 출발지나 도착지로 지정할 수 있습니다.';
 draw();}
function svgView(){const v=state.zoom;$('mapSvg').setAttribute('viewBox',`${v.x} ${v.y} ${v.w} ${v.h}`)}
function zoom(f,origin=null){const v=state.zoom,px=origin?.x??v.x+v.w/2,py=origin?.y??v.y+v.h/2;const nw=Math.min(1400,Math.max(195,v.w*f)),nh=nw*.76;
 v.x=px-(px-v.x)*nw/v.w;v.y=py-(py-v.y)*nh/v.h;v.w=nw;v.h=nh;svgView();}
function fit(){state.zoom={x:0,y:0,w:1000,h:760};svgView()}
function mouseCoords(evt){const p=$('mapSvg').createSVGPoint();p.x=evt.clientX;p.y=evt.clientY;return p.matrixTransform($('mapSvg').getScreenCTM().inverse())}
function background(g){const gr=state.mode==='graph';
 $S('rect',{x:0,y:0,width:1000,height:760,fill:gr?'#f8fbff':'#e5f0e7'},g);
 if(gr){$S('rect',{x:0,y:0,width:1000,height:760,fill:'url(#gridpattern)'},g);$S('text',{x:50,y:703,class:'zoneLabel','font-size':25},g,'GRAPH THEORY · VERTEX / EDGE / WEIGHT');return}
 const parks=[['M0 0H1000V70Q910 75 840 110L790 10H0Z','#d8ead7'],['M0 230Q100 220 160 300L200 430L0 480Z','#cde6cc'],['M760 470Q845 395 1000 450V760H750Z','#d3e8d1'],['M0 685Q160 610 235 675L350 760H0Z','#d5e7d4']];parks.forEach(([d,c])=>$S('path',{d,fill:c},g));
 // Campus street network follows the orientation of the official 3D campus plan.
 const paths=['M0 652 L225 648 L435 690 L540 690 L750 590 L1000 700',
 'M0 420 L170 412 L300 370 L452 430 L625 435 L783 480 L970 532',
 'M155 0 L220 100 L305 175 L410 245 L536 320 L680 335 L840 345 L1000 365',
 'M0 260 L150 245 L270 255 L396 303 L540 350 L680 345',
 'M440 0 L490 85 L535 155 L590 240 L650 360 L695 480 L720 640',
 'M800 0 L750 150 L810 275 L905 325 L1000 320',
 'M275 350 L290 445 L280 560 L435 690',
 'M130 425 L120 500 L215 600 L280 560',
 'M420 240 L420 325 L400 435 L470 540',
 'M665 70 L705 180 L715 290 L770 405'];
 paths.forEach(d=>{$S('path',{d,class:'mapRoadEdge'},g);$S('path',{d,class:'mapRoad'},g)});
 // Campus running track is the main orientation landmark.
 $S('ellipse',{cx:377,cy:485,rx:146,ry:85,fill:'#e6a983',stroke:'#fff1d9','stroke-width':3,transform:'rotate(14 377 485)'},g);
 $S('ellipse',{cx:377,cy:485,rx:119,ry:63,fill:'#8bcaa3',stroke:'#fffaf0','stroke-width':3,transform:'rotate(14 377 485)'},g);
 $S('path',{d:'M262 467L490 507M368 424L380 549',stroke:'#d2ecdc','stroke-width':2},g);
 $S('circle',{cx:378,cy:484,r:22,fill:'none',stroke:'#e5f5eb','stroke-width':2},g);
 $S('rect',{x:60,y:290,width:150,height:62,rx:9,fill:'#d8e6dd',stroke:'#b5ccbc','stroke-width':3},g);
 $S('text',{x:72,y:327,class:'footprintLabels'},g,'캠퍼스 서쪽 출입구');
 // Approximate buildings are not the embedded official illustration; these
 // footprints are a simplified location-index layer used for teaching.
 for(const p of state.graph.nodes){if(p.id.startsWith('A1') && ['A15','A16','A17','A18','A19','A14'].includes(p.id))continue;
   if(['A15','A16','A17','A18','A19','A14','C6'].includes(p.id))continue;
   const width=p.zone==='D'?64:p.zone==='B'?64: p.zone==='E'?65:58;
   const height=p.zone==='D'?40:p.zone==='E'?34:40;
   const cls=p.zone==='A'?'buildingDorm':p.zone==='B'?'buildingOther':'buildingAcademic';
   const rect=$S('rect',{x:p.x-width/2-6,y:p.y-height/2-7,width,height,rx:7,class:`building ${cls}`,transform:`rotate(-9 ${p.x} ${p.y})`,opacity:.92},g);
   rect.setAttribute('pointer-events','none');}
 $S('text',{x:316,y:484,fill:'#fff',opacity:.7,'font-size':18,'font-weight':800},g,'운 동 장');
 $S('text',{x:370,y:727,fill:'#6e9884','font-size':12,'font-weight':750},g,'중앙로 · 정문');
}
function draw(){if(!state.graph||state.mode==='official')return;const root=$('scene');root.replaceChildren();background(root);
 const graph=state.graph;const result=state.result;const step=result?.steps?.[state.step]||null;
 const visited=new Set(step?.visited||[]),frontier=new Set(step?.frontier||[]),relaxed=new Set(step?.relaxed||[]);
 const path=result?.found&&(state.mode==='map'||step?.kind==='done')&&result?.path||[];const pathSet=new Set(path.slice(1).map((id,i)=>[path[i],id].sort().join('|')));
 const edgeLayer=$S('g',{},root);
 for(const e of graph.edges){const a=n(e.source),b=n(e.target);if(!a||!b)continue;
 const isRoute=pathSet.has([e.source,e.target].sort().join('|'));
 const isExploring=state.mode==='graph'&&step&&relaxed.has(e.target)&&step.current===e.source;
 if(state.mode==='graph'){
  $S('line',{x1:a.x,y1:a.y,x2:b.x,y2:b.y,class:isExploring?'exploreEdge':'outlineGraph',stroke: isRoute?'#7baade':'#b6c8da','stroke-width':isRoute?3.5:1.8},edgeLayer);
  const dx=b.x-a.x,dy=b.y-a.y; if(Math.hypot(dx,dy)>50 && state.zoom.w<1150)$S('text',{x:(a.x+b.x)/2+dy/15,y:(a.y+b.y)/2-dx/15,'text-anchor':'middle',class:'distanceText'},edgeLayer,fmt(e.distance));
 }else if(isRoute){$S('line',{x1:a.x,y1:a.y,x2:b.x,y2:b.y,stroke:'#c6dffb','stroke-width':6,'stroke-linecap':'round',opacity:.6},edgeLayer)}
 }
 if(result?.found && path.length>1){const points=path.map(id=>{const p=n(id);return `${p.x},${p.y}`}).join(' ');
   $S('polyline',{points,class:'routeGlow'},root);$S('polyline',{points,class:'routeMain'},root)}
 const pinLayer=$S('g',{},root);const started=$('startSelect').value,goal=$('goalSelect').value;
 for(const p of graph.nodes){const core= p.id===started?'#297bcf':p.id===goal?'#e36d6a':COLORS[p.zone]||'#638599';
  const isStart=p.id===started,isGoal=p.id===goal,isCurrent=step?.current===p.id,isSelected=state.selected===p.id;
  let fill=state.mode==='graph'?'#fff':'#ffffff';let stroke=core,r=state.mode==='graph'?8:7;
  if(state.mode==='graph'&&visited.has(p.id)){fill='#2ba788';stroke='#2ba788'}
  if(state.mode==='graph'&&frontier.has(p.id)){fill='#efad48';stroke='#efad48'}
  if(isCurrent){fill='#267ce3';stroke='#267ce3';r=12}
  if(isStart||isGoal){fill=core;stroke='#fff';r=11}
  if(isSelected){$S('circle',{cx:p.x,cy:p.y,r:21,fill:'#81c5ff',opacity:.42},pinLayer);}
  const g=$S('g',{class:'point','data-id':p.id,role:'button',tabindex:'0','aria-label':`${p.name} ${p.id}`},pinLayer);
  $S('circle',{cx:p.x,cy:p.y,r:r+5,fill:'transparent'},g);
  $S('circle',{cx:p.x,cy:p.y,r,fill,stroke,'stroke-width':2.8,class:'pinCore'},g);
  if((isStart||isGoal)&&state.mode==='map')$S('circle',{cx:p.x,cy:p.y,r:3,fill:'white'},g);
  const alwaysLabel=['A19','A18','A15','C1','D2','E1','A1','A2','B1','E3','E7'].includes(p.id);
  if(state.mode==='graph'||alwaysLabel||isSelected||path.includes(p.id)){
   const label=$S('text',{x:p.x+10,y:p.y-12,class:'pinLabel',fill:isCurrent?'#1666c1':core},g, state.mode==='map'&&((isStart||isGoal)||isSelected)?p.name:p.id);
   const ratio=state.zoom.w/Math.max(360,$('mapSvg').getBoundingClientRect().width);
   label.style.fontSize=`${Math.min(25,Math.max(13,13*ratio))}px`;
  }
  $S('title',{},g,`${p.name} · ${p.id}`);
  g.addEventListener('click',evt=>{evt.stopPropagation();selectPlace(p.id,false)});
  g.addEventListener('keydown',evt=>{if(['Enter',' '].includes(evt.key)){evt.preventDefault();selectPlace(p.id,false)}});
 }
 if(state.mode==='graph'){
   $S('text',{x:22,y:731,fill:'#849caf','font-size':13,'font-weight':700},root,`정점 ${graph.nodes.length}개 · 간선 ${graph.edges.length}개 · 가중치: 이동 비용`);
 }
 $('graphSummary').textContent=`${graph.nodes.length}개 장소 · ${graph.edges.length}개 연결 구간` +(state.mode==='graph'?' · 각 숫자는 이동 비용입니다.':' · 건물 배치는 국립순천대학교 안내도 기준');
}
function centerOn(p){if(!p)return;const v=state.zoom;const ww=Math.min(650,v.w);v.x=p.x-ww/2;v.y=p.y-ww*.76/2;v.w=ww;v.h=ww*.76;svgView()}
function selectPlace(id,center){const p=n(id);if(!p)return;state.selected=id;if(center){setMode('map');centerOn(p)}draw();showPlaces();
 state.picked=id;$('popName').textContent=p.name;$('popCode').textContent=`${p.id} · ${ZONES[p.zone]||'캠퍼스'}`;
 const pos=p;const rect=$('mapFrame').getBoundingClientRect();
 const point=$('mapSvg').createSVGPoint();point.x=pos.x;point.y=pos.y;
 const clientPoint=point.matrixTransform($('mapSvg').getScreenCTM());
 const px=clientPoint.x-rect.left,py=clientPoint.y-rect.top;
 $('placePopover').style.left=`${Math.min(Math.max(10,px+12),Math.max(10,rect.width-272))}px`;
 $('placePopover').style.top=`${Math.min(Math.max(8,py-70),Math.max(8,rect.height-165))}px`;
 $('placePopover').classList.remove('hidden');}
function clearSelected(){state.selected=null;$('placePopover').classList.add('hidden');draw();showPlaces()}
function bindCanvas(){const svg=$('mapSvg');
 svg.addEventListener('wheel',evt=>{if(state.mode==='official')return;evt.preventDefault();const at=mouseCoords(evt);zoom(evt.deltaY>0?1.11:.9,at)},{passive:false});
 svg.addEventListener('pointerdown',evt=>{if(evt.button!==0)return;const target=evt.target.closest?.('[data-id]');if(target && !state.moveMode){state.drag=null;return}if(state.moveMode && target){state.drag={kind:'node',id:target.dataset.id};}
 else{state.drag={kind:'pan',start:mouseCoords(evt)};svg.style.cursor='grabbing';}
 try{svg.setPointerCapture(evt.pointerId)}catch{}});
 svg.addEventListener('pointermove',evt=>{if(!state.drag)return;const p=mouseCoords(evt);if(state.drag.kind==='pan'){const v=state.zoom,prev=state.drag.start;v.x+=prev.x-p.x;v.y+=prev.y-p.y;svgView();}
 else if(state.moveMode){const pnt=n(state.drag.id);if(!pnt)return;pnt.x=Math.max(0,Math.min(1000,p.x));pnt.y=Math.max(0,Math.min(760,p.y));draw();}});
 svg.addEventListener('pointerup',async()=>{svg.style.cursor='grab';if(state.drag?.kind==='node'){const p=n(state.drag.id);try{await edit({action:'move_place',id:p.id,x:p.x,y:p.y},false)}catch(e){toast(errText(e))}}state.drag=null});
 svg.addEventListener('click',evt=>{if(!evt.target.closest?.('[data-id]'))$('placePopover').classList.add('hidden')});
}
async function calculate(){stop();const start=$('startSelect').value,goal=$('goalSelect').value,algorithm=$('algoSelect').value;
 if(!start||!goal){toast('출발지와 도착지를 선택하세요.');return}
 $('searchBtn').disabled=true;$('searchBtn').textContent='길을 찾고 있습니다…';
 try{state.result=await api('/api/search',{start,goal,algorithm});state.step=state.result.steps.length-1;renderResult();renderStep();draw();if(!state.result.found)toast('두 장소를 연결하는 경로가 없습니다.');}
 catch(e){toast(errText(e))}finally{$('searchBtn').disabled=false;$('searchBtn').innerHTML='<span>⌕</span> 경로 찾기'}
}
function renderResult(){const r=state.result;$('emptyResult').classList.toggle('hidden',!!r?.found);$('resultDetails').classList.toggle('hidden',!r?.found);if(!r?.found){$('emptyResult').textContent=r?'현재 연결된 길에서는 목적지까지 이동할 수 없습니다.':'출발지와 도착지를 선택해 경로를 찾아보세요.';return;}
 $('resultDistance').textContent=fmt(r.distance);$('resultTime').textContent=`약 ${Math.max(1,Math.ceil(r.distance/70))}분`;$('resultCount').textContent=`${r.path.length}곳`;
 $('routeChips').innerHTML=r.path.map((id,i)=>`<span class="routeChip" title="${esc(n(id)?.name||id)}">${esc(n(id)?.name||id)}</span>${i<r.path.length-1?'<span class="routeArrow">›</span>':''}`).join('');
 $('resultNote').textContent=r.algorithm==='BFS'?'너비 우선 탐색은 간선 수를 최소화합니다. 표시된 이동 거리가 최단 거리는 아닐 수 있습니다.': '이동 거리는 학습용 추정값입니다. 실제 보행 경로는 학교 공식 지도에서 확인하세요.';
}
function renderStep(){const r=state.result;if(!r){$('stepCounter').textContent='0 / 0 단계';$('visitedCounter').textContent='방문 0곳';$('stepText').textContent='경로를 찾으면 탐색 과정이 차례대로 표시됩니다.';$('progressFill').style.width='0%';return}
 const s=r.steps[state.step];$('stepCounter').textContent=`${state.step+1} / ${r.steps.length} 단계`;$('visitedCounter').textContent=`방문 ${s.visited.length}곳`;
 $('progressFill').style.width=`${(state.step+1)/r.steps.length*100}%`;
 $('stepText').textContent=s.message.replace(/\b([A-F]\d{1,2})\b/g,(key)=> n(key)?`${key}(${n(key).name})`:key);
 $('stepTag').textContent=({init:'준비',visit:'방문',relax:'거리 갱신',done:'완료'})[s.kind]||'탐색';$('stepCurrentNode').textContent=s.current?(n(s.current)?.name||s.current):'준비';
 draw();}
function stepTo(value){if(!state.result)return;state.step=Math.min(state.result.steps.length-1,Math.max(0,value));renderStep();}
function stop(){if(state.play){clearInterval(state.play);state.play=null}$('playBtn').textContent='▶ 재생'}
function autoplay(){if(!state.result)return;if(state.play){stop();return}if(state.step>=state.result.steps.length-1)stepTo(0);
 $('playBtn').textContent='Ⅱ 멈춤';state.play=setInterval(()=>{if(state.step>=state.result.steps.length-1){stop();return}stepTo(state.step+1)},520)}
async function edit(data,withToast=true){const res=await api('/api/edit',data);const beforeA=$('startSelect').value,beforeB=$('goalSelect').value;
 state.graph=res.graph;state.result=null;state.step=-1;setupChoices(n(beforeA)?beforeA:null,n(beforeB)?beforeB:null);clearSelected();renderResult();renderStep();showPlaces();draw();
 if(withToast)toast('지도에 변경 사항을 저장했습니다.');return res}
function openModal(title,html){stop();$('modalTitle').textContent=title;$('modalBody').innerHTML=html;$('modalBackdrop').classList.remove('hidden')}
function closeModal(){$('modalBackdrop').classList.add('hidden');state.moveMode=false}
function modalTabs(active){return `<div class="modalSubtabs"><button data-tab="places" class="${active==='places'?'active':''}">장소 추가·수정</button><button data-tab="roads" class="${active==='roads'?'active':''}">연결된 길 관리</button><button data-tab="placement" class="${active==='placement'?'active':''}">지도 위치 조정</button></div>`}
function manageModal(tab='places'){state.modalTab=tab;
 if(tab==='places'){
   openModal('장소와 길 관리',modalTabs(tab)+`<h3>새 장소 추가</h3><p>지도에 표시할 장소의 이름을 입력하세요. 번호는 다른 장소와 구별하는 표식입니다.</p><form id="addPlaceForm" class="formGrid"><label>장소 이름<input id="placeNameIn" required maxlength="80" placeholder="예: 음악관"></label><label>장소 번호<input id="placeIdIn" required maxlength="24" placeholder="예: G1"></label><div class="full"><button class="modalBtn" type="submit">장소 추가</button></div></form><h3>장소 이름 변경 또는 삭제</h3><div class="formGrid"><label>관리할 장소<select id="placePick">${nodeOpts()}</select></label><label>변경할 이름<input id="renameIn" maxlength="80" placeholder="새 이름"></label><div class="full"><button id="renameBtn" class="modalBtn modalSecondary">이름 바꾸기</button><button id="deletePlaceBtn" class="modalBtn dangerBtn">이 장소 삭제</button></div></div>`);
   $('addPlaceForm').onsubmit=async evt=>{evt.preventDefault();try{const id=$('placeIdIn').value,name=$('placeNameIn').value;await edit({action:'add_place',id,name,x:500,y:380});manageModal('placement')}catch(e){toast(errText(e))}};
   $('renameBtn').onclick=async()=>{try{await edit({action:'rename_place',id:$('placePick').value,name:$('renameIn').value});manageModal('places')}catch(e){toast(errText(e))}};
   $('deletePlaceBtn').onclick=async()=>{const id=$('placePick').value;if(!confirm(`${n(id)?.name||id} 장소와 이곳에 연결된 길을 삭제할까요?`))return;try{await edit({action:'delete_place',id});manageModal('places')}catch(e){toast(errText(e))}};
 }else if(tab==='roads'){
   openModal('장소와 길 관리',modalTabs(tab)+`<h3>두 장소를 잇는 길 추가</h3><p>길의 거리에는 두 장소 사이의 이동 비용을 입력합니다. 기존 길을 다시 연결하면 거리를 바꿀 수 있습니다.</p><form id="roadForm" class="formGrid"><label>첫 번째 장소<select id="roadA">${nodeOpts()}</select></label><label>두 번째 장소<select id="roadB">${nodeOpts()}</select></label><label class="full">이동 거리 또는 비용<input id="roadCost" type="number" min="1" max="100000" step="1" required value="80" placeholder="예: 80"></label><div class="full"><button type="submit" class="modalBtn">길 연결 · 거리 적용</button><button type="button" id="roadDelete" class="modalBtn dangerBtn">두 장소 사이의 길 삭제</button></div></form><p>장소가 연결되어 있으면 다익스트라와 A*는 입력한 가중치를 합산하여 경로를 계산합니다.</p>`);
   $('roadB').selectedIndex=Math.min(1,$('roadB').options.length-1);
   $('roadForm').onsubmit=async evt=>{evt.preventDefault();try{await edit({action:'connect',source:$('roadA').value,target:$('roadB').value,distance:Number($('roadCost').value)});manageModal('roads')}catch(e){toast(errText(e))}};
   $('roadDelete').onclick=async()=>{if(!confirm('두 장소를 잇는 길을 삭제할까요?'))return;try{await edit({action:'disconnect',source:$('roadA').value,target:$('roadB').value});manageModal('roads')}catch(e){toast(errText(e))}};
 }else{
   openModal('장소와 길 관리',modalTabs(tab)+`<h3>장소 위치를 직접 옮기기</h3><p>위치를 바꿀 장소를 선택해 지도에서 드래그하세요. 드래그를 놓으면 변경 사항이 자동 저장됩니다.</p><button id="placeMoveBtn" class="modalBtn">지도에서 위치 조정 시작</button><p>위치 조정은 지도와 그래프 표시의 배치에만 영향을 줍니다. 연결된 길과 이동 거리는 별도로 수정할 수 있습니다.</p>`);
   $('placeMoveBtn').onclick=()=>{closeModal();state.moveMode=true;setMode('graph');toast('장소를 드래그해서 옮기세요. 이동이 끝나면 위치가 저장됩니다.')};
 }
 document.querySelectorAll('[data-tab]').forEach(btn=>btn.onclick=()=>manageModal(btn.dataset.tab));
}
function guideModal(){openModal('GraphWay 이용 방법',`<div class="guide"><h3>① 출발지와 도착지를 선택해요</h3><p>왼쪽에서 건물을 선택하거나 지도 위의 건물 표시를 클릭한 뒤 ‘여기서 출발’ 또는 ‘여기로 도착’을 누르세요.</p><h3>② 경로를 찾아요</h3><p>‘경로 찾기’를 누르면 이동 순서가 표시됩니다. 지도에서 파란색 선을 따라가며 각 장소의 연결을 확인할 수 있습니다.</p><h3>③ 알고리즘을 따라가요</h3><p>‘그래프 학습’으로 전환하고, 오른쪽의 재생 버튼이나 이전·다음 버튼을 사용해 탐색 과정을 살펴보세요.</p><h3>④ 건물과 길을 바꿔 볼 수 있어요</h3><p>‘장소와 길 관리’에서 새로운 장소를 만들고 길을 연결해 보세요. 변경 사항은 컴퓨터에 저장됩니다.</p><h3>지도 안내</h3><p>캠퍼스 건물 이름과 구역은 국립순천대학교 공식 안내도에 따라 표기했습니다. 학습 지도에 표시된 연결과 이동 거리는 교육용 추정값이며, 실제 통행 여부와 보행거리를 보장하지 않습니다.</p><a href="https://www.scnu.ac.kr/campusmap.jsp" target="_blank" rel="noopener noreferrer" class="smallPrimary">학교 공식 캠퍼스 길찾기 ↗</a></div>`)}
async function compareModal(){const a=$('startSelect').value,b=$('goalSelect').value;try{const [d,astar,bfs]=await Promise.all(['Dijkstra','A*','BFS'].map(algorithm=>api('/api/search',{start:a,goal:b,algorithm})));
 const rows=[['다익스트라',d],['A*',astar],['너비 우선 탐색',bfs]];
 openModal('알고리즘 결과 비교',`<p><strong>${esc(n(a)?.name||a)} → ${esc(n(b)?.name||b)}</strong> 경로에서 세 알고리즘의 특징을 비교합니다.</p><table class="compareTable"><thead><tr><th>탐색 방법</th><th>이동 비용</th><th>방문 장소</th><th>경유</th></tr></thead><tbody>${rows.map(([name,r])=>`<tr><td><b>${esc(name)}</b></td><td>${r.distance===null?'연결 없음':fmt(r.distance)}</td><td>${r.visit_order.length}곳</td><td>${Math.max(0,r.path.length-1)}구간</td></tr>`).join('')}</tbody></table><p>다익스트라와 A*는 가중치 기준 최단경로를 찾습니다. 너비 우선 탐색(BFS)은 간선의 개수가 가장 적은 경로를 찾으므로 거리 합계가 다를 수 있습니다.</p>`);
 }catch(e){toast(errText(e))}}
function exportImage(){
 if(state.mode==='official'){toast('지도 모드 또는 그래프 학습 모드에서 그림을 저장할 수 있습니다.');return}
 const original=$('mapSvg'),copy=original.cloneNode(true);
 copy.setAttribute('xmlns',NS);copy.setAttribute('width','2000');copy.setAttribute('height','1520');
 const style=$S('style',{},null,`
  .building{fill:#fefefe;stroke:#b6cbbd;stroke-width:2}.buildingAcademic{fill:#dce9f1;stroke:#a4c4d6}.buildingDorm{fill:#efded8;stroke:#cfbbb1}.buildingOther{fill:#f0e3d3;stroke:#d5bfa1}
  .mapRoad{fill:none;stroke:#fff;stroke-width:25;stroke-linecap:round;stroke-linejoin:round}.mapRoadEdge{fill:none;stroke:#c5d6c8;stroke-width:28;stroke-linecap:round;stroke-linejoin:round}
  .routeGlow{stroke:#fff;stroke-width:12;fill:none;stroke-linecap:round;stroke-linejoin:round}.routeMain{stroke:#207ce6;stroke-width:7;fill:none;stroke-linecap:round;stroke-linejoin:round}
  .outlineGraph{stroke:#b6c8da;stroke-width:2;stroke-linecap:round}.exploreEdge{stroke:#e9b657;stroke-width:5}.pinLabel{font-family:Malgun Gothic,sans-serif;font-weight:800;font-size:12px;paint-order:stroke;stroke:#fff;stroke-width:3px;stroke-linejoin:round}
  .zoneLabel{font:800 18px sans-serif;fill:#547a7c;opacity:.4}.distanceText{font:11px sans-serif;paint-order:stroke;stroke:#fff;stroke-width:4px;fill:#67819d}.footprintLabels{font:11px sans-serif;fill:#93a39e;font-weight:700}
 `);
 copy.insertBefore(style,copy.firstChild);
 const xml=new XMLSerializer().serializeToString(copy);const blob=new Blob([xml],{type:'image/svg+xml;charset=utf-8'});
 const href=URL.createObjectURL(blob);const img=new Image();img.onload=()=>{
   const canvas=document.createElement('canvas');canvas.width=2400;canvas.height=1824;
   const ctx=canvas.getContext('2d');ctx.fillStyle='#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);
   URL.revokeObjectURL(href);canvas.toBlob(output=>{
      if(!output){toast('그림을 저장하지 못했습니다.');return}const dl=URL.createObjectURL(output);
      const link=document.createElement('a');link.href=dl;link.download='GraphWay_캠퍼스지도.png';link.click();setTimeout(()=>URL.revokeObjectURL(dl),1000);
   },'image/png');
 };
 img.onerror=()=>{URL.revokeObjectURL(href);toast('그림을 저장하지 못했습니다.')};img.src=href;
 $('fileMenu').classList.add('hidden');
}
async function resetMap(){if(!confirm('변경한 장소와 길을 지우고 학교 지도를 처음 상태로 되돌릴까요?'))return;try{await edit({action:'reset'});$('fileMenu').classList.add('hidden');fit();toast('학교 지도를 복원했습니다.')}catch(e){toast(errText(e))}}
async function importFile(file){if(!file)return;try{if(file.size>2_000_000)throw Error('2MB 이하의 지도 파일만 불러올 수 있습니다.');const json=JSON.parse(await file.text());if(!confirm('현재 지도를 불러온 지도로 바꿀까요?'))return;await edit({action:'import',graph:json});toast('저장된 지도를 불러왔습니다.')}catch(e){toast(`지도를 불러오지 못했습니다. ${errText(e)}`)}finally{$('importInput').value=''}}
async function init(){try{const data=await api('/api/state');state.graph=data.graph;setupChoices(data.start,data.goal);showPlaces();fit();draw();renderResult();renderStep();await calculate()}catch(e){toast('지도를 열지 못했습니다. '+errText(e))}}
function wire(){
 $('mapTab').onclick=()=>setMode('map');$('graphTab').onclick=()=>setMode('graph');$('officialTab').onclick=()=>setMode('official');
 $('zoomInBtn').onclick=()=>zoom(.8);$('zoomOutBtn').onclick=()=>zoom(1.25);$('fitBtn').onclick=fit;
 $('searchBtn').onclick=calculate;$('startSelect').onchange=()=>{$('placePopover').classList.add('hidden');draw()};$('goalSelect').onchange=()=>{$('placePopover').classList.add('hidden');draw()};
 $('swapBtn').onclick=()=>{const a=$('startSelect').value;$('startSelect').value=$('goalSelect').value;$('goalSelect').value=a;draw();calculate()};
 $('algoSelect').onchange=()=>{$('algoDescription').textContent=DESCRIPTIONS[$('algoSelect').value];calculate()};
 $('algoHelp').onclick=()=>guideModal();$('placeSearch').oninput=showPlaces;
 $('popCloseBtn').onclick=()=>clearSelected();$('popStartBtn').onclick=()=>{if(state.picked){$('startSelect').value=state.picked;$('placePopover').classList.add('hidden');draw()}};
 $('popGoalBtn').onclick=()=>{if(state.picked){$('goalSelect').value=state.picked;$('placePopover').classList.add('hidden');draw()}};
 $('prevBtn').onclick=()=>{stop();stepTo(state.step-1)};$('nextBtn').onclick=()=>{stop();stepTo(state.step+1)};$('playBtn').onclick=autoplay;
 $('textSizeBtn').onclick=()=>{const on=document.body.classList.toggle('largeText');$('textSizeBtn').textContent=on?'기본 글자 크기':'글자 크게';$('textSizeBtn').setAttribute('aria-pressed',String(on))};
 $('guideBtn').onclick=guideModal;$('manageBtn').onclick=()=>manageModal('places');$('compareBtn').onclick=compareModal;
 $('modalClose').onclick=closeModal;$('modalBackdrop').onclick=evt=>{if(evt.target.id==='modalBackdrop')closeModal()};
 $('fileMenuBtn').onclick=()=>{const drop=$('fileMenu');drop.classList.toggle('hidden');$('fileMenuBtn').setAttribute('aria-expanded',String(!drop.classList.contains('hidden')))};
 $('imageExportBtn').onclick=exportImage;
 $('backupBtn').onclick=()=>{window.location.href='/api/export';$('fileMenu').classList.add('hidden')};
 $('restoreBtn').onclick=()=>{$('importInput').click();$('fileMenu').classList.add('hidden')};$('importInput').onchange=evt=>importFile(evt.target.files[0]);$('resetBtn').onclick=resetMap;
 document.addEventListener('click',evt=>{if(!evt.target.closest('.menuwrap'))$('fileMenu').classList.add('hidden')});
 document.addEventListener('keydown',evt=>{if(evt.key==='Escape'){closeModal();stop();$('placePopover').classList.add('hidden');state.moveMode=false}
 if(evt.key==='F5'){evt.preventDefault();calculate()}
 if(evt.key==='F6'){evt.preventDefault();stop();stepTo(state.step+(evt.shiftKey?-1:1))}});
 $('officialImage').onerror=()=>{$('officialImage').classList.add('hidden');$('officialImageError').classList.remove('hidden')};
 bindCanvas();}
wire();init();

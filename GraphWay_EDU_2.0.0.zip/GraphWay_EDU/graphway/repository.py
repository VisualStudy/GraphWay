"""SQLite graph persistence with foreign keys and atomic replacement."""
import sqlite3
from pathlib import Path
from .model import CampusGraph, Node, Edge
from .sample_data import build_demo_graph


class GraphRepository:
    def __init__(self, path: str | Path):
        self.path = Path(path).expanduser()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.execute('PRAGMA foreign_keys = ON')
        self.conn.executescript('''
        CREATE TABLE IF NOT EXISTS nodes (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            x REAL NOT NULL,
            y REAL NOT NULL,
            zone TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS edges (
            source TEXT NOT NULL,
            target TEXT NOT NULL,
            distance REAL NOT NULL CHECK (distance > 0),
            PRIMARY KEY (source, target),
            FOREIGN KEY(source) REFERENCES nodes(id) ON DELETE CASCADE,
            FOREIGN KEY(target) REFERENCES nodes(id) ON DELETE CASCADE,
            CHECK (source < target)
        );
        ''')
        self.conn.commit()

    def load(self) -> CampusGraph:
        nodes = [Node(*r) for r in self.conn.execute('SELECT id,name,x,y,zone FROM nodes ORDER BY id')]
        edges = [Edge(*r) for r in self.conn.execute('SELECT source,target,distance FROM edges ORDER BY source,target')]
        if not nodes:
            graph = build_demo_graph()
            self.save(graph)
            return graph
        return CampusGraph(nodes, edges)

    def save(self, graph: CampusGraph) -> None:
        with self.conn:
            self.conn.execute('DELETE FROM edges')
            self.conn.execute('DELETE FROM nodes')
            self.conn.executemany('INSERT INTO nodes VALUES (?,?,?,?,?)', [(n.id,n.name,n.x,n.y,n.zone) for n in graph.nodes.values()])
            self.conn.executemany('INSERT INTO edges VALUES (?,?,?)', [(min(e.source,e.target), max(e.source,e.target),e.distance) for e in graph.edges.values()])

    def close(self):
        self.conn.close()

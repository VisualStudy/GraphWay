"""GraphWay HTTP service: local-only Python server with SQLite persistence."""
from __future__ import annotations
import argparse
import json
import math
import os
import shutil
import subprocess
import sys
import threading
import webbrowser
from dataclasses import replace
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

from .algorithms import search
from .model import CampusGraph, Node, Edge
from .repository import GraphRepository
from .sample_data import build_demo_graph

STATIC = Path(__file__).resolve().parent / 'web'
PUBLIC = {'/':'index.html','/app.js':'app.js','/style.css':'style.css'}
MIME = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8'}


def storage_path():
    setting=os.environ.get('GRAPHWAY_DATA_DIR')
    if setting: return Path(setting).expanduser()/'campus.db'
    base=Path(os.getenv('LOCALAPPDATA',str(Path.home()))) if os.name=='nt' else Path.home()/'.local'/'share'
    return base/'GraphWayEDU'/'campus.db'


class State:
    def __init__(self, path=None):
        self.lock=threading.RLock()
        self.repo=GraphRepository(path or storage_path())
        self.graph=self.repo.load()
        # Only upgrade an untouched first-release sample, keeping edited maps.
        legacy_file=Path(__file__).resolve().parent/'resources'/'legacy_v1.json'
        if legacy_file.is_file():
            try:
                prior=CampusGraph.from_dict(json.loads(legacy_file.read_text(encoding='utf-8')))
                if (self.graph.nodes==prior.nodes and
                    {k:e.distance for k,e in self.graph.edges.items()}==
                    {k:e.distance for k,e in prior.edges.items()}):
                    self.graph=build_demo_graph()
                    self.repo.save(self.graph)
            except (ValueError,KeyError,TypeError):
                pass

    def do_search(self, data):
        with self.lock:
            start=str(data.get('start',''))
            goal=str(data.get('goal',''))
            algo=str(data.get('algorithm','Dijkstra'))
            r=search(self.graph,start,goal,algo)
            return {'algorithm':r.algorithm,'start':r.start,'goal':r.goal,
                    'found':r.found,'path':r.path,'distance':r.distance,
                    'visit_order':r.visit_order,
                    'steps':[{'current':s.current,'visited':s.visited,
                         'frontier':s.frontier,
                         'distances':{k:v for k,v in s.distances.items() if math.isfinite(v)},
                         'message':s.message,'kind':s.kind,'relaxed':s.relaxed} for s in r.steps]}

    def mutate(self, data):
        with self.lock:
            graph=CampusGraph.from_dict(self.graph.to_dict())
            op=data.get('action')
            if op=='add_place':
                code=str(data.get('id','')).strip().upper()
                name=str(data.get('name','')).strip()
                if not code or len(code)>24 or not code.replace('-','').isalnum():
                    raise ValueError('장소 번호는 영문 또는 숫자 24자 이내로 입력하세요.')
                if code in graph.nodes: raise ValueError('이미 사용 중인 장소 번호입니다.')
                if len(name)>80: raise ValueError('장소 이름은 80자 이내로 입력하세요.')
                x=float(data.get('x',500));y=float(data.get('y',380))
                if not (0<=x<=1000 and 0<=y<=760):raise ValueError('지도에서 장소를 놓을 위치를 확인하세요.')
                graph.add_node(Node(code,name,x,y,code[0]))
            elif op=='rename_place':
                code=str(data.get('id',''));name=str(data.get('name','')).strip()
                if code not in graph.nodes:raise ValueError('해당 장소가 없습니다.')
                if not (1<=len(name)<=80):raise ValueError('장소 이름을 1~80자로 입력하세요.')
                graph.add_node(replace(graph.nodes[code],name=name))
            elif op=='move_place':
                code=str(data.get('id',''));x=float(data.get('x'));y=float(data.get('y'))
                if code not in graph.nodes:raise ValueError('해당 장소가 없습니다.')
                if not (0<=x<=1000 and 0<=y<=760):raise ValueError('지도 범위를 벗어났습니다.')
                graph.add_node(replace(graph.nodes[code],x=x,y=y))
            elif op=='delete_place':
                graph.remove_node(str(data.get('id','')))
            elif op=='connect':
                a=str(data.get('source',''));b=str(data.get('target',''))
                dist=float(data.get('distance',0))
                graph.add_edge(Edge(a,b,dist))
            elif op=='disconnect':
                graph.remove_edge(str(data.get('source','')),str(data.get('target','')))
            elif op=='reset':
                graph=build_demo_graph()
            elif op=='import':
                graph=CampusGraph.from_dict(data.get('graph'))
            else:raise ValueError('지원되지 않는 요청입니다.')
            self.repo.save(graph)
            self.graph=graph
            return {'graph':graph.to_dict()}


def make_handler(state):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            pass

        def respond(self, payload, code=200):
            raw=json.dumps(payload,ensure_ascii=False,allow_nan=False).encode('utf-8')
            self.send_response(code)
            self.send_header('Content-Type','application/json; charset=utf-8')
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Length',str(len(raw)))
            self.end_headers();self.wfile.write(raw)

        def do_GET(self):
            path=urlsplit(self.path).path
            if path in PUBLIC:
                target=STATIC/PUBLIC[path]
                if not target.is_file():self.send_error(404);return
                raw=target.read_bytes()
                self.send_response(200)
                self.send_header('Content-Type',MIME[target.suffix])
                self.send_header('Cache-Control','no-cache')
                self.send_header('X-Content-Type-Options','nosniff')
                self.send_header('Content-Length',str(len(raw)))
                self.end_headers();self.wfile.write(raw)
            elif path=='/api/state':
                with state.lock:
                    self.respond({'graph':state.graph.to_dict(),
                                  'start':'A19' if 'A19' in state.graph.nodes else next(iter(state.graph.nodes),''),
                                  'goal':'C1' if 'C1' in state.graph.nodes else list(state.graph.nodes)[-1] if state.graph.nodes else ''})
            elif path=='/api/health':self.respond({'status':'ok'})
            elif path=='/api/export':
                with state.lock: data=state.graph.to_dict()
                payload=json.dumps(data,ensure_ascii=False,indent=2).encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type','application/octet-stream')
                self.send_header('Content-Disposition','attachment; filename="my-campus-map.graphway.json"')
                self.send_header('Content-Length',str(len(payload)))
                self.end_headers();self.wfile.write(payload)
            else:self.send_error(404)

        def do_POST(self):
            path=urlsplit(self.path).path
            if path not in {'/api/search','/api/edit'}:self.send_error(404);return
            try:
                n=int(self.headers.get('Content-Length','0'))
                if not 0<n<=2_000_000:raise ValueError('파일 크기를 확인하세요. (최대 2MB)')
                data=json.loads(self.rfile.read(n))
                if not isinstance(data,dict):raise ValueError('요청 형식을 확인하세요.')
                self.respond(state.do_search(data) if path=='/api/search' else state.mutate(data))
            except (ValueError,KeyError,TypeError,OverflowError) as e:
                self.respond({'error':str(e)},400)
            except Exception:
                self.respond({'error':'요청을 처리하지 못했습니다. 내용을 확인하고 다시 시도하세요.'},500)
    return Handler


def create_server(port=0,path=None):
    state=State(path)
    server=ThreadingHTTPServer(('127.0.0.1',port),make_handler(state))
    server.daemon_threads=True
    return server,state


def open_app(url):
    if os.name=='nt':
        dirs=[os.environ.get('ProgramFiles(x86)',''), os.environ.get('PROGRAMFILES',''),
              os.environ.get('LOCALAPPDATA','')]
        names=[Path(p)/'Microsoft'/'Edge'/'Application'/'msedge.exe' for p in dirs if p]
        names += [Path(p)/'Google'/'Chrome'/'Application'/'chrome.exe' for p in dirs if p]
        for exe in names:
            if exe.is_file():
                subprocess.Popen([str(exe),f'--app={url}','--window-size=1540,920'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
                return
    webbrowser.open(url)


def main():
    p=argparse.ArgumentParser(description='GraphWay EDU')
    p.add_argument('--port',type=int,default=0)
    p.add_argument('--no-browser',action='store_true')
    p.add_argument('--data-dir',type=Path)
    args=p.parse_args()
    server,state=create_server(args.port,(args.data_dir/'campus.db') if args.data_dir else None)
    url=f'http://127.0.0.1:{server.server_address[1]}/'
    print(f'GraphWay EDU | {url}',flush=True)
    if not args.no_browser:threading.Timer(0.4,open_app,args=(url,)).start()
    try:server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:pass
    finally:server.server_close();state.repo.close()

if __name__=='__main__':main()

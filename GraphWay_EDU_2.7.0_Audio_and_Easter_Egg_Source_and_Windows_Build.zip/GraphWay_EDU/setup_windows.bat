@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo [GraphWay EDU] Checking Python...
call "%~dp0check_python_windows.bat"
if errorlevel 1 (
  echo.
  echo Setup failed. Check the messages above.
  pause
  exit /b 1
)
echo.
echo [GraphWay EDU] Python was found.
echo No extra package installation is needed to run the app.
echo Double-click run_windows.bat to start GraphWay EDU.
pause
exit /b 0

"""GraphWay EDU — interactive campus graph and shortest-path education."""
__version__ = "2.7.0"

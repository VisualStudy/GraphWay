'use strict';
/* GraphWay soundtrack: original procedural music and movement effects, all generated
 * locally with the Web Audio API. No downloads, external sound files or services. */
(() => {
  const toggle = document.getElementById('soundToggle');
  const slider = document.getElementById('soundVolume');
  const surprise = document.getElementById('campusSurprise');
  const closeSurprise = document.getElementById('closeSurprise');
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  const pref = key => { try { return localStorage.getItem(key); } catch { return null; } };
  const save = (key, value) => { try { localStorage.setItem(key, value); } catch { /* private browsing */ } };
  let enabled = pref('graphway.sound.enabled') !== 'false';
  let volume = Math.min(100, Math.max(0, Number(pref('graphway.sound.volume') ?? '35') || 0));
  let context = null, mainGain = null, musicGain = null, effectsGain = null;
  let ambientTimer = null, chordIndex = 0;
  let lastFootstep = 0, lastLeg = -1, isMoving = false;
  let clicks = 0, previousClick = 0, surpriseTimer = null;
  const reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;

  function updateControls() {
    slider.value = String(volume);
    toggle.textContent = enabled ? '♫ 소리 켜짐' : '♪ 소리 꺼짐';
    toggle.setAttribute('aria-pressed', String(enabled));
    toggle.setAttribute('aria-label', enabled ? '배경음과 효과음 끄기' : '배경음과 효과음 켜기');
    slider.disabled = !enabled;
    if (mainGain && context) mainGain.gain.setTargetAtTime(enabled ? volume / 100 : 0, context.currentTime, .035);
  }

  function audioContext() {
    if (!AudioCtx || !enabled) return null;
    if (context) return context;
    try {
      context = new AudioCtx();
      mainGain = context.createGain();
      mainGain.gain.value = volume / 100;
      musicGain = context.createGain();
      musicGain.gain.value = .45;
      effectsGain = context.createGain();
      effectsGain.gain.value = .55;
      musicGain.connect(mainGain);
      effectsGain.connect(mainGain);
      mainGain.connect(context.destination);
      return context;
    } catch { return null; }
  }

  function note(frequency, when, length, strength = .08, kind = 'sine', channel = musicGain) {
    if (!context || context.state !== 'running' || !channel || !enabled) return;
    const oscillator = context.createOscillator();
    const amp = context.createGain();
    const filter = context.createBiquadFilter();
    oscillator.type = kind;
    oscillator.frequency.setValueAtTime(frequency, when);
    filter.type = 'lowpass';
    filter.frequency.value = kind === 'triangle' ? 1550 : 2600;
    amp.gain.setValueAtTime(.0001, when);
    amp.gain.linearRampToValueAtTime(strength, when + Math.min(.35, length * .16));
    amp.gain.exponentialRampToValueAtTime(.0001, when + length);
    oscillator.connect(filter); filter.connect(amp); amp.connect(channel);
    oscillator.start(when); oscillator.stop(when + length + .02);
  }

  // Calm original four-chord loop. Notes are synthesized; no copyrighted recordings.
  const chords = [
    [130.81, 164.81, 196.00], [146.83, 174.61, 220.00],
    [130.81, 164.81, 220.00], [146.83, 196.00, 246.94],
  ];
  const melody = [392, 440, 329.63, 392, 349.23, 440, 392, 329.63];
  function playAmbientBar() {
    if (!context || context.state !== 'running' || !enabled || document.hidden) return;
    const t = context.currentTime + .04;
    const chord = chords[chordIndex % chords.length];
    chord.forEach((hz, i) => note(hz, t + i * .045, 4.3, i === 0 ? .077 : .049, 'sine'));
    note(melody[(chordIndex * 2) % melody.length], t + .65, 1.2, .027, 'triangle');
    note(melody[(chordIndex * 2 + 1) % melody.length], t + 2.8, 1.25, .023, 'triangle');
    chordIndex++;
  }
  function startAmbient() {
    if (ambientTimer !== null || !enabled || !context || context.state !== 'running') return;
    playAmbientBar();
    ambientTimer = window.setInterval(playAmbientBar, 4800);
  }
  function pauseAmbient() {
    if (ambientTimer !== null) window.clearInterval(ambientTimer);
    ambientTimer = null;
  }
  function unlock() {
    const ctx = audioContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') ctx.resume().then(startAmbient).catch(() => {});
    else startAmbient();
  }
  function shortTone(freq, duration = .12, strength = .05, waveform = 'sine') {
    if (!enabled || !context || context.state !== 'running') return;
    note(freq, context.currentTime + .005, duration, strength, waveform, effectsGain);
  }
  function stepSound(stepIndex) {
    // Low-volume two-part tick that tracks continuous interpolation, not algorithm probes.
    const hz = stepIndex % 2 ? 180 : 220;
    shortTone(hz, .095, .072, 'triangle');
    shortTone(hz * 1.44, .053, .018);
  }
  function arrivalSound(isFinished) {
    shortTone(isFinished ? 523.25 : 392, .2, .095);
    if (isFinished && context?.state === 'running') {
      note(659.25, context.currentTime + .15, .34, .082, 'sine', effectsGain);
      note(783.99, context.currentTime + .35, .49, .06, 'sine', effectsGain);
    }
  }
  const GraphWayAudio = {
    journeyStart() { isMoving = true; lastLeg = -1; lastFootstep = 0; unlock(); },
    journeyStop() { isMoving = false; },
    journeyProgress(leg, progress) {
      if (!isMoving || !enabled || !context || context.state !== 'running') return;
      // At most one light step per ~280ms. Frame rate cannot increase the sound rate.
      const now = performance.now();
      if (leg !== lastLeg) { lastLeg = leg; lastFootstep = 0; }
      if (progress > .05 && progress < .97 && now - lastFootstep >= 295) {
        stepSound(Math.floor(progress * 6) + leg);
        lastFootstep = now;
      }
    },
    journeyArrive(leg, total) { if (isMoving) arrivalSound(leg >= total); },
    unlock,
    getStatus() { return { enabled, volume, initialized: Boolean(context), moving: isMoving }; },
  };
  window.GraphWayAudio = GraphWayAudio;

  toggle.addEventListener('click', () => {
    enabled = !enabled;
    save('graphway.sound.enabled', String(enabled));
    updateControls();
    if (enabled) unlock(); else pauseAmbient();
  });
  slider.addEventListener('input', () => {
    volume = Number(slider.value);
    save('graphway.sound.volume', String(volume));
    updateControls();
    unlock();
  });
  // Browsers may block initial autoplay. Begin after the first real user gesture.
  document.addEventListener('pointerdown', unlock, { passive: true });
  document.addEventListener('keydown', unlock);
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) pauseAmbient(); else if (enabled) unlock();
  });
  updateControls();
  unlock();

  function boomSound() {
    if (!enabled || !context || context.state !== 'running') return;
    const t = context.currentTime;
    // Descending synthesizer sweep: cartoon cue, not a realistic explosion recording.
    const osc = context.createOscillator();
    const amp = context.createGain();
    const filt = context.createBiquadFilter();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(520, t);
    osc.frequency.exponentialRampToValueAtTime(55, t + .6);
    filt.type = 'lowpass'; filt.frequency.value = 650;
    amp.gain.setValueAtTime(.0001, t);
    amp.gain.linearRampToValueAtTime(.17, t + .055);
    amp.gain.exponentialRampToValueAtTime(.0001, t + .75);
    osc.connect(filt); filt.connect(amp); amp.connect(effectsGain);
    osc.start(t); osc.stop(t + .8);
    note(783.99, t + .13, .2, .085, 'triangle', effectsGain);
  }
  function hideSurprise() {
    if (surprise.classList.contains('hidden')) return;
    surprise.classList.add('hidden');
    surprise.setAttribute('aria-hidden', 'true');
    window.clearTimeout(surpriseTimer);
    document.getElementById('panelToggleBtn').focus();
  }
  function showSurprise() {
    if (typeof window.stop === 'function') window.stop();
    surprise.classList.remove('hidden');
    surprise.setAttribute('aria-hidden', 'false');
    surprise.classList.remove('surpriseReplay');
    void surprise.offsetWidth; // Restart CSS only for this deliberately hidden event.
    surprise.classList.add('surpriseReplay');
    boomSound();
    closeSurprise.focus();
    surpriseTimer = window.setTimeout(hideSurprise, reducedMotion ? 3600 : 6800);
  }
  const panelButton = document.getElementById('panelToggleBtn');
  document.addEventListener('click', event => {
    if (surprise.contains(event.target)) return;
    const clickedPanel = event.target.closest?.('#panelToggleBtn') === panelButton;
    if (!clickedPanel) { clicks = 0; return; }
    const now = performance.now();
    clicks = now - previousClick <= 2300 ? clicks + 1 : 1;
    previousClick = now;
    if (clicks === 10) { clicks = 0; showSurprise(); }
  }, true);
  closeSurprise.addEventListener('click', hideSurprise);
  surprise.addEventListener('click', event => { if (event.target === surprise || event.target.classList.contains('surpriseBackdrop')) hideSurprise(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape') hideSurprise(); });
  window.GraphWaySurprise = { isVisible() { return !surprise.classList.contains('hidden'); } };
})();

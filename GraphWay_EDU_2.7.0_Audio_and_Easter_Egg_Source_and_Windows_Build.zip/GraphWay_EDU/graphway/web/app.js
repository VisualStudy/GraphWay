'use strict';
const $ = id => document.getElementById(id);
const NS = 'http://www.w3.org/2000/svg';
const ZONES = {A:'중앙 · 운동장 · 생활관',B:'정문 동쪽 · 생명과학',C:'도서관 · 북문',D:'공과대학',E:'학생회관 · 사범대학',F:'서쪽 · 체육시설'};
const COLORS = {A:'#2d72c4',B:'#9a69b0',C:'#187f8c',D:'#d7786c',E:'#c58b45',F:'#7f996c'};
const DESCRIPTIONS = {
  'Dijkstra':'길마다 이동 거리를 더해 가장 짧은 경로를 찾습니다.',
  'A*':'목적지까지의 남은 거리를 추정해 탐색 순서를 결정합니다.',
  'BFS':'방문하는 길의 개수가 가장 적은 경로를 찾습니다. 가장 짧은 거리는 아닐 수 있습니다.'
};
const $S = (tag,attrs={},parent=null,text=null)=>{const e=document.createElementNS(NS,tag);for(const [k,v] of Object.entries(attrs))e.setAttribute(k,String(v));if(text!==null)e.textContent=text;if(parent)parent.appendChild(e);return e};
const esc = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// Click positions correspond to the labelled badges on the university's 1000 × 570
// illustrated campus image. These are IMAGE coordinates, not GPS or walkway data.
// The official JPEG is fetched from the university and never bundled here.
const OFFICIAL_POINTS = Object.freeze({
 A1:[520,231],A2:[629,248],A3:[622,204],A4:[485,193],A5:[450,211],
 A6:[482,133],A7:[465,167],A8:[397,207],A9:[380,134],A10:[425,146],
 A11:[441,108],A12:[413,95],A13:[354,248],A14:[329,216],A15:[398,298],
 A16:[293,349],A17:[292,385],A18:[418,416],A19:[431,467],
 B1:[588,416],B2:[670,333],B3:[740,379],B4:[742,287],B5:[784,315],
 B6:[808,293],B7:[748,474],
 C1:[822,185],C2:[864,271],C3:[898,212],C4:[916,242],C5:[969,262],
 C6:[947,210],D1:[946,171],D2:[933,128],D3:[822,86],D4:[851,60],
 E1:[673,186],E2:[588,121],E3:[738,114],E4:[769,135],E5:[675,93],
 E6:[501,75],E7:[596,51],E8:[727,43],
 F1:[42,291],F2:[158,345],F3:[151,318],F4:[115,275]
});
const state={graph:null,result:null,mode:'map',step:-1,selected:null,picked:null,zoom:{x:0,y:0,w:1300,h:988},officialZoom:1,officialPickStage:0,drag:null,moveMode:false,play:null,motionProgress:0,studyInteracted:false,animateLeg:false,modalTab:'places',toast:null};
function n(id){return state.graph?.nodes.find(p=>p.id===id)}
function mapXY(p){return state.mode==='map'&&typeof MapDesign!=='undefined' ? MapDesign.point(p,state.graph.nodes) : [p.x,p.y]}
function originalXY(pt){return state.mode==='map'&&typeof MapDesign!=='undefined' ? [(pt.x-35)/1.22,(pt.y-28)/1.22] : [pt.x,pt.y]}
function routeLegCount(){return Math.max(0,(state.result?.found?state.result.path.length:1)-1)}
function segmentDistance(a,b){const e=neighbors(a).find(x=>(x.source===a&&x.target===b)||(x.source===b&&x.target===a));return e?.distance??0}
function journeyAlternatives(){
 // The yellow hints are merely other edges adjacent to the CURRENT route node.
 // They are not proof that the algorithm rejected or prohibited those streets.
 const path=state.result?.path||[];
 if(!state.studyInteracted||state.step>=path.length-1)return [];
 const fromIndex=Math.max(0,state.step);
 const origin=path[fromIndex],prev=path[fromIndex-1],next=path[fromIndex+1];
 return neighbors(origin).map(e=>({from:origin,to:e.source===origin?e.target:e.source,distance:e.distance}))
 .filter(e=>e.to!==prev&&e.to!==next)
 .sort((a,b)=>a.distance-b.distance||a.to.localeCompare(b.to,'en'))
 .slice(0,2);
}

function neighbors(id){return state.graph?.edges.filter(e=>e.source===id||e.target===id)||[]}
function fmt(d){return Number.isFinite(d)? Math.round(d).toLocaleString('ko-KR'):'—'}
function errText(error){return error?.message||'요청을 완료하지 못했습니다.'}
async function api(path,payload){const resp=await fetch(path,payload?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}:{});const data=await resp.json();if(!resp.ok)throw new Error(data.error||'처리하지 못했습니다.');return data}
function toast(text){$('toast').textContent=text;$('toast').classList.remove('hidden');clearTimeout(state.toast);state.toast=setTimeout(()=>$('toast').classList.add('hidden'),3700)}
function sortNodes(){return [...(state.graph?.nodes||[])].sort((a,b)=>a.id.localeCompare(b.id,'en',{numeric:true}))}
function nodeOpts(){return sortNodes().map(p=>`<option value="${esc(p.id)}">${esc(p.name)} (${esc(p.id)})</option>`).join('')}
function setupChoices(start,goal){const options=Object.entries(ZONES).map(([z,label])=>`<optgroup label="${esc(label)}">${sortNodes().filter(p=>p.zone===z).map(p=>`<option value="${esc(p.id)}">${esc(p.name)} · ${esc(p.id)}</option>`).join('')}</optgroup>`).join('')+sortNodes().filter(p=>!ZONES[p.zone]).map(p=>`<option value="${esc(p.id)}">${esc(p.name)} · ${esc(p.id)}</option>`).join('');
 const a=$('startSelect'),b=$('goalSelect');a.innerHTML=options;b.innerHTML=options;a.value=start||a.options[0]?.value||'';b.value=goal||b.options[0]?.value||'';}
// 강의와 건물을 같은 검색창에서 찾습니다.
let searchTimer = null;
let searchRequestId = 0;
const lectureLookup = new Map();
const searchState = { courses: [], total: 0, loading: false };
function switchPane(pane) {
    const showResults = pane === 'results';
    $('searchPane').classList.toggle('hidden', showResults);
    $('resultsPane').classList.toggle('hidden', !showResults);
    $('panelToggleBtn').textContent = showResults ? '길찾기 보기' : '탐색 결과 보기';
    $('panelToggleBtn').setAttribute('aria-pressed', String(showResults));
    document.body.classList.toggle('studyOpen',showResults);
}
function showPlaces() {
    const query = $('searchInput').value.trim().toLocaleLowerCase();
    const output = $('unifiedResults');
    const meta = $('searchMeta');
    lectureLookup.clear();
    if (!query) {
        meta.textContent = '찾으려는 강의나 건물을 입력하세요.';
        output.replaceChildren();
        return;
    }
    const buildings = sortNodes().filter(place => `${place.name} ${place.id}`.toLocaleLowerCase().includes(query)).slice(0, 8);
    const matchingCourses = searchState.courses.slice(0, 16);
    const parts = [];
    if (buildings.length) {
        parts.push('<h3 class="resultGroupTitle">건물 및 장소</h3>');
        for (const place of buildings) {
            parts.push(`<div class="buildingResult">
        <button type="button" class="placeItem ${state.selected === place.id ? 'selected' : ''}" data-place-id="${esc(place.id)}">
          <span class="placeIcon">${esc(place.id)}</span>
          <span><strong>${esc(place.name)}</strong><small>${esc(ZONES[place.zone] || '캠퍼스 장소')}</small></span>
        </button>
        <button type="button" class="goalQuickBtn" data-goal-id="${esc(place.id)}">도착지로</button>
      </div>`);
        }
    }
    if (matchingCourses.length) {
        parts.push('<h3 class="resultGroupTitle">강의</h3>');
        matchingCourses.forEach((course, index) => {
            const place = course.building_id && course.building_status === 'candidate'
                ? n(course.building_id) : null;
            lectureLookup.set(String(index), course);
            // 연결된 건물이 있는 강의에만 길찾기 버튼을 표시합니다.
            const placeLine = place
                ? `<div class="lectureBuilding">${esc(place.name)} (${esc(place.id)})</div>` : '';
            const routeButton = place
                ? `<button type="button" class="lectureRouteBtn" data-lecture-id="${index}">이 건물로 길찾기 →</button>` : '';
            parts.push(`<article class="lectureItem">
        <div class="lectureTitle"><strong>${esc(course.course_name)}</strong><span>${esc(course.section)}분반</span></div>
        <div class="lectureCode">${esc(course.course_code)} · ${esc(course.professor)}</div>
        <div class="lectureDetail">시간: ${esc(course.schedule_raw || '시간 미기재')}</div>
        <div class="lectureDetail">강의실: <b>${esc(course.room_raw)}</b></div>
        ${placeLine}${routeButton}
      </article>`);
        });
    }
    if (!parts.length && !searchState.loading) {
        parts.push('<p class="miniInfo">검색 결과가 없습니다.</p>');
    }
    meta.textContent = searchState.loading ? '강의를 검색하고 있습니다…'
        : `건물 ${buildings.length}곳 · 강의 ${searchState.total.toLocaleString('ko-KR')}개`;
    output.innerHTML = parts.join('');
    output.querySelectorAll('[data-place-id]').forEach(button => {
        button.onclick = () => selectPlace(button.dataset.placeId, true);
    });
    output.querySelectorAll('[data-goal-id]').forEach(button => {
        button.onclick = () => {
            $('goalSelect').value = button.dataset.goalId;
            selectPlace(button.dataset.goalId, true);
            $('placePopover').classList.add('hidden');
            calculate(true);
        };
    });
    output.querySelectorAll('[data-lecture-id]').forEach(button => {
        button.onclick = () => routeToLecture(button.dataset.lectureId);
    });
}
async function searchAll() {
    const query = $('searchInput').value.trim();
    const requestId = ++searchRequestId;
    searchState.courses = [];
    searchState.total = 0;
    searchState.loading = Boolean(query);
    showPlaces();
    if (!query)
        return;
    try {
        const response = await api('/api/lectures?q=' + encodeURIComponent(query));
        if (requestId !== searchRequestId)
            return;
        searchState.courses = response.courses;
        searchState.total = response.total;
    }
    catch (error) {
        if (requestId !== searchRequestId)
            return;
        toast(errText(error));
    }
    finally {
        if (requestId === searchRequestId) {
            searchState.loading = false;
            showPlaces();
        }
    }
}
function routeToLecture(id) {
    const course = lectureLookup.get(String(id));
    if (!course || course.building_status !== 'candidate')
        return;
    const place = n(course.building_id);
    if (!place)
        return;
    $('goalSelect').value = place.id;
    selectPlace(place.id, true);
    $('placePopover').classList.add('hidden');
    calculate(true);
}
function setMode(mode){state.mode=mode;for(const [id,m] of [['mapTab','map'],['graphTab','graph'],['officialTab','official']]){const active=m===mode;$(id).classList.toggle('active',active);$(id).setAttribute('aria-selected',String(active))}
 $('officialMapPanel').classList.toggle('hidden',mode!=='official');$('mapSvg').classList.toggle('hidden',mode==='official');$('mapLegend').classList.toggle('hidden',mode==='official');$('mapBanner').classList.toggle('hidden',mode==='official');$('placePopover').classList.add('hidden');
 $('zoomInBtn').disabled=$('zoomOutBtn').disabled=$('fitBtn').disabled=false;
 if(mode==='official'){state.officialPickStage=state.result?2:0;renderOfficialMap()}
 updateTraceBadge();$('bannerTitle').textContent=mode==='graph'?'그래프 연결 구조':'캠퍼스 길찾기';$('bannerSub').textContent=mode==='graph'?'정점 · 간선 · 가중치 시각화':'건물을 클릭하면 출발지나 도착지로 지정할 수 있습니다.';
 draw();}
function svgView(){const v=state.zoom;$('mapSvg').setAttribute('viewBox',`${v.x} ${v.y} ${v.w} ${v.h}`)}
function zoom(f,origin=null){if(state.mode==='official'){updateOfficialZoom(state.officialZoom / f);return}const v=state.zoom,px=origin?.x??v.x+v.w/2,py=origin?.y??v.y+v.h/2;const nw=Math.min(1800,Math.max(235,v.w*f)),nh=nw*(988/1300);
 v.x=px-(px-v.x)*nw/v.w;v.y=py-(py-v.y)*nh/v.h;v.w=nw;v.h=nh;svgView();}
function fit(){if(state.mode==='official'){updateOfficialZoom(1);return}state.zoom={x:0,y:0,w:1300,h:988};svgView()}
function mouseCoords(evt){const p=$('mapSvg').createSVGPoint();p.x=evt.clientX;p.y=evt.clientY;return p.matrixTransform($('mapSvg').getScreenCTM().inverse())}
function background(g){if(state.mode==='map'&&typeof MapDesign!=='undefined'){MapDesign.paintBackground(g,$S,state.graph.nodes);return;}const gr=state.mode==='graph';
 $S('rect',{x:0,y:0,width:1000,height:760,fill:gr?'#f8fbff':'#e5f0e7'},g);
 if(gr){$S('rect',{x:0,y:0,width:1000,height:760,fill:'url(#gridpattern)'},g);$S('text',{x:50,y:703,class:'zoneLabel','font-size':25},g,'GRAPH THEORY · VERTEX / EDGE / WEIGHT');return}
 const parks=[['M0 0H1000V70Q910 75 840 110L790 10H0Z','#d8ead7'],['M0 230Q100 220 160 300L200 430L0 480Z','#cde6cc'],['M760 470Q845 395 1000 450V760H750Z','#d3e8d1'],['M0 685Q160 610 235 675L350 760H0Z','#d5e7d4']];parks.forEach(([d,c])=>$S('path',{d,fill:c},g));
 // Campus street network follows the orientation of the official 3D campus plan.
 const paths=['M0 652 L225 648 L435 690 L540 690 L750 590 L1000 700',
 'M0 420 L170 412 L300 370 L452 430 L625 435 L783 480 L970 532',
 'M155 0 L220 100 L305 175 L410 245 L536 320 L680 335 L840 345 L1000 365',
 'M0 260 L150 245 L270 255 L396 303 L540 350 L680 345',
 'M440 0 L490 85 L535 155 L590 240 L650 360 L695 480 L720 640',
 'M800 0 L750 150 L810 275 L905 325 L1000 320',
 'M275 350 L290 445 L280 560 L435 690',
 'M130 425 L120 500 L215 600 L280 560',
 'M420 240 L420 325 L400 435 L470 540',
 'M665 70 L705 180 L715 290 L770 405'];
 paths.forEach(d=>{$S('path',{d,class:'mapRoadEdge'},g);$S('path',{d,class:'mapRoad'},g)});
 // Campus running track is the main orientation landmark.
 $S('ellipse',{cx:377,cy:485,rx:146,ry:85,fill:'#e6a983',stroke:'#fff1d9','stroke-width':3,transform:'rotate(14 377 485)'},g);
 $S('ellipse',{cx:377,cy:485,rx:119,ry:63,fill:'#8bcaa3',stroke:'#fffaf0','stroke-width':3,transform:'rotate(14 377 485)'},g);
 $S('path',{d:'M262 467L490 507M368 424L380 549',stroke:'#d2ecdc','stroke-width':2},g);
 $S('circle',{cx:378,cy:484,r:22,fill:'none',stroke:'#e5f5eb','stroke-width':2},g);
 $S('rect',{x:60,y:290,width:150,height:62,rx:9,fill:'#d8e6dd',stroke:'#b5ccbc','stroke-width':3},g);
 $S('text',{x:72,y:327,class:'footprintLabels'},g,'캠퍼스 서쪽 출입구');
 // Approximate buildings are not the embedded official illustration; these
 // footprints are a simplified location-index layer used for teaching.
 for(const p of state.graph.nodes){if(p.id.startsWith('A1') && ['A15','A16','A17','A18','A19','A14'].includes(p.id))continue;
   if(['A15','A16','A17','A18','A19','A14','C6'].includes(p.id))continue;
   const width=p.zone==='D'?64:p.zone==='B'?64: p.zone==='E'?65:58;
   const height=p.zone==='D'?40:p.zone==='E'?34:40;
   const cls=p.zone==='A'?'buildingDorm':p.zone==='B'?'buildingOther':'buildingAcademic';
   const rect=$S('rect',{x:p.x-width/2-6,y:p.y-height/2-7,width,height,rx:7,class:`building ${cls}`,transform:`rotate(-9 ${p.x} ${p.y})`,opacity:.92},g);
   rect.setAttribute('pointer-events','none');}
 $S('text',{x:316,y:484,fill:'#fff',opacity:.7,'font-size':18,'font-weight':800},g,'운 동 장');
 $S('text',{x:370,y:727,fill:'#6e9884','font-size':12,'font-weight':750},g,'중앙로 · 정문');
}
function updateOfficialZoom(value){
 state.officialZoom=Math.min(2.4,Math.max(1,Math.round(value*100)/100));
 $('officialImageCanvas').style.width=`${state.officialZoom*100}%`;
}
// SVG overlays explain decisions. A scanning marker is NOT a moving person.
// The algorithm records still exist in Python, but the default playback follows
// ONLY the confirmed path, one adjacent edge at a time.
function activeTrace(){return state.result?.steps?.[state.result.steps.length-1]||null}
function isStudyRunning(){return !!state.result?.found && state.studyInteracted && state.step < routeLegCount()}
function edgeTraceLayer(svg,step,a,b,official=false){
 // Kept for optional advanced teaching mode; the main animation never uses probes.
 if(!step?.edge||!a||!b)return;
 $S('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],class:'traceEdge traceRejected','pointer-events':'none'},svg);
}
function routeMotion(svg,point,official=false){
 if(!point)return;
 $S('circle',{cx:point[0],cy:point[1],r:official?6:9,class:'routeTraveler','pointer-events':'none'},svg);
}
// The cursor counts FINISHED legs. Animation progress is an independent fraction
// of the NEXT adjacent edge; it never jumps to an unconnected graph vertex.
function paintJourney(svg,ids,pointOf,official=false){
 if(!ids?.length)return;
 const coords=ids.map(pointOf);
 if(!state.studyInteracted){
   if(coords.length>1){
     $S('polyline',{points:coords.map(p=>p.join(',')).join(' '),class:official?'officialRouteOutline':'routeGlow','pointer-events':'none'},svg);
     $S('polyline',{points:coords.map(p=>p.join(',')).join(' '),class:official?'officialRouteLine':'routeMain','pointer-events':'none'},svg);
   }
   return;
 }
 if(coords.length>1)$S('polyline',{points:coords.map(p=>p.join(',')).join(' '),class:'journeyPreview','pointer-events':'none'},svg);
 const finished=Math.min(Math.max(0,state.step),ids.length-1);
 for(let i=1;i<=finished;i++){
   const a=coords[i-1],b=coords[i];
   $S('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],class:'journeyCompleted','pointer-events':'none'},svg);
 }
 let at=coords[finished];
 if(finished<coords.length-1){
   const next=coords[finished+1],t=Math.min(1,Math.max(0,state.motionProgress));
   at=[at[0]+(next[0]-at[0])*t,at[1]+(next[1]-at[1])*t];
   $S('line',{x1:coords[finished][0],y1:coords[finished][1],x2:at[0],y2:at[1],class:'journeyActive','pointer-events':'none'},svg);
 }
 routeMotion(svg,at,official);
}
function moveTraveler(){
 const path=state.result?.path||[],leg=state.step;
 if(!state.studyInteracted||leg>=path.length-1)return;
 const a=n(path[leg]),b=n(path[leg+1]);if(!a||!b)return;
 const p=state.mode==='official'?OFFICIAL_POINTS[a.id]:mapXY(a);
 const q=state.mode==='official'?OFFICIAL_POINTS[b.id]:mapXY(b);
 if(!p||!q)return;
 const t=Math.max(0,Math.min(1,state.motionProgress));
 const x=p[0]+(q[0]-p[0])*t,y=p[1]+(q[1]-p[1])*t;
 const svg=state.mode==='official' ? $('officialOverlay') : $('scene');
 const marker=svg.querySelector('.routeTraveler');
 const line=svg.querySelector('.journeyActive');
 if(marker){marker.setAttribute('cx',String(x));marker.setAttribute('cy',String(y));}
 if(line){line.setAttribute('x2',String(x));line.setAttribute('y2',String(y));}
}
function paintAlternatives(svg,pointOf){
 for(const option of journeyAlternatives()){
   const a=n(option.from),b=n(option.to);if(!a||!b)continue;
   const p=pointOf(option.from),q=pointOf(option.to);if(!p||!q)continue;
   $S('line',{x1:p[0],y1:p[1],x2:q[0],y2:q[1],class:'journeyAlternative','pointer-events':'none'},svg);
   $S('circle',{cx:q[0],cy:q[1],r:9,class:'journeyAlternativeNode','pointer-events':'none'},svg);
 }
}
function updateTraceBadge(){
 const badge=$('traceMapBadge'),r=state.result;
 if(!r?.found||!state.studyInteracted){badge.classList.add('hidden');return}
 badge.classList.remove('hidden');badge.dataset.kind='journey';
 const current=Math.min(Math.max(0,state.step),routeLegCount());
 const from=r.path[current],to=r.path[Math.min(current+1,routeLegCount())];
 $('traceMapKind').textContent=`경로 따라가기 · ${current}/${routeLegCount()}구간`;
 $('traceMapLabel').textContent=current===routeLegCount()?`${n(from)?.name||from} 도착`:`${n(from)?.name||from} → ${n(to)?.name||to}`;
 $('traceMapHint').textContent=current===routeLegCount()?'최종 경로를 모두 이동했습니다.':'인접한 두 장소 사이를 파란 선으로 이동합니다.';
}
function renderOfficialMap(){
 if(!state.graph)return;
 const svg=$('officialOverlay');svg.replaceChildren();
 const s=$('startSelect').value,g=$('goalSelect').value;
 const r=state.result;
 const path=r?.found ? r.path.filter(id=>OFFICIAL_POINTS[id]&&n(id)) : [];
 if(path.length){
   if(state.studyInteracted)paintAlternatives(svg,id=>OFFICIAL_POINTS[id]);
   paintJourney(svg,path,id=>OFFICIAL_POINTS[id],true);
 }
 const layer=$S('g',{},svg);
 for(const [id,coords] of Object.entries(OFFICIAL_POINTS)){
   const p=n(id);if(!p)continue;
   const [x,y]=coords;
   const start=(id===s && (state.officialPickStage>=1 || Boolean(r)));
   const goal=(id===g && (state.officialPickStage===2 || Boolean(r)));
   const via=path.includes(id);
   const focused=state.studyInteracted && r?.path?.[Math.min(state.step,routeLegCount())]===id;
   const underReview=journeyAlternatives().some(e=>e.to===id);
   const type=start?'start':goal?'goal':via?'via':'normal';
   const item=$S('g',{class:`officialPin ${type}${focused?' traceCurrent':''}${underReview?' traceNeighbor':''}`,'data-official-id':id,tabindex:0,role:'button','aria-label':`${p.name} (${id}) 선택`},layer);
   $S('circle',{cx:x,cy:y,r:17,class:'officialHit'},item);
   if(start||goal)$S('circle',{cx:x,cy:y,r:15,class:'officialHalo'},item);
   $S('circle',{cx:x,cy:y,r:9,class:'officialPinCore'},item);
   if(start||goal)$S('circle',{cx:x,cy:y,r:3.2,fill:'#fff'},item);
   $S('title',{},item,`${p.name} (${id}) — 클릭하여 선택`);
   item.addEventListener('click',event=>{event.stopPropagation();pickOfficialPlace(id)});
   item.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();pickOfficialPlace(id)}});
 }
 const title=$('officialPickTitle'),detail=$('officialPickDetail');
 if(state.officialPickStage===1){
   title.textContent=`출발: ${n(s)?.name||s}`;
   detail.textContent='이제 도착할 건물을 클릭하세요.';
 }else if(state.officialPickStage===2 && r?.found){
   title.textContent=`${n(s)?.name||s} → ${n(g)?.name||g}`;
   detail.textContent=`경로 계산 완료 · 이동 비용 ${fmt(r.distance)}m (교육용 추정값) · 다른 건물을 누르면 새 출발지로 선택됩니다.`;
 }else if(state.officialPickStage===2 && r && !r.found){
   title.textContent='이 두 장소를 연결하는 경로가 없습니다.';
   detail.textContent='다른 출발지 또는 도착지를 골라 주세요.';
 }else{
   title.textContent='① 출발할 건물을 클릭하세요';
   detail.textContent='② 도착할 건물을 선택하면 경로가 자동으로 계산됩니다.';
 }
 $('graphSummary').textContent='학교 조감도에서 건물을 클릭해 경로를 계산하세요 · 파란 점선은 교육용 그래프 경로';
}
async function pickOfficialPlace(id){
 if(state.mode!=='official'||!n(id))return;
 const s=$('startSelect'),g=$('goalSelect');
 if(state.officialPickStage!==1){
   stop();s.value=id;state.officialPickStage=1;
   state.result=null;state.step=-1;state.studyInteracted=false;renderResult();renderStep();renderOfficialMap();
   return;
 }
 if(s.value===id){toast('출발지와 다른 건물을 도착지로 선택해 주세요.');return}
 g.value=id;state.officialPickStage=2;
 renderOfficialMap();
 await calculate();
}
function draw(){
 if(state.mode==='official'){renderOfficialMap();return}
 if(!state.graph)return;
 const root=$('scene');root.replaceChildren();background(root);
 const graph=state.graph,result=state.result;
 const path=result?.found?result.path:[];
 const pathEdge=new Set(path.slice(1).map((id,i)=>[id,path[i]].sort().join('|')));
 const edgeLayer=$S('g',{'aria-label':'장소 사이 연결'},root);
 for(const e of graph.edges){
   const a=n(e.source),b=n(e.target);if(!a||!b)continue;
   const [ax,ay]=mapXY(a),[bx,by]=mapXY(b);
   if(state.mode==='graph'){
      const along=pathEdge.has([e.source,e.target].sort().join('|'));
      $S('line',{x1:ax,y1:ay,x2:bx,y2:by,class:'outlineGraph',stroke:along?'#8fb7dd':'#b6c8da','stroke-width':along?3.5:1.8},edgeLayer);
      if(Math.hypot(bx-ax,by-ay)>50&&state.zoom.w<1150)
        $S('text',{x:(ax+bx)/2+(by-ay)/15,y:(ay+by)/2-(bx-ax)/15,'text-anchor':'middle',class:'distanceText'},edgeLayer,fmt(e.distance));
   }
 }
 if(state.studyInteracted&&result?.found)paintAlternatives(root,id=>mapXY(n(id)));
 if(path.length)paintJourney(root,path,id=>mapXY(n(id)));
 const pinLayer=$S('g',{},root),started=$('startSelect').value,goal=$('goalSelect').value;
 const journeyCurrent=state.studyInteracted&&result?.found?path[Math.min(state.step,path.length-1)]:null;
 const alternateTargets=new Set(journeyAlternatives().map(x=>x.to));
 for(const p of graph.nodes){
   const [x,y]=mapXY(p),core=p.id===started?'#297bcf':p.id===goal?'#e36d6a':COLORS[p.zone]||'#638599';
   const isStart=p.id===started,isGoal=p.id===goal,isCurrent=journeyCurrent===p.id,isSelected=state.selected===p.id;
   let fill='#fff',stroke=core,r=state.mode==='graph'?8:7;
   if(alternateTargets.has(p.id)){fill='#fff4d9';stroke='#c59632'}
   if(isCurrent){fill='#237cd4';stroke='#fff';r=13;
     $S('circle',{cx:x,cy:y,r:22,class:'traceNodePulse','pointer-events':'none'},pinLayer);
   }
   if(isStart||isGoal){fill=core;stroke='#fff';r=isCurrent?13:11}
   if(isSelected)$S('circle',{cx:x,cy:y,r:20,fill:'#81c5ff',opacity:.4},pinLayer);
   const g=$S('g',{class:`point${state.mode==='graph'?' graphPoint':''}${isCurrent||isStart||isGoal?' graphActive':''}`,'data-id':p.id,role:'button',tabindex:'0','aria-label':`${p.name} ${p.id}`},pinLayer);
   $S('circle',{cx:x,cy:y,r:r+7,fill:'transparent'},g);
   $S('circle',{cx:x,cy:y,r,fill,stroke,'stroke-width':2.8,class:'pinCore'},g);
   if((isStart||isGoal)&&state.mode==='map')$S('circle',{cx:x,cy:y,r:3,fill:'#fff'},g);
   if(state.mode==='graph'){
     // In graph mode the label appears only for the current/start/goal node
     // or when hovered/focused. Do not leave all visited node IDs on screen.
     $S('text',{x:x+11,y:y-12,class:'pinLabel graphNodeLabel',fill:core},g,p.id);
   }
   $S('title',{},g,`${p.name} · ${p.id}`);
   g.addEventListener('click',evt=>{evt.stopPropagation();selectPlace(p.id,false)});
   g.addEventListener('keydown',evt=>{if(['Enter',' '].includes(evt.key)){evt.preventDefault();selectPlace(p.id,false)}});
 }
 if(state.mode==='map'&&typeof MapDesign!=='undefined')MapDesign.makeLabels(root,$S,graph.nodes,{zoomWidth:state.zoom.w,current:journeyCurrent,selected:state.selected,start:started,goal,path});
 if(state.mode==='graph')$S('text',{x:22,y:731,fill:'#849caf','font-size':13,'font-weight':700},root,`정점 ${graph.nodes.length}개 · 간선 ${graph.edges.length}개 · 가중치: 이동 비용`);
 $('graphSummary').textContent=`${graph.nodes.length}개 장소 · ${graph.edges.length}개 연결 구간`+(state.mode==='graph'?' · 정점에 마우스를 올리면 건물 번호를 볼 수 있습니다.':' · 교육용 간략화 지도 · 실제 보행로와 다를 수 있습니다.');
}
function centerOn(p){if(!p)return;const v=state.zoom;const [x,y]=mapXY(p),ww=Math.min(760,v.w);v.x=x-ww/2;v.y=y-ww*(988/1300)/2;v.w=ww;v.h=ww*(988/1300);svgView()}
function selectPlace(id,center){const p=n(id);if(!p)return;state.selected=id;if(center){setMode('map');centerOn(p)}draw();showPlaces();
 state.picked=id;$('popName').textContent=p.name;$('popCode').textContent=`${p.id} · ${ZONES[p.zone]||'캠퍼스'}`;
 const pos=p;const rect=$('mapFrame').getBoundingClientRect();
 const point=$('mapSvg').createSVGPoint();const [mapX,mapY]=mapXY(pos);point.x=mapX;point.y=mapY;
 const clientPoint=point.matrixTransform($('mapSvg').getScreenCTM());
 const px=clientPoint.x-rect.left,py=clientPoint.y-rect.top;
 $('placePopover').style.left=`${Math.min(Math.max(10,px+12),Math.max(10,rect.width-272))}px`;
 $('placePopover').style.top=`${Math.min(Math.max(8,py-70),Math.max(8,rect.height-165))}px`;
 $('placePopover').classList.remove('hidden');}
function clearSelected(){state.selected=null;$('placePopover').classList.add('hidden');draw();showPlaces()}
function bindCanvas(){const svg=$('mapSvg');
 svg.addEventListener('wheel',evt=>{if(state.mode==='official')return;evt.preventDefault();const at=mouseCoords(evt);zoom(evt.deltaY>0?1.11:.9,at)},{passive:false});
 svg.addEventListener('pointerdown',evt=>{if(evt.button!==0)return;const target=evt.target.closest?.('[data-id]');if(target && !state.moveMode){state.drag=null;return}if(state.moveMode && target){state.drag={kind:'node',id:target.dataset.id};}
 else{state.drag={kind:'pan',start:mouseCoords(evt)};svg.style.cursor='grabbing';}
 try{svg.setPointerCapture(evt.pointerId)}catch{}});
 svg.addEventListener('pointermove',evt=>{if(!state.drag)return;const p=mouseCoords(evt);if(state.drag.kind==='pan'){const v=state.zoom,prev=state.drag.start;v.x+=prev.x-p.x;v.y+=prev.y-p.y;svgView();}
 else if(state.moveMode){const pnt=n(state.drag.id);if(!pnt)return;const [ox,oy]=originalXY(p);pnt.x=Math.max(0,Math.min(1000,ox));pnt.y=Math.max(0,Math.min(760,oy));draw();}});
 const finishDrag=async()=>{svg.style.cursor='grab';if(state.drag?.kind==='node'){const p=n(state.drag.id);if(p){try{await edit({action:'move_place',id:p.id,x:p.x,y:p.y},false)}catch(e){toast(errText(e))}}}state.drag=null};
 svg.addEventListener('pointerup',finishDrag);
 svg.addEventListener('pointercancel',finishDrag);
 svg.addEventListener('lostpointercapture',()=>{if(state.drag?.kind==='pan'){state.drag=null;svg.style.cursor='grab'}});
 svg.addEventListener('click',evt=>{if(!evt.target.closest?.('[data-id]'))$('placePopover').classList.add('hidden')});
}
async function calculate(openResults = true){stop();const start=$('startSelect').value,goal=$('goalSelect').value,algorithm=$('algoSelect').value;
 if(!start||!goal){toast('출발지와 도착지를 선택하세요.');return}
 $('searchBtn').disabled=true;$('searchBtn').textContent='길을 찾고 있습니다…';
 try{if($('decisionLog')){$('decisionLog').dataset.filled='';$('decisionLog').replaceChildren()}state.result=await api('/api/search',{start,goal,algorithm});state.studyInteracted=false;document.body.classList.remove('isTracing');state.step=routeLegCount();renderResult();renderStep();draw();if(openResults)switchPane('results');if(!state.result.found)toast('두 장소를 연결하는 경로가 없습니다.');}
 catch(e){toast(errText(e))}finally{$('searchBtn').disabled=false;$('searchBtn').innerHTML='<span>⌕</span> 경로 찾기'}
}
function renderResult(){if(state.mode==='official')renderOfficialMap();const r=state.result;$('emptyResult').classList.toggle('hidden',!!r?.found);$('resultDetails').classList.toggle('hidden',!r?.found);if(!r?.found){$('emptyResult').textContent=r?'현재 연결된 길에서는 목적지까지 이동할 수 없습니다.':'출발지와 도착지를 선택해 경로를 찾아보세요.';return;}
 $('resultDistance').textContent=fmt(r.distance);$('resultTime').textContent=`약 ${Math.max(1,Math.ceil(r.distance/70))}분`;$('resultCount').textContent=`${r.path.length}곳`;
 $('routeChips').innerHTML=r.path.map((id,i)=>`<span class="routeChip" title="${esc(n(id)?.name||id)}">${esc(n(id)?.name||id)}</span>${i<r.path.length-1?'<span class="routeArrow">›</span>':''}`).join('');
 $('resultNote').textContent=r.algorithm==='BFS'?'너비 우선 탐색은 간선 수를 최소화합니다. 표시된 이동 거리가 최단 거리는 아닐 수 있습니다.': '이동 거리는 학습용 추정값입니다. 실제 보행 경로는 학교 공식 지도에서 확인하세요.';
}
function focusName(id){return n(id)?`${n(id).name} (${id})`:id||'—'}
function measure(value,metric){return Number.isFinite(value)?`${Number(value).toLocaleString('ko-KR',{maximumFractionDigits:1})}${metric==='hops'?'개':'m'}`:'아직 없음'}
function renderStep(){
 const r=state.result;
 if(!r?.found){
   $('stepCounter').textContent='0 / 0구간';$('visitedCounter').textContent='이동 준비';
   $('stepText').textContent='길찾기를 완료하면 최종 경로를 한 구간씩 이동하며 확인할 수 있습니다.';
   $('stepCurrentNode').textContent='—';$('decisionStatus').textContent='경로를 찾아주세요';
   $('progressFill').style.width='0%';$('stepSlider').value='0';$('stepSlider').max='0';
   $('watchBtn').disabled=true;document.body.classList.remove('isTracing');
   $('edgeDecision').classList.add('hidden');$('frontierList').replaceChildren();updateTraceBadge();draw();return;
 }
 $('watchBtn').disabled=false;
 document.body.classList.toggle('isTracing',state.studyInteracted);
 const legs=routeLegCount();state.step=Math.min(legs,Math.max(0,state.step));
 const i=state.step,path=r.path,finished= i>=legs;
 const from=path[i],to=path[Math.min(i+1,legs)];
 const totalDistance=path.slice(1).reduce((sum,id,index)=>sum+segmentDistance(path[index],id),0);
 const movedDistance=path.slice(1,i+1).reduce((sum,id,index)=>sum+segmentDistance(path[index],id),0);
 const currentEdgeDistance=finished?0:segmentDistance(from,to);
 const isPlaying=!!state.play;
 $('stepCounter').textContent=`${i} / ${legs}구간 완료`;
 $('visitedCounter').textContent=`${fmt(movedDistance)}m / ${fmt(totalDistance)}m`;
 $('stepSlider').max=String(legs);$('stepSlider').value=String(i);
 $('progressFill').style.width=`${legs?i/legs*100:100}%`;
 $('stepTag').textContent=finished?'도착':i===0&&!isPlaying?'출발':isPlaying?'이동 중':'다음 구간';
 $('decisionCard').dataset.kind=finished?'done':'journey';
 $('decisionStatus').textContent=finished?'도착지에 도착했습니다':isPlaying?'선택된 길을 따라 이동 중':'한 구간씩 확인해 보세요';
 $('stepCurrentNode').textContent=finished?`도착 · ${focusName(from)}`:`${focusName(from)} → ${focusName(to)}`;
 const alternatives=journeyAlternatives();
 const other=alternatives.length?` 갈림길 ${alternatives.length}곳은 이번 이동에 선택되지 않아 노란색으로 표시됩니다.`:'';
 $('stepText').textContent=finished?`모든 연결 구간을 통과했습니다. 전체 이동 비용은 ${fmt(totalDistance)}m입니다.`:
   `현재 연결: ${fmt(currentEdgeDistance)}m. 도착하면 누적 ${fmt(movedDistance+currentEdgeDistance)}m가 됩니다.${other}`;
 // Detailed algorithm decisions remain available as a separate, opt-in reference.
 const log=$('decisionLog');
 if(log&&!log.dataset.filled){
   log.innerHTML=r.steps.map((s,k)=>`<li><b>${k+1}.</b> ${esc(s.message)}</li>`).join('');
   log.dataset.filled='true';
 }
 $('edgeDecision').classList.add('hidden');
 $('frontierList').replaceChildren();
 $('watchBtn').textContent=i===legs?'▶ 출발지부터 경로 재생':'↺ 처음부터 다시 재생';
 updateTraceBadge();draw();
}
function stepTo(value,interacted=true){
 if(!state.result?.found)return;
 state.studyInteracted=interacted||state.studyInteracted;
 state.step=Math.min(routeLegCount(),Math.max(0,Math.round(value)));
 state.motionProgress=0;
 renderStep();
}
function stop(){
 window.GraphWayAudio?.journeyStop();
 if(state.play){cancelAnimationFrame(state.play.frame);state.play=null}
 state.animateLeg=false;
 $('playBtn').textContent='▶ 재생';
 if(state.result?.found&&state.studyInteracted)renderStep();
}
function autoplay(fromStart=false){
 if(!state.result?.found)return;
 if(state.play&&!fromStart){stop();return}
 stop();
 const legs=routeLegCount();
 if(fromStart||state.step>=legs)stepTo(0);
 state.studyInteracted=true;
 if(!legs){renderStep();return}
 state.animateLeg=true;
 const player={frame:0,last:null,hold:0};
 state.play=player;
 window.GraphWayAudio?.journeyStart();
 $('playBtn').textContent='Ⅱ 일시정지';
 renderStep();
 const tick=now=>{
   if(state.play!==player)return;
   const delta=player.last===null?0:Math.min(100,Math.max(0,now-player.last));
   player.last=now;
   if(player.hold>0){player.hold-=delta;player.frame=requestAnimationFrame(tick);return}
   const duration=Number($('playSpeed').value)||1400;
   state.motionProgress=Math.min(1,state.motionProgress+delta/duration);
   window.GraphWayAudio?.journeyProgress(state.step,state.motionProgress);
   moveTraveler();
   if(state.motionProgress>=1){
     window.GraphWayAudio?.journeyArrive(state.step+1,legs);
     state.step++;
     state.motionProgress=0;
     player.hold=230;
     renderStep();
     if(state.step>=legs){stop();return}
   }
   player.frame=requestAnimationFrame(tick);
 };
 player.frame=requestAnimationFrame(tick);
}
async function edit(data,withToast=true){const res=await api('/api/edit',data);const beforeA=$('startSelect').value,beforeB=$('goalSelect').value;
 state.graph=res.graph;state.result=null;state.step=-1;state.studyInteracted=false;setupChoices(n(beforeA)?beforeA:null,n(beforeB)?beforeB:null);clearSelected();renderResult();renderStep();showPlaces();draw();
 if(withToast)toast('지도에 변경 사항을 저장했습니다.');return res}
function openModal(title,html){stop();$('modalTitle').textContent=title;$('modalBody').innerHTML=html;$('modalBackdrop').classList.remove('hidden')}
function closeModal(){$('modalBackdrop').classList.add('hidden');state.moveMode=false}
function modalTabs(active){return `<div class="modalSubtabs"><button data-tab="places" class="${active==='places'?'active':''}">장소 추가·수정</button><button data-tab="roads" class="${active==='roads'?'active':''}">연결된 길 관리</button><button data-tab="placement" class="${active==='placement'?'active':''}">지도 위치 조정</button></div>`}
function manageModal(tab='places'){state.modalTab=tab;
 if(tab==='places'){
   openModal('장소와 길 관리',modalTabs(tab)+`<h3>새 장소 추가</h3><p>지도에 표시할 장소의 이름을 입력하세요. 번호는 다른 장소와 구별하는 표식입니다.</p><form id="addPlaceForm" class="formGrid"><label>장소 이름<input id="placeNameIn" required maxlength="80" placeholder="예: 음악관"></label><label>장소 번호<input id="placeIdIn" required maxlength="24" placeholder="예: G1"></label><div class="full"><button class="modalBtn" type="submit">장소 추가</button></div></form><h3>장소 이름 변경 또는 삭제</h3><div class="formGrid"><label>관리할 장소<select id="placePick">${nodeOpts()}</select></label><label>변경할 이름<input id="renameIn" maxlength="80" placeholder="새 이름"></label><div class="full"><button id="renameBtn" class="modalBtn modalSecondary">이름 바꾸기</button><button id="deletePlaceBtn" class="modalBtn dangerBtn">이 장소 삭제</button></div></div>`);
   $('addPlaceForm').onsubmit=async evt=>{evt.preventDefault();try{const id=$('placeIdIn').value,name=$('placeNameIn').value;await edit({action:'add_place',id,name,x:500,y:380});manageModal('placement')}catch(e){toast(errText(e))}};
   $('renameBtn').onclick=async()=>{try{await edit({action:'rename_place',id:$('placePick').value,name:$('renameIn').value});manageModal('places')}catch(e){toast(errText(e))}};
   $('deletePlaceBtn').onclick=async()=>{const id=$('placePick').value;if(!confirm(`${n(id)?.name||id} 장소와 이곳에 연결된 길을 삭제할까요?`))return;try{await edit({action:'delete_place',id});manageModal('places')}catch(e){toast(errText(e))}};
 }else if(tab==='roads'){
   openModal('장소와 길 관리',modalTabs(tab)+`<h3>두 장소를 잇는 길 추가</h3><p>길의 거리에는 두 장소 사이의 이동 비용을 입력합니다. 기존 길을 다시 연결하면 거리를 바꿀 수 있습니다.</p><form id="roadForm" class="formGrid"><label>첫 번째 장소<select id="roadA">${nodeOpts()}</select></label><label>두 번째 장소<select id="roadB">${nodeOpts()}</select></label><label class="full">이동 거리 또는 비용<input id="roadCost" type="number" min="1" max="100000" step="1" required value="80" placeholder="예: 80"></label><div class="full"><button type="submit" class="modalBtn">길 연결 · 거리 적용</button><button type="button" id="roadDelete" class="modalBtn dangerBtn">두 장소 사이의 길 삭제</button></div></form><p>장소가 연결되어 있으면 다익스트라와 A*는 입력한 가중치를 합산하여 경로를 계산합니다.</p>`);
   $('roadB').selectedIndex=Math.min(1,$('roadB').options.length-1);
   $('roadForm').onsubmit=async evt=>{evt.preventDefault();try{await edit({action:'connect',source:$('roadA').value,target:$('roadB').value,distance:Number($('roadCost').value)});manageModal('roads')}catch(e){toast(errText(e))}};
   $('roadDelete').onclick=async()=>{if(!confirm('두 장소를 잇는 길을 삭제할까요?'))return;try{await edit({action:'disconnect',source:$('roadA').value,target:$('roadB').value});manageModal('roads')}catch(e){toast(errText(e))}};
 }else{
   openModal('장소와 길 관리',modalTabs(tab)+`<h3>장소 위치를 직접 옮기기</h3><p>위치를 바꿀 장소를 선택해 지도에서 드래그하세요. 드래그를 놓으면 변경 사항이 자동 저장됩니다.</p><button id="placeMoveBtn" class="modalBtn">지도에서 위치 조정 시작</button><p>위치 조정은 지도와 그래프 표시의 배치에만 영향을 줍니다. 연결된 길과 이동 거리는 별도로 수정할 수 있습니다.</p>`);
   $('placeMoveBtn').onclick=()=>{closeModal();state.moveMode=true;setMode('graph');toast('장소를 드래그해서 옮기세요. 이동이 끝나면 위치가 저장됩니다.')};
 }
 document.querySelectorAll('[data-tab]').forEach(btn=>btn.onclick=()=>manageModal(btn.dataset.tab));
}
function guideModal(){openModal('GraphWay 이용 방법',`<div class="guide"><h3>① 공식 지도에서 건물을 직접 선택해요</h3><p>‘공식 지도에서 길찾기’ 탭에서 학교 조감도의 첫 번째 건물을 클릭하면 출발지로, 두 번째 건물을 클릭하면 도착지로 정해집니다. 선택을 마치면 최단경로가 자동으로 계산됩니다. 다시 선택 버튼으로 새 경로를 찾을 수 있습니다.</p><h3>② 목록에서 출발지와 도착지를 선택해요</h3><p>왼쪽에서 건물을 선택하거나 지도 위의 건물 표시를 클릭한 뒤 ‘여기서 출발’ 또는 ‘여기로 도착’을 누르세요.</p><h3>② 경로를 찾아요</h3><p>‘경로 찾기’를 누르면 이동 순서가 표시됩니다. 지도에서 파란색 선을 따라가며 각 장소의 연결을 확인할 수 있습니다.</p><h3>③ 알고리즘을 따라가요</h3><p>‘그래프 학습’으로 전환하고, 왼쪽 학습 패널의 재생 버튼이나 이전·다음 버튼을 사용해 탐색 과정을 살펴보세요.</p><h3>④ 건물과 길을 바꿔 볼 수 있어요</h3><p>‘장소와 길 관리’에서 새로운 장소를 만들고 길을 연결해 보세요. 변경 사항은 컴퓨터에 저장됩니다.</p><h3>지도 안내</h3><p>캠퍼스 건물 이름과 구역은 국립순천대학교 공식 안내도에 따라 표기했습니다. 학습 지도에 표시된 연결과 이동 거리는 교육용 추정값이며, 실제 통행 여부와 보행거리를 보장하지 않습니다.</p><a href="https://www.scnu.ac.kr/campusmap.jsp" target="_blank" rel="noopener noreferrer" class="smallPrimary">학교 공식 캠퍼스 길찾기 ↗</a></div>`)}
async function compareModal(){const a=$('startSelect').value,b=$('goalSelect').value;try{const [d,astar,bfs]=await Promise.all(['Dijkstra','A*','BFS'].map(algorithm=>api('/api/search',{start:a,goal:b,algorithm})));
 const rows=[['다익스트라',d],['A*',astar],['너비 우선 탐색',bfs]];
 openModal('알고리즘 결과 비교',`<p><strong>${esc(n(a)?.name||a)} → ${esc(n(b)?.name||b)}</strong> 경로에서 세 알고리즘의 특징을 비교합니다.</p><table class="compareTable"><thead><tr><th>탐색 방법</th><th>이동 비용</th><th>방문 장소</th><th>경유</th></tr></thead><tbody>${rows.map(([name,r])=>`<tr><td><b>${esc(name)}</b></td><td>${r.distance===null?'연결 없음':fmt(r.distance)}</td><td>${r.visit_order.length}곳</td><td>${Math.max(0,r.path.length-1)}구간</td></tr>`).join('')}</tbody></table><p>다익스트라와 A*는 가중치 기준 최단경로를 찾습니다. 너비 우선 탐색(BFS)은 간선의 개수가 가장 적은 경로를 찾으므로 거리 합계가 다를 수 있습니다.</p>`);
 }catch(e){toast(errText(e))}}
function exportImage(){
 if(state.mode==='official'){toast('지도 모드 또는 그래프 학습 모드에서 그림을 저장할 수 있습니다.');return}
 const original=$('mapSvg'),copy=original.cloneNode(true);
 copy.setAttribute('xmlns',NS);copy.setAttribute('width','2000');copy.setAttribute('height','1520');
 const style=$S('style',{},null,`
  .building{fill:#fefefe;stroke:#b6cbbd;stroke-width:2}.buildingAcademic{fill:#dce9f1;stroke:#a4c4d6}.buildingDorm{fill:#efded8;stroke:#cfbbb1}.buildingOther{fill:#f0e3d3;stroke:#d5bfa1}
  .mapRoad{fill:none;stroke:#fff;stroke-width:25;stroke-linecap:round;stroke-linejoin:round}.mapRoadEdge{fill:none;stroke:#c5d6c8;stroke-width:28;stroke-linecap:round;stroke-linejoin:round}
  .routeGlow{stroke:#fff;stroke-width:12;fill:none;stroke-linecap:round;stroke-linejoin:round}.routeMain{stroke:#207ce6;stroke-width:7;fill:none;stroke-linecap:round;stroke-linejoin:round}
  .outlineGraph{stroke:#b6c8da;stroke-width:2;stroke-linecap:round}.exploreEdge{stroke:#e9b657;stroke-width:5}.pinLabel{font-family:Malgun Gothic,sans-serif;font-weight:800;font-size:12px;paint-order:stroke;stroke:#fff;stroke-width:3px;stroke-linejoin:round}
  .zoneLabel{font:800 18px sans-serif;fill:#547a7c;opacity:.4}.distanceText{font:11px sans-serif;paint-order:stroke;stroke:#fff;stroke-width:4px;fill:#67819d}.footprintLabels{font:11px sans-serif;fill:#93a39e;font-weight:700}
 `);
 const svgStyleRules=[];
 for(const sheet of document.styleSheets){
   try {for(const rule of sheet.cssRules){
     if(/campus|gw[A-Z]|journey|route|outlineGraph|pinCore|pinLabel|distanceText|footprintLabels|officialPin|point|traceNodePulse|zoneLabel/.test(rule.cssText))svgStyleRules.push(rule.cssText);
   }} catch{} // Ignore cross-origin sheets; packaged app styles are same-origin.
 }
 style.textContent += '\n' + svgStyleRules.join('\n');
 copy.insertBefore(style,copy.firstChild);
 const xml=new XMLSerializer().serializeToString(copy);const blob=new Blob([xml],{type:'image/svg+xml;charset=utf-8'});
 const href=URL.createObjectURL(blob);const img=new Image();img.onload=()=>{
   const canvas=document.createElement('canvas');canvas.width=2400;canvas.height=1824;
   const ctx=canvas.getContext('2d');ctx.fillStyle='#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);
   URL.revokeObjectURL(href);canvas.toBlob(output=>{
      if(!output){toast('그림을 저장하지 못했습니다.');return}const dl=URL.createObjectURL(output);
      const link=document.createElement('a');link.href=dl;link.download='GraphWay_캠퍼스지도.png';link.click();setTimeout(()=>URL.revokeObjectURL(dl),1000);
   },'image/png');
 };
 img.onerror=()=>{URL.revokeObjectURL(href);toast('그림을 저장하지 못했습니다.')};img.src=href;
 $('fileMenu').classList.add('hidden');
}
async function resetMap(){if(!confirm('변경한 장소와 길을 지우고 학교 지도를 처음 상태로 되돌릴까요?'))return;try{await edit({action:'reset'});$('fileMenu').classList.add('hidden');fit();toast('학교 지도를 복원했습니다.')}catch(e){toast(errText(e))}}
async function importFile(file){if(!file)return;try{if(file.size>2_000_000)throw Error('2MB 이하의 지도 파일만 불러올 수 있습니다.');const json=JSON.parse(await file.text());if(!confirm('현재 지도를 불러온 지도로 바꿀까요?'))return;await edit({action:'import',graph:json});toast('저장된 지도를 불러왔습니다.')}catch(e){toast(`지도를 불러오지 못했습니다. ${errText(e)}`)}finally{$('importInput').value=''}}
async function init(){try{const data=await api('/api/state');state.graph=data.graph;setupChoices(data.start,data.goal);showPlaces();fit();draw();renderResult();renderStep();await calculate(false)}catch(e){toast('지도를 열지 못했습니다. '+errText(e))}}
function wire(){
 $('mapTab').onclick=()=>setMode('map');$('graphTab').onclick=()=>setMode('graph');$('officialTab').onclick=()=>setMode('official');
 $('zoomInBtn').onclick=()=>zoom(.8);$('zoomOutBtn').onclick=()=>zoom(1.25);$('fitBtn').onclick=fit;
 $('searchBtn').onclick=()=>{state.officialPickStage=2;calculate()};$('startSelect').onchange=()=>{state.officialPickStage=2;$('placePopover').classList.add('hidden');draw()};$('goalSelect').onchange=()=>{state.officialPickStage=2;$('placePopover').classList.add('hidden');draw()};
 $('swapBtn').onclick=()=>{const a=$('startSelect').value;$('startSelect').value=$('goalSelect').value;$('goalSelect').value=a;draw();calculate()};
 $('algoSelect').onchange=()=>{$('algoDescription').textContent=DESCRIPTIONS[$('algoSelect').value];calculate()};
 $('algoHelp').onclick=()=>guideModal();
 $('searchInput').addEventListener('input',()=>{
   clearTimeout(searchTimer);
   ++searchRequestId;
   searchState.courses=[];searchState.total=0;
   searchState.loading=Boolean($('searchInput').value.trim());
   showPlaces();
   searchTimer=setTimeout(searchAll,180);
 });
 $('searchInput').addEventListener('keydown',event=>{
   if(event.key==='Enter'){event.preventDefault();clearTimeout(searchTimer);searchAll();}
 });
 $('popCloseBtn').onclick=()=>clearSelected();$('popStartBtn').onclick=()=>{if(state.picked){$('startSelect').value=state.picked;$('placePopover').classList.add('hidden');draw()}};
 $('popGoalBtn').onclick=()=>{if(state.picked){$('goalSelect').value=state.picked;$('placePopover').classList.add('hidden');draw()}};
 $('firstBtn').onclick=()=>{stop();stepTo(0)};$('prevBtn').onclick=()=>{stop();stepTo(state.step-1)};$('nextBtn').onclick=()=>{stop();stepTo(state.step+1)};$('playBtn').onclick=()=>autoplay();
 $('watchBtn').onclick=()=>{stop();autoplay(true);$('resultsPane').scrollTo({top:0,behavior:'smooth'})};
 $('stepSlider').addEventListener('input',event=>{stop();stepTo(Number(event.target.value))});
 $('playSpeed').onchange=()=>{};
 $('panelToggleBtn').onclick=()=>switchPane($('resultsPane').classList.contains('hidden')?'results':'search');
 $('backToSearchBtn').onclick=()=>switchPane('search');
 $('guideBtn').onclick=guideModal;$('manageBtn').onclick=()=>manageModal('places');$('compareBtn').onclick=compareModal;
 $('modalClose').onclick=closeModal;$('modalBackdrop').onclick=evt=>{if(evt.target.id==='modalBackdrop')closeModal()};
 $('fileMenuBtn').onclick=()=>{const drop=$('fileMenu');drop.classList.toggle('hidden');$('fileMenuBtn').setAttribute('aria-expanded',String(!drop.classList.contains('hidden')))};
 $('imageExportBtn').onclick=exportImage;
 $('backupBtn').onclick=()=>{window.location.href='/api/export';$('fileMenu').classList.add('hidden')};
 $('restoreBtn').onclick=()=>{$('importInput').click();$('fileMenu').classList.add('hidden')};$('importInput').onchange=evt=>importFile(evt.target.files[0]);$('resetBtn').onclick=resetMap;
 document.addEventListener('click',evt=>{if(!evt.target.closest('.menuwrap'))$('fileMenu').classList.add('hidden')});
 document.addEventListener('keydown',evt=>{if(evt.key==='Escape'){closeModal();stop();$('placePopover').classList.add('hidden');state.moveMode=false}
 if(evt.key==='F6'){evt.preventDefault();stop();stepTo(state.step+(evt.shiftKey?-1:1))}});
 $('officialImage').onerror=()=>{$('officialImageCanvas').classList.add('hidden');$('officialImageError').classList.remove('hidden')};
 $('officialImage').onload=()=>{$('officialImageCanvas').classList.remove('hidden');$('officialImageError').classList.add('hidden');renderOfficialMap()};
 $('officialClearBtn').onclick=()=>{state.officialPickStage=0;state.result=null;state.step=-1;state.studyInteracted=false;stop();renderResult();renderStep();renderOfficialMap()};
 $('officialImageCanvas').addEventListener('click',event=>{
   if(event.target.closest?.('[data-official-id]'))return;
   const rect=$('officialOverlay').getBoundingClientRect();
   const x=(event.clientX-rect.left)/rect.width*1000,y=(event.clientY-rect.top)/rect.height*570;
   let closest=null,best=24;
   for(const [id,[px,py]] of Object.entries(OFFICIAL_POINTS)){
     if(!n(id))continue;
     const distance=Math.hypot(x-px,y-py);
     if(distance<best){best=distance;closest=id}
   }
   if(closest)pickOfficialPlace(closest);
 });
 bindCanvas();}
wire();init();

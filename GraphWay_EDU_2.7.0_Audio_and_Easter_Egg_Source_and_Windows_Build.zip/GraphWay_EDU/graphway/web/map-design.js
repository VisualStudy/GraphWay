/* GraphWay campus schematic renderer. Visual coordinates never modify graph data. */
'use strict';
const MapDesign = (() => {
  const WIDTH = 1300, HEIGHT = 988;
  const SCALE = 1.22, OFFSET_X = 35, OFFSET_Y = 28;
  const NON_BUILDINGS = new Set(['A14','A15','A16','A18','A19','C6','F3']);
  const widthFor = p => p.zone === 'D' ? 53 : p.zone === 'E' ? 48 : 49;
  const heightFor = p => p.zone === 'D' ? 34 : 32;
  let cachedSignature = '', positions = new Map();
  const base = p => [OFFSET_X + p.x * SCALE, OFFSET_Y + p.y * SCALE];
  const rectsIntersect = (a, b, pad = 1) => !(a.x + a.w + pad <= b.x || b.x + b.w + pad <= a.x || a.y + a.h + pad <= b.y || b.y + b.h + pad <= a.y);
  const inBounds = r => r.x >= 10 && r.y >= 12 && r.x + r.w <= WIDTH-12 && r.y+r.h <= HEIGHT-12;
  function layout(nodes) {
    const signature = nodes.map(p => `${p.id}|${p.name}|${p.zone}|${p.x}|${p.y}`).join(';');
    if (signature === cachedSignature) return positions;
    cachedSignature = signature;
    const ordered = [...nodes].sort((a,b) => a.id.localeCompare(b.id, 'en', {numeric:true}));
    const coords = new Map(ordered.map(p=>[p.id,base(p)]));
    const buildings = ordered.filter(p=>!NON_BUILDINGS.has(p.id));
    // Repel rectangles only in screen coordinates. The original graph and edges remain untouched.
    for (let tick=0;tick<90;tick++) {
      let moves=0;
      for(let i=0;i<buildings.length;i++)for(let j=i+1;j<buildings.length;j++){
        const a=buildings[i],b=buildings[j],pa=coords.get(a.id),pb=coords.get(b.id);
        const minX=(widthFor(a)+widthFor(b))/2+13, minY=(heightFor(a)+heightFor(b))/2+13;
        const dx=pb[0]-pa[0],dy=pb[1]-pa[1];
        const overlapX=minX-Math.abs(dx),overlapY=minY-Math.abs(dy);
        if(overlapX<=0||overlapY<=0)continue;
        const signX=dx===0?(a.id.localeCompare(b.id)<0?1:-1):Math.sign(dx);
        const signY=dy===0?(a.id.localeCompare(b.id)<0?1:-1):Math.sign(dy);
        if(overlapX<overlapY){const push=Math.min(8,overlapX/2+.25);pa[0]-=signX*push;pb[0]+=signX*push;}
        else{const push=Math.min(8,overlapY/2+.25);pa[1]-=signY*push;pb[1]+=signY*push;}
        moves++;
      }
      // Prevent labels and footprints from leaving the canvas, but avoid artificial drift.
      for(const p of buildings){const pos=coords.get(p.id);
        pos[0]=Math.min(WIDTH-48,Math.max(48,pos[0]));
        pos[1]=Math.min(HEIGHT-45,Math.max(45,pos[1]));
      }
      if(!moves)break;
    }
    positions=coords;
    return positions;
  }
  const point = (p, nodes) => layout(nodes).get(p.id) || base(p);
  function paintBackground(svg, add, nodes) {
    add('rect',{x:0,y:0,width:WIDTH,height:HEIGHT,fill:'#e8f0e9'},svg);
    add('path',{d:'M0 0H1300V180Q1160 132 1040 160L670 20H0Z',fill:'#d8e9dc'},svg);
    add('path',{d:'M0 280Q150 320 190 550L115 920L0 988Z',fill:'#d5e6d8'},svg);
    add('path',{d:'M850 680Q1035 585 1300 600V988H800Z',fill:'#d6e8dc'},svg);
    add('path',{d:'M200 870Q410 810 630 938L680 988H140Z',fill:'#dbeadb'},svg);
    const roads=add('g',{transform:`translate(${OFFSET_X} ${OFFSET_Y}) scale(${SCALE})`,class:'campusRoadLayer','aria-label':'교육용 간략화 도로'},svg);
    const main=[
      'M438 715 L438 675 L350 613 L307 575 L308 470 L354 410 L455 388 L615 385 L750 403 L915 410',
      'M350 613 L262 585 L228 520 L234 427 L271 336 L310 240 L349 160',
      'M615 385 L637 304 L700 236 L757 180 L815 111',
      'M455 388 L475 315 L530 240 L610 176 L648 95',
      'M750 403 L790 485 L842 563 L860 640'
    ];
    const walks=[
      'M175 415 L232 427 L318 420 L364 428 L453 388',
      'M269 334 L350 310 L430 276 L532 288 L615 385',
      'M349 160 L424 142 L522 163 L610 176 L757 180',
      'M610 176 L709 175 L756 182 L900 193',
      'M750 403 L782 354 L795 284 L865 278 L911 325',
      'M842 563 L738 563 L600 589 L438 715',
      'M238 520 L151 462 L90 455',
      'M364 428 L364 515 L305 570',
      'M815 111 L791 142 L865 253 L911 325',
      'M435 278 L349 185 L272 188'
    ];
    for(const d of main){add('path',{d,class:'campusRoadBorder'},roads);add('path',{d,class:'campusMainRoad'},roads)}
    for(const d of walks){add('path',{d,class:'campusWalkwayBorder'},roads);add('path',{d,class:'campusWalkway'},roads)}
    const marks=add('g',{transform:`translate(${OFFSET_X} ${OFFSET_Y}) scale(${SCALE})`,class:'landmarkLayer'},svg);
    add('ellipse',{cx:364,cy:428,rx:108,ry:61,fill:'#dc9e7b',stroke:'#fff5e9','stroke-width':3,transform:'rotate(-10 364 428)'},marks);
    add('ellipse',{cx:364,cy:428,rx:91,ry:47,fill:'#91cda5',stroke:'#fff5e9','stroke-width':2,transform:'rotate(-10 364 428)'},marks);
    add('text',{x:323,y:435,class:'gwLandmark'},marks,'운동장');
    // Illustration footprints use the SAME visual coordinates as the pins.
    const buildings=add('g',{class:'campusBuildings'},svg);
    for(const p of nodes){if(NON_BUILDINGS.has(p.id))continue;
      const [x,y]=point(p,nodes),w=widthFor(p),h=heightFor(p);
      add('rect',{x:x-w/2,y:y-h/2,width:w,height:h,rx:2.6,class:`gwFootprint gwZone${p.zone}`,'pointer-events':'none'},buildings);
    }
    const small=add('g',{class:'campusStaticAnnotations'},svg);
    const area=(x,y,w,text)=>{
      add('rect',{x,y:y-22,width:w,height:33,rx:6,class:'gwAreaLabelBg'},small);
      add('text',{x:x+10,y,class:'gwAreaLabelText'},small,text);
    };
    area(53,135,139,'서쪽 출입구');
    area(1002,878,147,'중앙로 · 정문');
    add('text',{x:66,y:HEIGHT-38,class:'gwRoadCaption'},small,'국립순천대학교 · 교육용 간략화 지도');
  }
  function makeLabels(svg, add, nodes, opts={}) {
    const map = layout(nodes), root=add('g',{class:'campusLabels','aria-hidden':'true','pointer-events':'none'},svg);
    const zoomWidth=opts.zoomWidth||WIDTH;
    const scale=Math.min(2,Math.max(1,zoomWidth/900));
    const badgeW=35*scale,badgeH=20*scale;
    const used=[];
    const bounds=[];
    const inMap= r=> inBounds(r);
    const priority = id => id===opts.current||id===opts.selected||id===opts.start||id===opts.goal||opts.path?.includes(id);
    const ordered=[...nodes].sort((a,b)=>Number(priority(b.id))-Number(priority(a.id))||a.id.localeCompare(b.id,'en',{numeric:true}));
    function chooseBox(cx,cy,w,h,existing,weight=1){
      const offsets=[[-w/2,-h-19],[19,-h/2],[-w-19,-h/2],[-w/2,19],[21,15],[-w-21,15],[20,-h-20],[-w-20,-h-20]];
      let best=null,bestScore=Infinity;
      for(const [ox,oy] of offsets){const r={x:cx+ox,y:cy+oy,w,h};if(!inMap(r))continue;
        let score=0;
        for(const b of existing)if(rectsIntersect(r,b,2)){
          const overlap=(Math.min(r.x+r.w,b.x+b.w)-Math.max(r.x,b.x))*(Math.min(r.y+r.h,b.y+b.h)-Math.max(r.y,b.y));
          score+=Math.max(0,overlap)*weight;
        }
        score+=Math.hypot(ox,oy)*.04;
        if(score<bestScore){bestScore=score;best=r}
      }
      return [best,bestScore];
    }
    // Every location code is visible, while larger names appear when there is room.
    for(const p of ordered){const [x,y]=map.get(p.id),flag=priority(p.id);
      const [box,score]=chooseBox(x,y,badgeW,badgeH,used);
      if(!box)continue;
      used.push(box); bounds.push({id:p.id,box,score});
      const g=add('g',{class:`gwCodeTag${flag?' gwTagPriority':''}`},root);
      add('path',{d:`M${x} ${y}L${Math.min(box.x+box.w,Math.max(box.x,x))} ${Math.min(box.y+box.h,Math.max(box.y,y))}`,class:'gwLabelLeader'},g);
      add('rect',{x:box.x,y:box.y,width:box.w,height:box.h,rx:6,class:'gwCodeBg'},g);
      add('text',{x:box.x+box.w/2,y:box.y+box.h/2+5*scale,'text-anchor':'middle',class:'gwCodeText','font-size':13*scale},g,p.id);
    }
    const preferred=new Set(['A19','A15','C1','D2','E1','E4','B1']);
    // Do not flood the full-campus overview. Expanded views show other building names.
    for(const p of ordered){const important=priority(p.id),named=important||preferred.has(p.id)||zoomWidth<=810;
      if(!named)continue;
      const [x,y]=map.get(p.id),font=important?15:13;
      const w=Math.min(245,Math.max(58,p.name.length*(font*.91)+17));
      const h=25;
      const [r,score]=chooseBox(x,y,w,h,used.concat(bounds.map(b=>b.box)),4);
      if(!r||score>45 && !important)continue;
      // For highlighted places keep a name available even when the vicinity is dense.
      if(score>180 && important)continue;
      const g=add('g',{class:`gwNameTag${important?' gwNamePriority':''}`},root);
      add('rect',{x:r.x,y:r.y,width:r.w,height:r.h,rx:7,class:'gwNameBg'},g);
      add('text',{x:r.x+9,y:r.y+17,class:'gwNameText','font-size':font},g,p.name);
      used.push(r);
    }
    return bounds;
  }
  return Object.freeze({ WIDTH, HEIGHT, NON_BUILDINGS, layout, point, paintBackground, makeLabels, base });
})();

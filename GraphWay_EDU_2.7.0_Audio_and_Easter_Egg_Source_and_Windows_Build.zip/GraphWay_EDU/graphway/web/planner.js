'use strict';
// The timetable is a separate screen. Campus navigation continues to use app.js.
const planner = {
  semester: '2026-2', courses: [],
  searchItems: [], searchTimer: null, searchRequest: 0, editorSource: 'manual',
  currentScreen: 'map', loaded: false
};
const plannerDays = ['월', '화', '수', '목', '금', '토'];
const p$ = id => document.getElementById(id);
const pEsc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));

function showScreen(page) {
  planner.currentScreen = page;
  p$('mapHeader').classList.toggle('hidden', page !== 'map');
  p$('mapWorkspace').classList.toggle('hidden', page !== 'map');
  p$('timetableScreen').classList.toggle('hidden', page !== 'timetable');
  for (const [id, name] of [['mainMapBtn','map'],['mainTimetableBtn','timetable']]) {
    const button = p$(id), active = page === name;
    button.classList.toggle('active', active);
    if (active) button.setAttribute('aria-current','page');
    else button.removeAttribute('aria-current');
  }
  if (page === 'map') { if (typeof draw === 'function') draw(); }
  if (page === 'timetable') renderPlanner();
}

async function loadPlanner() {
  const data = await api('/api/planner?semester=' + encodeURIComponent(planner.semester));
  planner.courses = data.courses;
  planner.loaded = true;
  renderPlanner();
}
async function updatePlanner(body) {
  await api('/api/planner', body);
  await loadPlanner();
}

function groupCourseSlots(slots) {
  const groups = [];
  for (const day of plannerDays) {
    const periods = slots.filter(s => s.day === day).map(s => s.period).sort((a,b) => a-b);
    let current = null;
    for (const period of periods) {
      
      if (current && current.end === period - 1) current.end = period;
      else { current = {day, start:period, end:period}; groups.push(current); }
    }
  }
  return groups;
}
function courseLocation(course) {
  const room = course.room || '';
  if (!course.building_id) return room;
  const building = (state.graph?.nodes || []).find(item => item.id === course.building_id);
  const rawRoom = room.startsWith(course.building_id) ? room.slice(course.building_id.length) : room;
  const roomNumber = rawRoom.replace(/^0(?=[0-9A-Za-z]{3}$)/, '');
  const label = building ? `${building.name} (${course.building_id})` : course.building_id;
  return roomNumber ? `${label} · ${roomNumber}호` : label;
}
function overlappingSlots(courses) {
  const used = new Map(), problems = new Set();
  for (const course of courses) {
    for (const slot of course.slots) {
      const key = slot.day + slot.period;
      if (used.has(key) && used.get(key) !== course.id) problems.add(`${slot.day} ${slot.period}교시`);
      else used.set(key,course.id);
    }
  }
  return Array.from(problems);
}
function renderPlanner() {
  if (!planner.loaded) return;
  const otherSemester = planner.semester !== '2026-2';
  p$('plannerSearch').disabled = otherSemester;
  p$('plannerSearch').placeholder = otherSemester ? '이 학기는 직접 추가를 이용하세요' : '예: 데이터베이스, CO0604';
  p$('plannerSearchStatus').textContent = otherSemester ? '개설 강의 검색은 2026-2학기만 지원합니다.' : p$('plannerSearchStatus').textContent;
  p$('plannerSummary').textContent = `${planner.courses.length}과목 · ${planner.semester}`;
  const overlaps = overlappingSlots(planner.courses);
  p$('plannerConflict').innerHTML = overlaps.length ? `<div class="plannerWarning">수업 시간이 겹칩니다: ${pEsc(overlaps.join(', '))}</div>` : '';
  const grid = p$('plannerCalendar');
  let html = '<div class="calendarCorner">교시</div>';
  plannerDays.forEach(day => html += `<div class="calendarDay">${day}</div>`);
  for (let period = 1; period <= 16; period++) {
    html += `<div class="calendarHour" style="grid-column:1;grid-row:${period+1}">${period}<small>${period <= 10 ? String(period + 8).padStart(2,'0') + ':00' : '야간'}</small></div>`;
    for (let col=0; col<6; col++) html += `<div class="calendarCell" style="grid-column:${col+2};grid-row:${period+1}"></div>`;
  }
  planner.courses.forEach((course, index) => {
    for (const g of groupCourseSlots(course.slots)) {
      html += `<button type="button" class="calendarCourse color${index%7}" data-edit-course="${pEsc(course.id)}"
        style="grid-column:${plannerDays.indexOf(g.day)+2};grid-row:${g.start+1} / span ${g.end-g.start+1}"
        title="${pEsc(course.course_name)} — ${pEsc(course.professor)} — ${pEsc(courseLocation(course))}">
        <strong>${pEsc(course.course_name)}</strong><span>${pEsc(course.professor)}</span><small>${pEsc(courseLocation(course))}</small>
        </button>`;
    }
  });
  grid.innerHTML = html;
  grid.querySelectorAll('[data-edit-course]').forEach(button => button.onclick = () => editPlannerCourse(button.dataset.editCourse));
  const list = p$('plannerMyCourses');
  list.innerHTML = planner.courses.length ? planner.courses.map(course => `
    <div class="myCourseCard">
      <button type="button" class="myCourseEdit" data-edit-course="${pEsc(course.id)}" aria-label="${pEsc(course.course_name)} 수정">
        <strong>${pEsc(course.course_name)}</strong><span>${pEsc(course.professor)} · ${pEsc(courseLocation(course))}</span>
        <small>${course.slots.map(s=>pEsc(s.day)+s.period).join(' ') || '시간 미설정'}</small>
      </button>
      ${course.building_id && state.graph?.nodes?.some(n=>n.id===course.building_id)
        ? `<button type="button" class="myCourseMap" data-map-course="${pEsc(course.id)}">지도에서 보기</button>` : ''}
    </div>`).join('') : '<p class="plannerEmpty">아직 등록한 강의가 없습니다.<br>강의 검색 또는 직접 추가로 시작하세요.</p>';
  list.querySelectorAll('[data-edit-course]').forEach(button => button.onclick = () => editPlannerCourse(button.dataset.editCourse));
  list.querySelectorAll('[data-map-course]').forEach(button => button.onclick = () => goToCourseMap(button.dataset.mapCourse));
}

// Use the existing route finder, rather than computing a second route for timetables.
function goToCourseMap(id) {
  const course = planner.courses.find(item => item.id === id);
  if (!course || !state.graph?.nodes?.some(node => node.id === course.building_id)) return;
  closePlannerEditor();
  showScreen('map');
  p$('goalSelect').value = course.building_id;
  if (typeof setMode === 'function') setMode('map');
  if (typeof calculate === 'function') calculate();
}

function setFormError(id, message) {
  p$(id).textContent = message;
  p$(id).classList.toggle('hidden', !message);
}
function fillDayInputs(slots) {
  p$('editDayFields').querySelectorAll('[data-day]').forEach(input => {
    input.value = slots.filter(s=>s.day===input.dataset.day).map(s=>s.period).sort((a,b)=>a-b).join(',');
  });
}
function chooseBuildingOptions() {
  const select = p$('editBuilding');
  const prior = select.value;
  select.innerHTML = '<option value="">선택 안 함</option>' + (state.graph?.nodes || [])
    .slice().sort((a,b)=>a.id.localeCompare(b.id,'en',{numeric:true}))
    .map(node => `<option value="${pEsc(node.id)}">${pEsc(node.name)} (${pEsc(node.id)})</option>`).join('');
  select.value = prior;
}
function openPlannerEditor(course = null) {
  chooseBuildingOptions();
  p$('plannerCourseForm').reset();
  p$('editCourseId').value = course?.id || '';
  p$('editCourseName').value = course?.course_name || '';
  p$('editProfessor').value = course?.professor || '';
  p$('editRoom').value = course?.room || '';
  p$('editBuilding').value = course?.building_id || '';
  p$('editCourseCode').value = course?.course_code || '';
  p$('editSection').value = course?.section || '';
  fillDayInputs(course?.slots || []);
  planner.editorSource = course?.source || 'manual';
  p$('plannerEditorTitle').textContent = course?.id ? '강의 수정' : '시간표에 강의 추가';
  p$('plannerDeleteBtn').classList.toggle('hidden', !course?.id);
  p$('plannerMapBtn').classList.toggle('hidden', !course?.id || !course.building_id ||
    !state.graph?.nodes?.some(node => node.id === course.building_id));
  setFormError('plannerFormError','');
  p$('plannerEditorBackdrop').classList.remove('hidden');
  p$('editCourseName').focus();
}
function editPlannerCourse(id) {
  const course = planner.courses.find(item => item.id === id);
  if (course) openPlannerEditor(course);
}
function closePlannerEditor() { p$('plannerEditorBackdrop').classList.add('hidden'); }
function readDayInputs() {
  const slots=[];
  p$('editDayFields').querySelectorAll('[data-day]').forEach(input=>{
    const raw=input.value.trim();
    if (!raw) return;
    if (!/^\d{1,2}(\s*[,， ]\s*\d{1,2})*$/.test(raw)) throw new Error(`${input.dataset.day}요일은 1,2처럼 교시 번호만 입력하세요.`);
    for (const value of raw.split(/[,， ]+/)) {
      const period=Number(value);
      if (!Number.isInteger(period) || period < 1 || period > 16) throw new Error('교시는 1~16 사이여야 합니다.');
      if (!slots.some(s=>s.day===input.dataset.day && s.period===period)) slots.push({day:input.dataset.day,period});
    }
  });
  return slots;
}
async function savePlannerCourse(event) {
  event.preventDefault();
  try {
    const course={action:'save_course',semester:planner.semester,id:p$('editCourseId').value,
      course_name:p$('editCourseName').value.trim(),professor:p$('editProfessor').value.trim(),
      room:p$('editRoom').value.trim(),building_id:p$('editBuilding').value,
      course_code:p$('editCourseCode').value.trim(),section:p$('editSection').value.trim(),
      slots:readDayInputs(),source:planner.editorSource};
    if (!course.slots.length && !confirm('시간을 입력하지 않았습니다. 강의를 목록에만 추가할까요?')) return;
    await updatePlanner(course);closePlannerEditor();toast('시간표에 저장했습니다.');
  } catch (err) { setFormError('plannerFormError',err.message); }
}
async function deletePlannerCourse() {
  const id=p$('editCourseId').value;
  if (!id || !confirm('이 강의를 시간표에서 삭제할까요?')) return;
  try { await updatePlanner({action:'delete_course',id});closePlannerEditor();toast('강의를 삭제했습니다.'); }
  catch(err) {setFormError('plannerFormError',err.message);}
}

async function findPlannerLectures() {
  const q=p$('plannerSearch').value.trim(), request=++planner.searchRequest;
  if (!q || planner.semester !== '2026-2') { planner.searchItems=[];renderPlannerSearch();return; }
  p$('plannerSearchStatus').textContent='검색 중…';
  try {
    const result=await api('/api/lectures?q='+encodeURIComponent(q));
    if (request!==planner.searchRequest) return;
    planner.searchItems=result.courses;
    p$('plannerSearchStatus').textContent=`${result.total}개 강의 검색됨 · 최대 40개 표시`;
    renderPlannerSearch();
  } catch(err) { if(request===planner.searchRequest) p$('plannerSearchStatus').textContent=err.message; }
}
function renderPlannerSearch() {
  const list=p$('plannerSearchResults');
  if (!p$('plannerSearch').value.trim()) {
    p$('plannerSearchStatus').textContent='강의명을 입력하면 결과가 나옵니다.';
    list.innerHTML='';return;
  }
  list.innerHTML=planner.searchItems.length ? planner.searchItems.map((course,index)=>{
    return `<article class="plannerSearchCard"><div><strong>${pEsc(course.course_name)}</strong><span>${pEsc(course.section)}분반 · ${pEsc(course.professor)}</span>
      <small>${pEsc(course.schedule_raw || '시간 미기재')} · ${pEsc(course.room_raw)}</small></div>
      <button type="button" data-catalog-index="${index}">추가</button></article>`;
  }).join('') : '<p class="plannerEmpty">검색 결과가 없습니다. 직접 추가할 수 있습니다.</p>';
  list.querySelectorAll('[data-catalog-index]').forEach(button => button.onclick = () => {
    if (planner.semester !== '2026-2') return;
    const item=planner.searchItems[Number(button.dataset.catalogIndex)];
    // Periods are parsed on the server to avoid treating week-number notes as lecture hours.
    const slots=item.slots || [];
    openPlannerEditor({course_name:item.course_name,professor:item.professor || '미정',
      room:item.room_raw || '미정',building_id:item.building_id || '',
      course_code:item.course_code,section:item.section,slots,source:'catalog'});
  });
}

function initializePlanner() {
  const selector=p$('semesterPick');
  for(let year=2023;year<=2029;year++) for (let sem=1;sem<=2;sem++) {
    const value=`${year}-${sem}`,option=document.createElement('option');
    option.value=value;option.textContent=`${year}학년도 ${sem}학기`;selector.append(option);
  }
  selector.value=planner.semester;
  selector.onchange=async()=>{
    planner.semester=selector.value;
    planner.searchItems=[];
    p$('plannerSearch').value='';renderPlannerSearch();
    try {await loadPlanner();}catch(err){toast(err.message);}
  };
  p$('mainMapBtn').onclick=()=>showScreen('map');
  p$('mainTimetableBtn').onclick=()=>showScreen('timetable');
  p$('plannerManualBtn').onclick=()=>openPlannerEditor();
  p$('plannerEditorClose').onclick=p$('plannerCancelBtn').onclick=closePlannerEditor;
  p$('plannerEditorBackdrop').onclick=e=>{if(e.target===p$('plannerEditorBackdrop'))closePlannerEditor();};
  p$('plannerCourseForm').onsubmit=savePlannerCourse;
  p$('plannerDeleteBtn').onclick=deletePlannerCourse;
  p$('plannerMapBtn').onclick=()=>goToCourseMap(p$('editCourseId').value);
  p$('plannerSearch').oninput=()=>{clearTimeout(planner.searchTimer);++planner.searchRequest;
    planner.searchItems=[];renderPlannerSearch();
    planner.searchTimer=setTimeout(findPlannerLectures,180);
  };
  p$('plannerSearch').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();clearTimeout(planner.searchTimer);findPlannerLectures();}};
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closePlannerEditor();});
  loadPlanner().catch(err=>toast('시간표를 불러오지 못했습니다. '+err.message));
}
initializePlanner();

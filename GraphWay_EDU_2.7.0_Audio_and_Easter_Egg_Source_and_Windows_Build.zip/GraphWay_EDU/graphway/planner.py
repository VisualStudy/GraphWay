"""Personal timetable, stored separately from the campus graph."""
from __future__ import annotations
import json
import re
import uuid
from collections import defaultdict

DAYS = ('월', '화', '수', '목', '금', '토')
SEMESTER = re.compile(r'^20\d{2}-[12]$')


def parse_schedule(raw: str) -> list[dict]:
    """Read day/period pairs from the university timetable (e.g. 월1,2 수6)."""
    raw = str(raw or '')
    result = []
    parts = list(re.finditer('[월화수목금토]', raw))
    for index, match in enumerate(parts):
        day = match.group()
        tail = raw[match.end():parts[index + 1].start() if index + 1 < len(parts) else len(raw)]
        # Notes like (1주-5주) explain teaching weeks, not additional periods.
        tail = tail.split('(')[0].split('（')[0]
        for token in re.findall(r'(?<!\d)\d{1,2}(?!\d)', tail):
            period = int(token)
            if 1 <= period <= 16:
                slot = {'day': day, 'period': period}
                if slot not in result:
                    result.append(slot)
    return result


def check_slots(slots):
    if not isinstance(slots, list) or len(slots) > 96:
        raise ValueError('요일과 교시 목록을 확인하세요.')
    cleaned = []
    seen = set()
    for slot in slots:
        if not isinstance(slot, dict):
            raise ValueError('수업 시간 형식이 올바르지 않습니다.')
        day, period = slot.get('day'), slot.get('period')
        if day not in DAYS or type(period) is not int or not 1 <= period <= 16:
            raise ValueError('요일은 월~토, 교시는 1~16 사이로 입력하세요.')
        key = (day, period)
        if key not in seen:
            cleaned.append({'day': day, 'period': period})
            seen.add(key)
    return sorted(cleaned, key=lambda s: (DAYS.index(s['day']), s['period']))


def safe_text(data, key, required=False, limit=100):
    value = str(data.get(key, '') or '').strip()
    if len(value) > limit or (required and not value):
        raise ValueError(f'{key} 입력 내용을 확인하세요. (최대 {limit}자)')
    return value



class PlannerRepository:
    """Shares the existing graph connection. Caller holds State.lock."""
    def __init__(self, conn):
        self.conn = conn
        conn.executescript('''
            CREATE TABLE IF NOT EXISTS planner_schedule (
                id TEXT PRIMARY KEY, semester TEXT NOT NULL, course_name TEXT NOT NULL,
                professor TEXT NOT NULL, room TEXT NOT NULL, building_id TEXT NOT NULL,
                course_code TEXT NOT NULL, section TEXT NOT NULL, credits INTEGER NOT NULL,
                slots TEXT NOT NULL, source TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS ix_planner_semester ON planner_schedule(semester);
        ''')
        conn.commit()

    def get(self, semester):
        if not SEMESTER.fullmatch(str(semester)):
            raise ValueError('학기 형식은 2026-2와 같이 입력하세요.')
        columns = ('id','semester','course_name','professor','room','building_id',
                   'course_code','section','slots','source')
        rows = [dict(zip(columns, r)) for r in self.conn.execute(
            'SELECT ' + ','.join(columns) + ' FROM planner_schedule WHERE semester=? ORDER BY course_name,id',
            (semester,))]
        for row in rows:
            row['slots'] = json.loads(row['slots'])
        return {'semester': semester, 'courses': rows}

    def update(self, data):
        action = data.get('action')
        if action == 'save_course':
            semester = safe_text(data, 'semester', True, 7)
            if not SEMESTER.fullmatch(semester):
                raise ValueError('학기를 확인하세요.')
            row_id = safe_text(data, 'id', False, 40) or uuid.uuid4().hex
            old = self.conn.execute('SELECT credits FROM planner_schedule WHERE id=?', (row_id,)).fetchone()
            # Keep legacy data intact when editing a timetable saved by an older version.
            stored_credits = old[0] if old else 0
            values = (row_id, semester, safe_text(data,'course_name',True),
                      safe_text(data,'professor',True), safe_text(data,'room',True),
                      safe_text(data,'building_id',False,24),safe_text(data,'course_code',False,32),
                      safe_text(data,'section',False,20),stored_credits,
                      json.dumps(check_slots(data.get('slots',[])),ensure_ascii=False),
                      'catalog' if data.get('source')=='catalog' else 'manual')
            with self.conn:
                self.conn.execute('''INSERT INTO planner_schedule VALUES(?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(id) DO UPDATE SET semester=excluded.semester, course_name=excluded.course_name,
                    professor=excluded.professor, room=excluded.room, building_id=excluded.building_id,
                    course_code=excluded.course_code, section=excluded.section,credits=excluded.credits,
                    slots=excluded.slots,source=excluded.source''',values)
            return {'id':row_id}
        if action == 'delete_course':
            with self.conn:
                self.conn.execute('DELETE FROM planner_schedule WHERE id=?',(safe_text(data,'id',True,40),))
            return {'ok':True}
        raise ValueError('지원되지 않는 시간표 요청입니다.')

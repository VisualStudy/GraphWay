"""GraphWay HTTP service: local-only Python server with SQLite persistence."""
from __future__ import annotations
import argparse
import json
import math
import os
import re
import subprocess
import threading
import webbrowser
from dataclasses import replace
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
import unicodedata

from .algorithms import search
from .model import CampusGraph, Node, Edge
from .repository import GraphRepository
from .planner import PlannerRepository, parse_schedule
from .sample_data import build_demo_graph, PLACES

STATIC = Path(__file__).resolve().parent / 'web'
CATALOG = Path(__file__).resolve().parent / 'resources' / 'lectures_2026_2.json'
PUBLIC = {'/':'index.html','/app.js':'app.js','/map-design.js':'map-design.js','/style.css':'style.css','/planner.js':'planner.js','/planner.css':'planner.css','/sound-effects.js':'sound-effects.js','/sound-effects.css':'sound-effects.css'}
MIME = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8'}

MAX_X, MAX_Y = 1000, 760


def valid_place_id(code: str) -> bool:
    return (0 < len(code) <= 24 and code.isascii() and
            code.replace('-', '').isalnum())


def check_layout(graph: CampusGraph) -> None:
    """Apply add-place bounds to user-imported maps, before replacing saved data."""
    for node in graph.nodes.values():
        if not valid_place_id(node.id):
            raise ValueError('장소 번호에는 영문·숫자·하이픈만 사용할 수 있습니다.')
        if not 1 <= len(node.name.strip()) <= 80:
            raise ValueError('장소 이름은 1~80자로 입력하세요.')
        if not 0 <= node.x <= MAX_X or not 0 <= node.y <= MAX_Y:
            raise ValueError('지도 범위를 벗어난 장소가 있습니다: ' + node.name[:20])


def check_not_legacy(payload: dict, graph: CampusGraph) -> None:
    """Avoid silently reinterpreting legacy building IDs as current buildings.

    Detect using several unambiguous old labels, not merely one renamed place:
    users can legitimately rename a building in a current-version-1 backup.
    """
    if payload.get('version', 1) != 1:
        return
    old_labels = {'A3': '공학관', 'A18': '체육관 앞',
                  'C1': '강의동', 'E1': '중앙도서관'}
    matches = sum(1 for code, label in old_labels.items()
                  if code in graph.nodes and graph.nodes[code].name == label
                  and PLACES[code][0] != label)
    if matches >= 2:
        raise ValueError('오래된 지도는 건물 번호가 현재 지도와 다릅니다. 학교 지도를 처음 상태로 되돌리거나 새 지도 파일을 선택하세요.')


def public_message(error: Exception) -> str:
    message = str(error)
    # Only surface explicitly authored Korean user-facing messages.
    return message if re.search('[가-힣]', message) else '입력값을 확인하세요.'


def storage_path():
    setting=os.environ.get('GRAPHWAY_DATA_DIR')
    if setting: return Path(setting).expanduser()/'campus.db'
    base=Path(os.getenv('LOCALAPPDATA',str(Path.home()))) if os.name=='nt' else Path.home()/'.local'/'share'
    return base/'GraphWayEDU'/'campus.db'


class State:
    def __init__(self, path=None):
        self.lock=threading.RLock()
        self.repo=GraphRepository(path or storage_path())
        self.graph=self.repo.load()
        self.planner=PlannerRepository(self.repo.conn)
        # Read-only course timetable, independent of editable campus map data.
        self.lecture_catalog=json.loads(CATALOG.read_text(encoding='utf-8'))
        # Only upgrade an untouched first-release sample, keeping edited maps.
        legacy_file=Path(__file__).resolve().parent/'resources'/'legacy_v1.json'
        if legacy_file.is_file():
            try:
                prior=CampusGraph.from_dict(json.loads(legacy_file.read_text(encoding='utf-8')))
                if (self.graph.nodes==prior.nodes and
                    {k:e.distance for k,e in self.graph.edges.items()}==
                    {k:e.distance for k,e in prior.edges.items()}):
                    self.graph=build_demo_graph()
                    self.repo.save(self.graph)
            except (ValueError,KeyError,TypeError):
                pass

    def find_lectures(self, query):
        # Normalize whitespace and width (e.g. Ｅ３０２０６ -> E30206).
        query=unicodedata.normalize('NFKC',str(query or '')).casefold().strip()
        query=''.join(query.split())
        if len(query)>80:
            raise ValueError('검색어는 80자 이내로 입력하세요.')
        all_courses=self.lecture_catalog['courses']
        if not query:
            return {'semester':self.lecture_catalog['semester'], 'total':0,
                    'courses':[], 'source_note':self.lecture_catalog['source_note']}
        ranked=[]
        for course in all_courses:
            values=[str(course.get(key,'')) for key in
                    ('course_name','course_code','professor','room_raw','schedule_raw')]
            values=[''.join(unicodedata.normalize('NFKC',s).casefold().split()) for s in values]
            matches=[i for i,v in enumerate(values) if query in v]
            if not matches:continue
            priority=(0 if values[0]==query else 1 if values[0].startswith(query) else
                      2 if 0 in matches else 3 if 1 in matches else 4)
            ranked.append((priority,course))
        ranked.sort(key=lambda item:(item[0],item[1]['course_name'],item[1]['section'],item[1]['course_code']))
        return {'semester':self.lecture_catalog['semester'],'total':len(ranked),
                'courses':[{**item[1], 'slots':parse_schedule(item[1].get('schedule_raw',''))} for item in ranked[:40]],
                'source_note':self.lecture_catalog['source_note']}

    def do_search(self, data):
        with self.lock:
            start=str(data.get('start',''))
            goal=str(data.get('goal',''))
            algo=str(data.get('algorithm','Dijkstra'))
            r=search(self.graph,start,goal,algo)
            return {'algorithm':r.algorithm,'start':r.start,'goal':r.goal,
                    'found':r.found,'path':r.path,'distance':r.distance,
                    'visit_order':r.visit_order,
                    'steps':[{'current':s.current,'visited':s.visited,
                         'frontier':s.frontier,
                         'distances':{k:v for k,v in s.distances.items() if math.isfinite(v)},
                         'message':s.message,'kind':s.kind,'relaxed':s.relaxed,
                         'edge':s.edge,'weight':s.weight,'candidate':s.candidate,
                         'previous':s.previous,'decision':s.decision,
                         'parents':s.parents,'frontier_scores':s.frontier_scores,
                         'metric':s.metric,'heuristic':s.heuristic,'priority':s.priority} for s in r.steps]}

    def mutate(self, data):
        with self.lock:
            graph=CampusGraph.from_dict(self.graph.to_dict())
            op=data.get('action')
            if op=='add_place':
                code=str(data.get('id','')).strip().upper()
                name=str(data.get('name','')).strip()
                if not valid_place_id(code):
                    raise ValueError('장소 번호는 영문 또는 숫자 24자 이내로 입력하세요.')
                if code in graph.nodes: raise ValueError('이미 사용 중인 장소 번호입니다.')
                if len(name)>80: raise ValueError('장소 이름은 80자 이내로 입력하세요.')
                x=float(data.get('x',500));y=float(data.get('y',380))
                if not (0<=x<=MAX_X and 0<=y<=MAX_Y):raise ValueError('지도에서 장소를 놓을 위치를 확인하세요.')
                graph.add_node(Node(code,name,x,y,code[0]))
            elif op=='rename_place':
                code=str(data.get('id',''));name=str(data.get('name','')).strip()
                if code not in graph.nodes:raise ValueError('해당 장소가 없습니다.')
                if not (1<=len(name)<=80):raise ValueError('장소 이름을 1~80자로 입력하세요.')
                graph.add_node(replace(graph.nodes[code],name=name))
            elif op=='move_place':
                code=str(data.get('id',''));x=float(data.get('x'));y=float(data.get('y'))
                if code not in graph.nodes:raise ValueError('해당 장소가 없습니다.')
                if not (0<=x<=MAX_X and 0<=y<=MAX_Y):raise ValueError('지도 범위를 벗어났습니다.')
                graph.add_node(replace(graph.nodes[code],x=x,y=y))
            elif op=='delete_place':
                graph.remove_node(str(data.get('id','')))
            elif op=='connect':
                a=str(data.get('source',''));b=str(data.get('target',''))
                dist=float(data.get('distance',0))
                graph.add_edge(Edge(a,b,dist))
            elif op=='disconnect':
                graph.remove_edge(str(data.get('source','')),str(data.get('target','')))
            elif op=='reset':
                graph=build_demo_graph()
            elif op=='import':
                payload=data.get('graph')
                graph=CampusGraph.from_dict(payload)
                check_not_legacy(payload, graph)
                check_layout(graph)
            else:raise ValueError('지원되지 않는 요청입니다.')
            if not graph.nodes:
                raise ValueError('장소를 모두 삭제할 수 없습니다. 학교 지도를 처음 상태로 되돌려 주세요.')
            self.repo.save(graph)
            self.graph=graph
            return {'graph':graph.to_dict()}


def make_handler(state):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            pass

        def respond(self, payload, code=200):
            raw=json.dumps(payload,ensure_ascii=False,allow_nan=False).encode('utf-8')
            self.send_response(code)
            self.send_header('Content-Type','application/json; charset=utf-8')
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Length',str(len(raw)))
            self.end_headers();self.wfile.write(raw)

        def host_ok(self):
            # Exact host and ephemeral port: reject DNS rebinding, including on GET.
            port = self.server.server_address[1]
            host = (self.headers.get('Host') or '').lower()
            return host in (f'127.0.0.1:{port}', f'localhost:{port}')

        def origin_ok(self):
            origin = self.headers.get('Origin')
            if origin is None:
                return True
            return origin.lower() == 'http://' + (self.headers.get('Host') or '').lower()

        def do_GET(self):
            if not self.host_ok():
                self.send_error(403)
                return
            path=urlsplit(self.path).path
            if path in PUBLIC:
                target=STATIC/PUBLIC[path]
                if not target.is_file():self.send_error(404);return
                raw=target.read_bytes()
                self.send_response(200)
                self.send_header('Content-Type',MIME[target.suffix])
                self.send_header('Cache-Control','no-cache')
                self.send_header('X-Content-Type-Options','nosniff')
                self.send_header('Content-Length',str(len(raw)))
                self.end_headers();self.wfile.write(raw)
            elif path=='/api/state':
                with state.lock:
                    self.respond({'graph':state.graph.to_dict(),
                                  'start':'A19' if 'A19' in state.graph.nodes else next(iter(state.graph.nodes),''),
                                  'goal':'C1' if 'C1' in state.graph.nodes else list(state.graph.nodes)[-1] if state.graph.nodes else ''})
            elif path=='/api/lectures':
                try:
                    query=parse_qs(urlsplit(self.path).query,keep_blank_values=True).get('q',[''])[0]
                    self.respond(state.find_lectures(query))
                except (ValueError,TypeError) as err:
                    self.respond({'error':str(err)},400)
            elif path=='/api/planner':
                try:
                    semester=parse_qs(urlsplit(self.path).query).get('semester',['2026-2'])[0]
                    with state.lock: self.respond(state.planner.get(semester))
                except (ValueError,TypeError) as err:
                    self.respond({'error':public_message(err)},400)
            elif path=='/api/health':self.respond({'status':'ok'})
            elif path=='/api/export':
                with state.lock: data=state.graph.to_dict()
                payload=json.dumps(data,ensure_ascii=False,indent=2).encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type','application/octet-stream')
                self.send_header('Content-Disposition','attachment; filename="my-campus-map.graphway.json"')
                self.send_header('Content-Length',str(len(payload)))
                self.end_headers();self.wfile.write(payload)
            else:self.send_error(404)

        def do_POST(self):
            if not self.host_ok() or not self.origin_ok():
                self.respond({'error':'다른 웹사이트의 요청은 허용하지 않습니다.'},403)
                return
            path=urlsplit(self.path).path
            if path not in {'/api/search','/api/edit','/api/planner'}:self.send_error(404);return
            if (self.headers.get('Content-Type') or '').split(';')[0].strip().lower() != 'application/json':
                self.respond({'error':'요청 형식을 확인하세요.'},415)
                return
            try:
                n=int(self.headers.get('Content-Length','0'))
                if not 0<n<=2_000_000:raise ValueError('파일 크기를 확인하세요. (최대 2MB)')
                data=json.loads(self.rfile.read(n))
                if not isinstance(data,dict):raise ValueError('요청 형식을 확인하세요.')
                if path=='/api/planner':
                    with state.lock: result=state.planner.update(data)
                    self.respond(result)
                else:
                    self.respond(state.do_search(data) if path=='/api/search' else state.mutate(data))
            except json.JSONDecodeError:
                self.respond({'error':'요청 형식을 확인하세요.'},400)
            except KeyError:
                self.respond({'error':'존재하지 않는 장소·길이거나 필수 항목이 빠져 있습니다.'},400)
            except (ValueError,TypeError,OverflowError) as e:
                self.respond({'error':public_message(e)},400)
            except Exception:
                self.respond({'error':'요청을 처리하지 못했습니다. 내용을 확인하고 다시 시도하세요.'},500)
    return Handler


def create_server(port=0,path=None):
    state=State(path)
    server=ThreadingHTTPServer(('127.0.0.1',port),make_handler(state))
    server.daemon_threads=True
    return server,state


def open_app(url):
    if os.name=='nt':
        dirs=[os.environ.get('ProgramFiles(x86)',''), os.environ.get('PROGRAMFILES',''),
              os.environ.get('LOCALAPPDATA','')]
        names=[Path(p)/'Microsoft'/'Edge'/'Application'/'msedge.exe' for p in dirs if p]
        names += [Path(p)/'Google'/'Chrome'/'Application'/'chrome.exe' for p in dirs if p]
        for exe in names:
            if exe.is_file():
                subprocess.Popen([str(exe),f'--app={url}','--window-size=1540,920'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
                return
    webbrowser.open(url)


def main():
    p=argparse.ArgumentParser(description='GraphWay EDU')
    p.add_argument('--port',type=int,default=0)
    p.add_argument('--no-browser',action='store_true')
    p.add_argument('--data-dir',type=Path)
    p.add_argument('--reset',action='store_true',
                   help='시작할 때 저장된 지도를 초기화합니다. 사용자 변경 내용이 사라집니다.')
    args=p.parse_args()
    server,state=create_server(args.port,(args.data_dir/'campus.db') if args.data_dir else None)
    if args.reset:
        state.mutate({'action':'reset'})
    url=f'http://127.0.0.1:{server.server_address[1]}/'
    print(f'GraphWay EDU | {url}',flush=True)
    if not args.no_browser:threading.Timer(0.4,open_app,args=(url,)).start()
    try:server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:pass
    finally:server.server_close();state.repo.close()

if __name__=='__main__':main()

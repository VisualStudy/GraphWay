"""Core graph domain models. Coordinates are schematic (not GIS coordinates)."""
from dataclasses import dataclass, asdict
from typing import Any
import math


@dataclass(frozen=True)
class Node:
    id: str
    name: str
    x: float
    y: float
    zone: str = "A"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class Edge:
    source: str
    target: str
    distance: float

    def __post_init__(self):
        if self.source == self.target:
            raise ValueError("같은 장소끼리는 길을 연결할 수 없습니다.")
        if not math.isfinite(self.distance) or self.distance <= 0:
            raise ValueError("이동 거리 또는 비용은 0보다 큰 숫자여야 합니다.")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SearchStep:
    current: str | None
    visited: tuple[str, ...]
    frontier: tuple[str, ...]
    distances: dict[str, float]
    message: str
    kind: str = "visit"
    relaxed: tuple[str, ...] = ()
    # Edge-level explanation fields are additive; old SearchStep users still work.
    edge: tuple[str, str] | None = None
    weight: float | None = None
    candidate: float | None = None
    previous: float | None = None
    decision: str | None = None
    parents: dict[str, str] | None = None
    frontier_scores: tuple[dict[str, float | str], ...] = ()
    metric: str = 'distance'
    heuristic: float | None = None
    priority: float | None = None


@dataclass(frozen=True)
class RouteResult:
    algorithm: str
    start: str
    goal: str
    path: tuple[str, ...]
    distance: float | None
    steps: tuple[SearchStep, ...]
    visit_order: tuple[str, ...]

    @property
    def found(self) -> bool:
        return self.distance is not None


class CampusGraph:
    def __init__(self, nodes: list[Node] | None = None, edges: list[Edge] | None = None):
        self.nodes: dict[str, Node] = {}
        self.edges: dict[tuple[str, str], Edge] = {}
        # Lazily built adjacency lists. Rebuild after each topology change.
        self._adj: dict[str, list[tuple[str, float]]] | None = None
        for node in nodes or []:
            self.add_node(node)
        for edge in edges or []:
            self.add_edge(edge)

    @staticmethod
    def key(a: str, b: str) -> tuple[str, str]:
        return tuple(sorted((a, b)))

    def add_node(self, node: Node) -> None:
        if not node.id or any(ch.isspace() for ch in node.id):
            raise ValueError("장소 번호는 빈칸 없이 입력하세요.")
        if not math.isfinite(node.x) or not math.isfinite(node.y):
            raise ValueError("장소 위치를 확인해 주세요.")
        if not node.name.strip():
            raise ValueError("장소 이름은 비워둘 수 없습니다.")
        self.nodes[node.id] = node
        self._adj = None

    def add_edge(self, edge: Edge) -> None:
        if edge.source not in self.nodes or edge.target not in self.nodes:
            raise ValueError("간선 양 끝의 정점이 존재해야 합니다.")
        self.edges[self.key(edge.source, edge.target)] = edge
        self._adj = None

    def remove_node(self, node_id: str) -> None:
        if node_id not in self.nodes:
            raise KeyError(node_id)
        del self.nodes[node_id]
        for key in list(self.edges):
            if node_id in key:
                del self.edges[key]
        self._adj = None

    def remove_edge(self, a: str, b: str) -> None:
        del self.edges[self.key(a, b)]
        self._adj = None

    def neighbors(self, node_id: str) -> list[tuple[str, float]]:
        if node_id not in self.nodes:
            raise KeyError(node_id)
        if self._adj is None:
            adjacency = {node: [] for node in self.nodes}
            for (a, b), edge in self.edges.items():
                adjacency[a].append((b, edge.distance))
                adjacency[b].append((a, edge.distance))
            for items in adjacency.values():
                items.sort()
            self._adj = adjacency
        # A copy keeps callers from mutating the graph's cached lists.
        return list(self._adj[node_id])

    def path_distance(self, path: list[str] | tuple[str, ...]) -> float:
        return sum(self.edges[self.key(a, b)].distance for a, b in zip(path, path[1:]))

    def to_dict(self) -> dict[str, Any]:
        return {"format": "graphway-edu", "version": 2, "coordinate_system": "schematic", "nodes": [n.to_dict() for n in self.nodes.values()], "edges": [e.to_dict() for e in self.edges.values()]}

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> 'CampusGraph':
        if not isinstance(payload, dict) or not isinstance(payload.get('nodes'), list) or not isinstance(payload.get('edges'), list):
            raise ValueError("올바른 지도 파일이 아닙니다. GraphWay에서 저장한 파일을 선택해 주세요.")
        version = payload.get('version', 1)
        if type(version) is not int or version not in (1, 2):
            raise ValueError("지원하지 않는 지도 파일 버전입니다.")
        if payload.get('format', 'graphway-edu') != 'graphway-edu':
            raise ValueError("GraphWay에서 저장한 지도 파일을 선택해 주세요.")
        if len(payload['nodes']) > 5000 or len(payload['edges']) > 25000:
            raise ValueError("지도 파일에 장소나 길이 너무 많아 불러올 수 없습니다.")
        nodes = [Node(id=str(n['id']), name=str(n['name']), x=float(n['x']), y=float(n['y']), zone=str(n.get('zone', 'A'))) for n in payload['nodes']]
        if len({n.id for n in nodes}) != len(nodes):
            raise ValueError("중복된 정점 ID가 존재합니다.")
        edges = [Edge(source=str(e['source']), target=str(e['target']), distance=float(e['distance'])) for e in payload['edges']]
        if len({cls.key(e.source, e.target) for e in edges}) != len(edges):
            raise ValueError("중복된 간선이 존재합니다.")
        return cls(nodes, edges)

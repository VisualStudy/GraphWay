"""Explained, reproducible campus graph algorithms with edge-level decisions.

Each event describes a logical *inspection*, not a traveller walking the edge.
The terminal route is the only journey displayed as completed travel.
"""
from collections import deque
from heapq import heappush, heappop
from math import inf, hypot
from .model import CampusGraph, RouteResult, SearchStep


def _path(prev: dict[str, str], start: str, goal: str) -> tuple[str, ...]:
    if goal == start:
        return (start,)
    if goal not in prev:
        return ()
    out = [goal]
    while out[-1] != start:
        out.append(prev[out[-1]])
    return tuple(reversed(out))


def _check(graph: CampusGraph, start: str, goal: str) -> None:
    if start not in graph.nodes or goal not in graph.nodes:
        raise ValueError('출발지와 도착지는 존재하는 정점이어야 합니다.')


def _event(steps, *, current, visited, frontier, distances, parents,
           message, kind, edge=None, weight=None, candidate=None,
           previous=None, decision=None, frontier_scores=(),
           metric='distance', heuristic=None, priority=None):
    """Freeze every decision, including the edge considered and its outcome."""
    steps.append(SearchStep(
        current=current, visited=tuple(visited), frontier=tuple(frontier),
        distances=dict(distances), message=message, kind=kind,
        relaxed=(edge[1],) if edge and decision == 'update' else (),
        edge=tuple(edge) if edge else None,
        weight=weight, candidate=candidate, previous=previous,
        decision=decision, parents=dict(parents),
        frontier_scores=tuple(dict(item) for item in frontier_scores),
        metric=metric, heuristic=heuristic, priority=priority,
    ))


def _weighted_frontier(queue, visited, distances, heuristic=None):
    """Display one up-to-date entry per pending node, in real priority order."""
    out = {}
    for _, name in queue:
        if name in visited or name not in distances:
            continue
        d = distances[name]
        if d == inf:
            continue
        h = heuristic(name) if heuristic else 0.0
        out[name] = {'id': name, 'cost': d, 'heuristic': h, 'priority': d + h}
    return sorted(out.values(), key=lambda item: (item['priority'], item['id']))


def dijkstra(graph: CampusGraph, start: str, goal: str) -> RouteResult:
    _check(graph, start, goal)
    distances = {n: inf for n in graph.nodes}
    distances[start] = 0.0
    prev = {}
    queue = [(0.0, start)]
    visited = set()
    order = []
    steps = []

    def record(current, message, kind, **details):
        waiting = _weighted_frontier(queue, visited, distances)
        _event(steps, current=current, visited=order,
               frontier=[x['id'] for x in waiting], frontier_scores=waiting,
               distances=distances, parents=prev, message=message, kind=kind, **details)

    record(None, f'출발점 {start}의 거리를 0m로 놓고 후보 목록에 추가합니다.', 'init')
    while queue:
        d, u = heappop(queue)
        if u in visited or d > distances[u]:
            continue
        visited.add(u)
        order.append(u)
        record(u, f'후보 중 누적 거리가 가장 작은 {u}({d:g}m)를 확정합니다.', 'visit',
               candidate=d, decision='settle')
        if u == goal:
            break
        for v, weight in graph.neighbors(u):
            proposed = d + weight
            old = distances[v]
            if v in visited:
                record(u, f'{u} → {v}: 이미 최단 거리가 확정된 곳이므로 건너뜁니다.',
                       'reject', edge=(u, v), weight=weight, candidate=proposed,
                       previous=old, decision='visited')
                continue
            if proposed < old:
                distances[v] = proposed
                prev[v] = u
                heappush(queue, (proposed, v))
                record(u, f'{u} → {v}: {d:g} + {weight:g} = {proposed:g}m. 이전 후보보다 짧아 갱신합니다.',
                       'relax', edge=(u, v), weight=weight, candidate=proposed,
                       previous=old if old != inf else None, decision='update')
            else:
                record(u, f'{u} → {v}: {proposed:g}m는 기존 {old:g}m보다 짧지 않아 유지합니다.',
                       'reject', edge=(u, v), weight=weight, candidate=proposed,
                       previous=old, decision='no_improvement')
    path = _path(prev, start, goal) if goal in visited else ()
    total = graph.path_distance(path) if path else None
    record(goal if path else None,
           f"최단경로 확정: {' → '.join(path)} ({total:g}m)" if path else '목적지로 이어지는 경로가 없습니다.',
           'done', decision='found' if path else 'unreachable')
    return RouteResult('Dijkstra', start, goal, path, total, tuple(steps), tuple(order))


def bfs(graph: CampusGraph, start: str, goal: str) -> RouteResult:
    """BFS minimizes the number of edges, not total weighted distance."""
    _check(graph, start, goal)
    queue = deque([start])
    discovered = {start}
    prev = {}
    order = []
    hop = {start: 0}
    steps = []

    def record(current, message, kind, **details):
        pending = [{'id': node, 'cost': hop[node], 'heuristic': 0,
                    'priority': hop[node]} for node in queue]
        _event(steps, current=current, visited=order, frontier=list(queue),
               frontier_scores=pending, distances=hop, parents=prev,
               message=message, kind=kind, metric='hops', **details)

    record(None, f'큐에 출발점 {start}를 넣습니다. BFS는 간선 수가 적은 길을 찾습니다.', 'init')
    while queue:
        u = queue.popleft()
        order.append(u)
        record(u, f'큐의 맨 앞 {u}를 꺼내 주변 정점을 검사합니다. 현재 {hop[u]}개 간선을 지났습니다.',
               'visit', candidate=hop[u], decision='settle')
        if u == goal:
            break
        for v, weight in graph.neighbors(u):
            candidate = hop[u] + 1
            if v not in discovered:
                discovered.add(v)
                prev[v] = u
                hop[v] = candidate
                queue.append(v)
                record(u, f'{u} → {v}: 처음 발견한 정점입니다. {candidate}개 간선을 거쳐 도달하므로 큐 끝에 넣습니다.',
                       'relax', edge=(u, v), weight=weight, candidate=candidate,
                       previous=None, decision='update')
            else:
                record(u, f'{u} → {v}: 이미 발견한 정점이므로 큐에 다시 넣지 않습니다.',
                       'reject', edge=(u, v), weight=weight, candidate=candidate,
                       previous=hop[v], decision='visited' if v in order else 'discovered')
    path = _path(prev, start, goal) if goal in order else ()
    total = graph.path_distance(path) if path else None
    record(goal if path else None,
           f"최소 간선 수 경로: {' → '.join(path)} / 총 거리 {total:g}m" if path else '도달 가능한 경로가 없습니다.',
           'done', decision='found' if path else 'unreachable')
    return RouteResult('BFS', start, goal, path, total, tuple(steps), tuple(order))


def astar(graph: CampusGraph, start: str, goal: str) -> RouteResult:
    """A* using a conservative, consistent geometric lower bound.

    Map coordinates are schematic. k=min(w(e)/layout_length(e)) ensures
    h(n)=k*Euclidean(n,goal) never overestimates any legal graph route.
    """
    _check(graph, start, goal)
    ratios = []
    for e in graph.edges.values():
        a, b = graph.nodes[e.source], graph.nodes[e.target]
        layout_length = hypot(a.x - b.x, a.y - b.y)
        if layout_length > 0:
            ratios.append(e.distance / layout_length)
    factor = min(ratios, default=0.0)
    end = graph.nodes[goal]

    def h(node_id):
        node = graph.nodes[node_id]
        return factor * hypot(node.x-end.x, node.y-end.y)

    distances = {start: 0.0}
    prev = {}
    queue = [(h(start), start)]
    visited = set()
    order = []
    steps = []

    def record(current, message, kind, **details):
        waiting = _weighted_frontier(queue, visited, distances, h)
        _event(steps, current=current, visited=order,
               frontier=[x['id'] for x in waiting], frontier_scores=waiting,
               distances=distances, parents=prev, message=message, kind=kind, **details)

    record(None, f'A* 시작: 현재 거리 g와 목적지까지의 보수적 추정 h를 합한 f=g+h가 작은 후보를 고릅니다.', 'init',
           heuristic=h(start), priority=h(start))
    while queue:
        _, u = heappop(queue)
        if u in visited:
            continue
        visited.add(u)
        order.append(u)
        record(u, f'{u} 선택: g={distances[u]:g}m + h={h(u):.1f}m = f={distances[u]+h(u):.1f}m.',
               'visit', candidate=distances[u], heuristic=h(u),
               priority=distances[u]+h(u), decision='settle')
        if u == goal:
            break
        for v, weight in graph.neighbors(u):
            proposed = distances[u] + weight
            old = distances.get(v, inf)
            if v in visited:
                record(u, f'{u} → {v}: 이미 확정된 정점이라 다시 검사하지 않습니다.',
                       'reject', edge=(u, v), weight=weight, candidate=proposed,
                       previous=old, heuristic=h(v), priority=proposed+h(v), decision='visited')
            elif proposed < old:
                distances[v] = proposed
                prev[v] = u
                heappush(queue, (proposed+h(v), v))
                record(u, f'{u} → {v}: g={proposed:g}, h={h(v):.1f}, f={proposed+h(v):.1f}m로 갱신합니다.',
                       'relax', edge=(u, v), weight=weight, candidate=proposed,
                       previous=old if old != inf else None,
                       heuristic=h(v), priority=proposed+h(v), decision='update')
            else:
                record(u, f'{u} → {v}: 새 g={proposed:g}m는 기존 g={old:g}m보다 작지 않습니다.',
                       'reject', edge=(u, v), weight=weight, candidate=proposed,
                       previous=old, heuristic=h(v), priority=proposed+h(v), decision='no_improvement')
    path = _path(prev, start, goal) if goal in visited else ()
    total = graph.path_distance(path) if path else None
    record(goal if path else None,
           f"A* 최단경로 확정: {' → '.join(path)} ({total:g}m)" if path else '도달할 수 있는 경로가 없습니다.',
           'done', decision='found' if path else 'unreachable')
    return RouteResult('A*', start, goal, path, total, tuple(steps), tuple(order))


def search(graph: CampusGraph, start: str, goal: str, algorithm: str = 'Dijkstra') -> RouteResult:
    if algorithm == 'Dijkstra':
        return dijkstra(graph, start, goal)
    if algorithm == 'BFS':
        return bfs(graph, start, goal)
    if algorithm == 'A*':
        return astar(graph, start, goal)
    raise ValueError('알 수 없는 알고리즘: ' + algorithm)

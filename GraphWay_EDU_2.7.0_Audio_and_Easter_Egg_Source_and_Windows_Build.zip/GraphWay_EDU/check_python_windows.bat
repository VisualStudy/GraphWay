@echo off
rem Choose an installed Python 3.10+ interpreter. Do not assume that a py launcher means Python is installed.
set "GW_PY="
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
  if not errorlevel 1 set "GW_PY=py -3"
)
if not defined GW_PY (
  where python >nul 2>nul
  if not errorlevel 1 (
    python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
    if not errorlevel 1 set "GW_PY=python"
  )
)
if not defined GW_PY (
  echo [ERROR] Python 3.10 or newer is required.
  echo Install Python from https://www.python.org/downloads/
  echo During installation, select Add Python to PATH if offered.
  echo.
  echo Diagnostic information:
  where py 2>nul
  where python 2>nul
  py -3 --version 2>nul
  python --version 2>nul
  exit /b 1
)
exit /b 0

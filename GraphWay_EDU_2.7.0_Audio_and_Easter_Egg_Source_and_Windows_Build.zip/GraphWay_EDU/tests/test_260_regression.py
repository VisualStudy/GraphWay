"""Regression checks for the 2.6 timetable integration and protected map features."""
import json
import threading
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from graphway.algorithms import search
from graphway.server import State, create_server


def test_timetable_does_not_modify_shortest_path_or_graph(tmp_path):
    state=State(tmp_path/'existing.db')
    try:
        before=state.graph.to_dict()
        routes={(a,s,t):(r.path,r.distance,r.visit_order) for a in ('Dijkstra','A*','BFS') for s,t in [('A19','C1'),('A19','E4'),('E4','F1')] for r in [search(state.graph,s,t,a)]}
        state.planner.update({'action':'save_course','semester':'2026-2','course_name':'자료구조',
            'professor':'담당 교수','room':'E40207','building_id':'E4','slots':[{'day':'화','period':16}]})
        assert state.graph.to_dict()==before
        after={(a,s,t):(r.path,r.distance,r.visit_order) for a in ('Dijkstra','A*','BFS') for s,t in [('A19','C1'),('A19','E4'),('E4','F1')] for r in [search(state.graph,s,t,a)]}
        assert after==routes
        assert state.planner.get('2026-2')['courses'][0]['slots']==[{'day':'화','period':16}]
    finally:state.repo.close()


def test_schedule_persists_even_when_map_is_reset(tmp_path):
    path=tmp_path/'prior.db'
    state=State(path)
    try:
        result=state.planner.update({'action':'save_course','semester':'2026-2','course_name':'한국사',
            'professor':'교수','room':'온라인','slots':[{'day':'수','period':10}]})
        state.mutate({'action':'reset'})
        assert len(state.planner.get('2026-2')['courses'])==1
    finally:state.repo.close()
    reopened=State(path)
    try:
        assert reopened.planner.get('2026-2')['courses'][0]['id']==result['id']
    finally:reopened.repo.close()


def test_timetable_endpoint_and_existing_safety(tmp_path):
    server,state=create_server(0,tmp_path/'api.db')
    task=threading.Thread(target=server.serve_forever,daemon=True)
    task.start()
    base=f'http://127.0.0.1:{server.server_address[1]}'
    def response(path,method='GET',data=None,headers=None):
        req=Request(base+path,method=method,data=json.dumps(data).encode() if data else None,
                    headers=headers or {})
        try:
            with urlopen(req,timeout=4) as r:return r.status,r.read()
        except HTTPError as e:return e.code,e.read()
    try:
        status,raw=response('/planner.js')
        assert status==200 and b'initializePlanner' in raw
        status,raw=response('/planner.css')
        assert status==200 and b'plannerCalendar' in raw
        status,raw=response('/api/lectures?q=CO0628')
        assert status==200 and json.loads(raw)['courses'][0]['slots']==[
            {'day':'화','period':5},{'day':'화','period':6},{'day':'화','period':7}]
        payload={'action':'save_course','semester':'2026-2','course_name':'X','professor':'Y','room':'Z','slots':[]}
        status,_=response('/api/planner','POST',payload,{'Content-Type':'text/plain'})
        assert status==415
        status,_=response('/api/planner','POST',payload,{'Content-Type':'application/json','Origin':'https://untrusted.example'})
        assert status==403
        status,raw=response('/api/planner','POST',payload,{'Content-Type':'application/json'})
        assert status==200,raw
        status,raw=response('/api/planner?semester=2026-2')
        assert status==200 and len(json.loads(raw)['courses'])==1
        status,raw=response('/api/search','POST',{'start':'A19','goal':'E4','algorithm':'Dijkstra'},{'Content-Type':'application/json'})
        assert status==200 and json.loads(raw)['found']
    finally:
        server.shutdown();server.server_close();task.join(timeout=5);state.repo.close()


def test_current_map_ui_and_timetable_ui_both_present():
    root=Path(__file__).resolve().parents[1]
    html=(root/'graphway/web/index.html').read_text(encoding='utf8')
    planner=(root/'graphway/web/planner.js').read_text(encoding='utf8')
    for identifier in ['mapWorkspace','mainMapBtn','mainTimetableBtn','timetableScreen','mapSvg','officialTab',
                       'graphTab','stepSlider','playSpeed','watchBtn','plannerCalendar','plannerCourseForm','plannerSearch']:
        assert f'id="{identifier}"' in html
    assert '<script src="/map-design.js"></script>' in html
    assert '<script src="/app.js"></script>' in html
    assert '<script src="/planner.js"></script>' in html
    assert 'for (let period = 1; period <= 16; period++)' in planner

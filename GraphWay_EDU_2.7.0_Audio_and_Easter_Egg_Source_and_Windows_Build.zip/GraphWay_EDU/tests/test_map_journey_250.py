"""2.5 visual layout and adjacent-edge journey regression checks."""
from pathlib import Path

import pytest
from graphway.algorithms import search
from graphway.sample_data import build_demo_graph
from graphway.server import PUBLIC

ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.parametrize('algorithm', ('Dijkstra', 'A*', 'BFS'))
def test_every_journey_leg_is_an_existing_graph_edge(algorithm):
    graph = build_demo_graph()
    for start, goal in (('A19','E1'), ('A19','C1'), ('E4','F2'), ('C1','D4')):
        result = search(graph, start, goal, algorithm)
        assert result.found
        assert result.path[0] == start and result.path[-1] == goal
        assert all(graph.key(a, b) in graph.edges for a, b in zip(result.path, result.path[1:]))
        assert result.distance == graph.path_distance(result.path)


def test_design_module_and_official_tab_are_both_available():
    js = (ROOT / 'graphway/web/app.js').read_text(encoding='utf-8')
    design = (ROOT / 'graphway/web/map-design.js').read_text(encoding='utf-8')
    html = (ROOT / 'graphway/web/index.html').read_text(encoding='utf-8')
    assert PUBLIC['/map-design.js'] == 'map-design.js'
    assert 'src="/map-design.js"' in html
    for identifier in ('mapTab', 'graphTab', 'officialTab', 'stepSlider', 'playBtn', 'watchBtn', 'decisionLog'):
        assert f'id="{identifier}"' in html
    for behavior in ('function paintJourney(', 'function routeMotion(', 'function paintAlternatives(',
                     'function renderOfficialMap(', 'function routeToLecture(', 'function renderStep('):
        assert behavior in js
    assert 'MapDesign.paintBackground' in js and 'MapDesign.makeLabels' in js
    assert 'p.x * SCALE' in design and 'p.y * SCALE' in design  # presentation-only layout
    assert 'state.graph.nodes=' not in design
    assert 'function journeyAlternatives(' in js


def test_original_graph_data_is_not_rewritten_by_ui():
    sample = build_demo_graph().to_dict()
    assert len(sample['nodes']) == 48
    assert len(sample['edges']) > 50
    assert sample['coordinate_system'] == 'schematic'
    assert sample['nodes'][0]['id'] == 'A1'


def test_journey_is_not_the_internal_decision_cursor():
    js = (ROOT/'graphway/web/app.js').read_text(encoding='utf-8')
    assert 'state.step=routeLegCount()' in js
    assert 'state.step=Math.min(routeLegCount(),Math.max(0,Math.round(value)))' in js
    assert 'const tick=now=>' in js and 'requestAnimationFrame(tick)' in js and 'moveTraveler()' in js
    assert 'const path=r?.found ? r.path.filter' in js  # official route unaffected
    assert 'r.steps.map((s,k)' in js  # detailed trace still available on demand

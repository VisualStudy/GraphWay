"""Regression coverage for the 2.1.1/2.2.0 feature integration."""
import json
import threading
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from graphway.server import create_server

ROOT = Path(__file__).resolve().parents[1]


def test_campus_click_navigation_and_course_search_are_both_present():
    html = (ROOT / 'graphway/web/index.html').read_text(encoding='utf-8')
    js = (ROOT / 'graphway/web/app.js').read_text(encoding='utf-8')
    assert html.count('id="searchInput"') == 1
    assert html.count('id="officialOverlay"') == 1
    assert html.count('id="officialClearBtn"') == 1
    assert 'id="resultsPane"' in html and 'id="searchPane"' in html
    assert 'id="placeSearch"' not in html
    assert 'class="rightpane"' not in html
    assert 'function searchAll()' in js and 'function routeToLecture(id)' in js
    assert 'function renderOfficialMap()' in js and 'function pickOfficialPlace(id)' in js
    assert "switchPane('results')" in js


def test_lecture_readonly_api_does_not_remove_write_origin_protection(tmp_path):
    server, state = create_server(0, tmp_path / 'campus.db')
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f'http://127.0.0.1:{server.server_address[1]}'
    try:
        with urlopen(base + '/api/lectures?q=CO0628', timeout=5) as response:
            found = json.load(response)
        assert found['total'] >= 1
        assert any(c['room_raw'] == 'E40207' for c in found['courses'])
        payload = json.dumps({'start': 'A19', 'goal': 'C1', 'algorithm': 'Dijkstra'}).encode()
        denied = Request(base + '/api/search', data=payload, headers={
            'Content-Type': 'application/json', 'Origin': 'https://unrelated.example'
        })
        try:
            urlopen(denied, timeout=5)
            assert False, 'Unexpected cross-origin write allowed'
        except HTTPError as exc:
            assert exc.code == 403
        allowed = Request(base + '/api/search', data=payload, headers={
            'Content-Type': 'application/json', 'Origin': base
        })
        with urlopen(allowed, timeout=5) as response:
            result = json.load(response)
        assert result['found'] and result['path'][0] == 'A19' and result['path'][-1] == 'C1'
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
        state.repo.close()

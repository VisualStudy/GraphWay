"""Regression tests for persistent personal timetables and independent timetable page."""
from pathlib import Path
import json
import threading
from urllib.request import urlopen, Request
from urllib.error import HTTPError

import pytest
from graphway.planner import parse_schedule, check_slots
from graphway.server import create_server

ROOT = Path(__file__).resolve().parents[1]


def test_course_schedule_parse():
    assert parse_schedule('월1,2 수6') == [
        {'day':'월','period':1},{'day':'월','period':2},{'day':'수','period':6}]
    assert parse_schedule('화5,6,7') == [
        {'day':'화','period':5},{'day':'화','period':6},{'day':'화','period':7}]
    assert parse_schedule('화1,2목8 (1주-5주)') == [
        {'day':'화','period':1},{'day':'화','period':2},{'day':'목','period':8}]
    assert parse_schedule('목 야간 11,12,13')[-1] == {'day':'목','period':13}
    with pytest.raises(ValueError):check_slots([{'day':'월','period':17}])


def test_page_has_separate_navigation():
    html=(ROOT/'graphway/web/index.html').read_text(encoding='utf-8')
    assert html.index('class="globalNav"') < html.index('id="mapHeader"')
    for item in ('mainMapBtn','mainTimetableBtn','timetableScreen',
                 'plannerCalendar','plannerSearch','editCourseName','editProfessor','editRoom'):
        assert f'id="{item}"' in html
    assert 'src="/planner.js"' in html


def test_persistence_relaunch_and_origin_security(tmp_path):
    db=tmp_path/'data.db'
    server,state=create_server(0,db)
    thread=threading.Thread(target=server.serve_forever,daemon=True)
    thread.start()
    host=f'http://127.0.0.1:{server.server_address[1]}'
    def get(url):
        with urlopen(host+url) as response:return json.load(response)
    def post(payload,origin=None):
        headers={'Content-Type':'application/json'}
        if origin:headers['Origin']=origin
        request=Request(host+'/api/planner',data=json.dumps(payload).encode(),headers=headers)
        with urlopen(request) as response:return json.load(response)
    try:
        result=get('/api/lectures?q=CO0628')
        assert result['courses'][0]['slots'] == [{'day':'화','period':5},{'day':'화','period':6},{'day':'화','period':7}]
        with pytest.raises(HTTPError) as denied:
            post({'action':'save_course','semester':'2026-2','course_name':'X','professor':'P','room':'R','slots':[]},'https://evil.invalid')
        assert denied.value.code==403
        record=post({'action':'save_course','semester':'2026-2','course_name':'자료구조',
            'professor':'강의성','room':'E40207','building_id':'E4','course_code':'CO0628',
            'section':'00','credits':3,'slots':[{'day':'화','period':5}],'source':'catalog'},host)
        result=get('/api/planner?semester=2026-2')
        assert result['courses'][0]['id']==record['id']
        assert 'completed' not in result and 'profile' not in result
        assert get('/api/planner?semester=2027-1')['courses']==[]
        with pytest.raises(HTTPError) as invalid:
            post({'action':'save_course','semester':'2026-2','course_name':'X','professor':'P',
                  'room':'R','slots':[{'day':'화','period':22}]},host)
        assert invalid.value.code==400
    finally:
        server.shutdown();server.server_close();thread.join(timeout=5);state.repo.close()
    server2,state2=create_server(0,db)
    try:
        data=state2.planner.get('2026-2')
        assert data['courses'][0]['course_name']=='자료구조'
        # Resetting the campus map must not erase the timetable.
        state2.mutate({'action':'reset'})
        assert len(state2.planner.get('2026-2')['courses'])==1
        with pytest.raises(ValueError):state2.planner.update({'action':'save_completed'})
        with pytest.raises(ValueError):state2.planner.update({'action':'save_profile'})
    finally:
        server2.server_close();state2.repo.close()

"""Regression checks for locally synthesized audio and the hidden campus animation."""
from __future__ import annotations

import http.client
import re
import subprocess
import threading
from pathlib import Path

import pytest

from graphway.server import create_server

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / 'graphway' / 'web'


@pytest.fixture
def server(tmp_path):
    httpd, state = create_server(0, tmp_path / 'audio.db')
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    yield httpd.server_address[1]
    httpd.shutdown()
    thread.join(timeout=5)
    httpd.server_close()
    state.repo.close()


def get(port, path):
    conn = http.client.HTTPConnection('127.0.0.1', port, timeout=3)
    conn.request('GET', path)
    res = conn.getresponse()
    data = res.read()
    conn.close()
    return res.status, data


def test_new_audio_assets_served_locally(server):
    for path, start in [('/sound-effects.js', b"'use strict'"),
                        ('/sound-effects.css', b'/* Independent audio UI')]:
        status, data = get(server, path)
        assert status == 200 and data.startswith(start)


def test_audio_is_locally_synthesized_no_paid_runtime_service():
    js = (WEB / 'sound-effects.js').read_text(encoding='utf-8')
    assert 'AudioContext' in js
    assert 'createOscillator' in js
    assert 'journeyProgress(' in js and 'journeyArrive(' in js
    assert 'https://' not in js and 'fetch(' not in js
    assert 'new Audio(' not in js


def test_playback_hooks_connected_to_same_existing_route_engine():
    js = (WEB / 'app.js').read_text(encoding='utf-8')
    assert 'window.GraphWayAudio?.journeyStart()' in js
    assert 'window.GraphWayAudio?.journeyStop()' in js
    assert 'window.GraphWayAudio?.journeyProgress(state.step,state.motionProgress)' in js
    assert 'window.GraphWayAudio?.journeyArrive(state.step+1,legs)' in js


def test_easter_egg_is_visual_only_and_exactly_ten_clicks():
    js = (WEB / 'sound-effects.js').read_text(encoding='utf-8')
    page = (WEB / 'index.html').read_text(encoding='utf-8')
    assert "event.target.closest?.('#panelToggleBtn')" in js
    assert 'if (clicks === 10)' in js
    assert 'showSurprise()' in js
    assert 'campusSurprise' in page
    assert 'closeSurprise' in page
    assert "'/api/edit'" not in js and "'/api/planner'" not in js
    assert not re.search(r'localStorage\.setItem\([^)]*campus', js, re.I)


def test_sound_controls_present_on_global_navigation():
    page = (WEB / 'index.html').read_text(encoding='utf-8')
    assert 'id="soundToggle"' in page and 'id="soundVolume"' in page
    assert 'sound-effects.css' in page and 'sound-effects.js' in page
    assert page.index('id="soundToggle"') < page.index('id="mapHeader"')


def test_js_valid_in_node_if_installed():
    import shutil
    node = shutil.which('node')
    if not node:
        pytest.skip('Node.js is not installed; syntax check skipped')
    for name in ('app.js', 'sound-effects.js', 'planner.js'):
        proc = subprocess.run([node, '--check', str(WEB / name)], capture_output=True, text=True)
        assert proc.returncode == 0, f'{name}: {proc.stderr}'

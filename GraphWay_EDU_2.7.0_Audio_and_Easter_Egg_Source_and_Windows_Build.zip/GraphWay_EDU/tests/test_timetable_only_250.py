"""Version 2.5 only exposes campus navigation and a personal timetable."""
from pathlib import Path
from sqlite3 import connect

import pytest
from graphway.planner import PlannerRepository

ROOT = Path(__file__).resolve().parents[1]


def test_no_graduation_controls_or_calculators():
    html = (ROOT / 'graphway/web/index.html').read_text(encoding='utf8')
    js = (ROOT / 'graphway/web/planner.js').read_text(encoding='utf8')
    assert 'mainMapBtn' in html and 'mainTimetableBtn' in html
    assert 'mainProgressBtn' not in html and 'progressScreen' not in html
    assert 'completedEditorBackdrop' not in html and 'editCredits' not in html
    assert 'profileTarget' not in html and 'completedForm' not in html
    assert 'renderProgress' not in js and 'earnedCredits' not in js
    assert 'editCredits' not in js and 'planner.completed' not in js


def test_timetable_only_preserves_legacy_data(tmp_path):
    conn = connect(tmp_path/'test.db')
    try:
        conn.executescript('''
            CREATE TABLE planner_completed (id TEXT PRIMARY KEY,course_name TEXT,course_code TEXT,
               credits INTEGER,category TEXT,grade TEXT);
            INSERT INTO planner_completed VALUES('legacy','선형대수','X1',3,'전공필수','A+');
        ''')
        repo = PlannerRepository(conn)
        original = repo.update({'action':'save_course','semester':'2026-2',
            'course_name':'자료구조','professor':'강의성','room':'E40207',
            'credits':3, 'slots':[{'day':'화','period':5}]})
        # Existing credits from 2.4 are preserved even though no UI consumes them.
        conn.execute('UPDATE planner_schedule SET credits=3 WHERE id=?',(original['id'],))
        conn.commit()
        repo.update({'action':'save_course','semester':'2026-2','id':original['id'],
            'course_name':'자료구조 수정','professor':'강의성','room':'E40207',
            'slots':[{'day':'화','period':6}]})
        course = repo.get('2026-2')['courses'][0]
        assert course['course_name']=='자료구조 수정'
        assert course['slots']==[{'day':'화','period':6}]
        assert 'credits' not in course
        assert conn.execute('SELECT credits FROM planner_schedule').fetchone()[0]==3
        assert conn.execute('SELECT course_name FROM planner_completed').fetchone()[0]=='선형대수'
        with pytest.raises(ValueError): repo.update({'action':'save_completed'})
        with pytest.raises(ValueError): repo.update({'action':'save_profile'})
        assert 'completed' not in repo.get('2026-2')
    finally:
        conn.close()

"""UI-2.5 regression checks for simple, continuous route playback."""
from pathlib import Path
import pytest
from graphway.algorithms import search
from graphway.sample_data import build_demo_graph

ROOT = Path(__file__).resolve().parents[1]


def test_playback_advances_over_one_real_edge_at_a_time():
    js=(ROOT/'graphway/web/app.js').read_text(encoding='utf-8')
    assert 'state.motionProgress=Math.min(1,state.motionProgress+delta/duration)' in js
    assert 'function moveTraveler()' in js
    assert "const a=n(path[leg]),b=n(path[leg+1])" in js
    assert "marker.setAttribute('cx',String(x))" in js
    assert "line.setAttribute('x2',String(x))" in js
    assert 'setInterval(tick' not in js
    assert 'cancelAnimationFrame(state.play.frame)' in js


def test_graph_labels_only_appear_for_active_hover_or_focus():
    css=(ROOT/'graphway/web/style.css').read_text(encoding='utf-8')
    js=(ROOT/'graphway/web/app.js').read_text(encoding='utf-8')
    assert '.graphPoint .graphNodeLabel{display:none' in css
    assert '.graphPoint:hover .graphNodeLabel' in css
    assert '.graphPoint:focus-visible .graphNodeLabel' in css
    assert '.graphPoint.graphActive .graphNodeLabel' in css
    assert "class:'pinLabel graphNodeLabel'" in js
    assert "['A19','A15','C1','D2','E1','E4'].includes(p.id)" not in js


def test_design_is_independent_of_python_graph_and_keeps_official_tab():
    js=(ROOT/'graphway/web/app.js').read_text(encoding='utf-8')
    html=(ROOT/'graphway/web/index.html').read_text(encoding='utf-8')
    design=(ROOT/'graphway/web/map-design.js').read_text(encoding='utf-8')
    assert 'MapDesign.point(p,state.graph.nodes)' in js
    assert 'MapDesign.paintBackground' in js
    assert 'state.graph.nodes=' not in design
    assert 'campusMainRoad' in design and 'campusWalkway' in design
    assert 'officialMapPanel' in html and 'officialOverlay' in html
    assert 'decisionLog' in html and '<details class="journeyHelp">' in html


@pytest.mark.parametrize('algorithm',('Dijkstra','A*','BFS'))
def test_result_route_is_a_sequence_of_directly_connected_nodes(algorithm):
    graph=build_demo_graph()
    for start,goal in (('A19','E1'),('A19','C1'),('E4','F2')):
        r=search(graph,start,goal,algorithm)
        assert r.found
        for a,b in zip(r.path,r.path[1:]):
            assert graph.key(a,b) in graph.edges
        assert graph.path_distance(r.path)==r.distance

"""Trace validity: every highlighted edge must represent a real graph decision."""
from math import isclose
from pathlib import Path
import pytest

from graphway.algorithms import search
from graphway.model import CampusGraph, Edge, Node
from graphway.sample_data import build_demo_graph
from graphway.server import State


def tiny_graph():
    return CampusGraph(
        [Node('A', '출발', 0, 0), Node('B', '경유지', 1, 0),
         Node('C', '우회', 2, 0), Node('D', '목적지', 3, 0)],
        [Edge('A', 'B', 2), Edge('A', 'C', 9), Edge('B', 'C', 3),
         Edge('C', 'D', 2), Edge('B', 'D', 12)])


@pytest.mark.parametrize('algo', ['Dijkstra', 'A*', 'BFS'])
def test_decision_steps_inspect_actual_edges_and_freeze_tree(algo):
    graph = tiny_graph()
    result = search(graph, 'A', 'D', algo)
    assert result.found and result.steps[0].kind == 'init'
    assert result.steps[-1].kind == 'done'
    seen_reject = seen_update = False
    for step in result.steps:
        if step.edge:
            u, v = step.edge
            assert graph.key(u, v) in graph.edges
            assert step.current == u
            assert step.weight == graph.edges[graph.key(u, v)].distance
            assert step.kind in ('relax', 'reject')
            assert step.candidate is not None
            if step.kind == 'relax':
                seen_update = True
                assert step.parents[v] == u
                if step.previous is not None:
                    assert step.candidate < step.previous
            else:
                seen_reject = True
                assert step.decision in ('no_improvement', 'visited', 'discovered')
        assert len(step.frontier) == len(set(step.frontier))
        assert all(item['id'] in graph.nodes for item in step.frontier_scores)
    assert seen_update and seen_reject
    assert result.path[0] == 'A' and result.path[-1] == 'D'


def test_weighted_search_displays_g_and_a_star_f_in_priority_order():
    for algo in ('Dijkstra','A*'):
        result = search(tiny_graph(), 'A', 'D', algo)
        for step in result.steps:
            costs = [item['priority'] for item in step.frontier_scores]
            assert costs == sorted(costs)
            if algo == 'Dijkstra':
                assert all(item['heuristic'] == 0 for item in step.frontier_scores)
            else:
                assert all(isclose(item['cost'] + item['heuristic'], item['priority'])
                           for item in step.frontier_scores)


def test_bfs_records_hop_count_not_length():
    graph = CampusGraph([Node('A','A',0,0),Node('B','B',1,0),Node('C','C',2,0)],
                        [Edge('A','B',1),Edge('B','C',1),Edge('A','C',100)])
    result = search(graph,'A','C','BFS')
    assert result.path == ('A','C')
    assert result.distance == 100
    assert all(step.metric == 'hops' for step in result.steps)
    first = next(s for s in result.steps if s.edge == ('A','C'))
    assert first.candidate == 1 and first.weight == 100


def test_api_trace_includes_reasoned_decisions_without_mutating_saved_data(tmp_path):
    state = State(tmp_path/'data.db')
    before = state.graph.to_dict()
    for algo in ('Dijkstra','A*','BFS'):
        result = state.do_search({'start':'A19','goal':'C1','algorithm':algo})
        assert result['found']
        assert all(k in result['steps'][0] for k in ('edge','candidate','previous','parents','frontier_scores','metric'))
        assert any(s['kind'] == 'reject' for s in result['steps'])
        assert any(s['kind'] == 'relax' and s['edge'] for s in result['steps'])
        assert result['distance'] == state.graph.path_distance(result['path'])
    assert state.graph.to_dict() == before
    state.repo.close()


def test_ui_has_scrubber_queue_speed_and_detailed_edge_visuals():
    web = Path(__file__).resolve().parents[1]/'graphway'/'web'
    html = (web/'index.html').read_text(encoding='utf-8')
    js = (web/'app.js').read_text(encoding='utf-8')
    css = (web/'style.css').read_text(encoding='utf-8')
    for element in ('watchBtn','stepSlider','playSpeed','decisionCard','edgeFrom',
                    'edgeTo','candidateValue','previousValue','frontierList','traceMapBadge'):
        assert f'id="{element}"' in html
    for behavior in ('function edgeTraceLayer(', 'function routeMotion(',
                     'function renderOfficialMap(', 'function routeToLecture(',
                     'function renderStep(', 'function stepTo('):
        assert behavior in js
    assert 'prefers-reduced-motion' in css
    assert 'traceEdge' in css

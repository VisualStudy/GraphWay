"""Native shell lifecycle tests without a real Windows GUI."""
import json
import threading
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from urllib.request import urlopen, Request
from urllib.error import HTTPError

from graphway.server import create_server
from desktop import run_native_app


class FakeWebView:
    def __init__(self):
        self.window = None
        self.started = None
        self.server_responses = []

    def create_window(self, title, url, **kwargs):
        self.window = (title, url, kwargs)
        return object()

    def start(self, **kwargs):
        self.started = kwargs
        url = self.window[1]
        with urlopen(url + 'api/state', timeout=5) as response:
            state = json.load(response)
        assert state['graph']['nodes']
        with urlopen(url + 'api/health', timeout=5) as response:
            assert json.load(response)['status'] == 'ok'
        self.server_responses.append(state)
        # returning emulates the user closing the app window


class TestDesktop(unittest.TestCase):
    def test_native_window_serves_and_cleans_up(self):
        gui = FakeWebView()
        with TemporaryDirectory() as folder:
            def factory(port=0):
                assert port == 0
                srv, state = create_server(port=port, path=Path(folder) / 'campus.db')
                self.server = srv
                self.state = state
                return srv, state

            run_native_app(webview_module=gui, server_factory=factory)
            self.assertEqual(gui.started, {'gui': 'edgechromium', 'debug': False})
            self.assertIn('127.0.0.1', gui.window[1])
            self.assertIn('min_size', gui.window[2])
            self.assertTrue(gui.server_responses)
            self.assertTrue(self.server._BaseServer__is_shut_down.is_set())
            # Repo closed after desktop window closes
            with self.assertRaises(Exception):
                self.state.repo.conn.execute('SELECT 1')

    def test_cross_origin_write_is_rejected(self):
        with TemporaryDirectory() as folder:
            server, state = create_server(port=0, path=Path(folder) / 'campus.db')
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                port = server.server_address[1]
                url = f'http://127.0.0.1:{port}/api/edit'
                payload = json.dumps({'action': 'reset'}).encode()
                foreign = Request(url, data=payload, method='POST', headers={
                    'Origin': 'https://unrelated.example', 'Content-Type': 'application/json'})
                with self.assertRaises(HTTPError) as caught:
                    urlopen(foreign, timeout=5)
                self.assertEqual(caught.exception.code, 403)
                local = Request(url, data=payload, method='POST', headers={
                    'Origin': f'http://127.0.0.1:{port}', 'Content-Type': 'application/json'})
                with urlopen(local, timeout=5) as response:
                    self.assertIn('graph', json.load(response))
            finally:
                server.shutdown()
                thread.join(timeout=5)
                server.server_close()
                state.repo.close()

    def test_crashed_gui_also_shuts_down_backend(self):
        class CrashedWebView(FakeWebView):
            def start(self, **kwargs):
                raise RuntimeError('GUI unavailable')
        with TemporaryDirectory() as folder:
            srv, state = create_server(path=Path(folder) / 'campus.db')
            with self.assertRaisesRegex(RuntimeError, 'GUI unavailable'):
                run_native_app(webview_module=CrashedWebView(), server_factory=lambda port=0: (srv, state))
            self.assertTrue(srv._BaseServer__is_shut_down.is_set())
            with self.assertRaises(Exception):
                state.repo.conn.execute('SELECT 1')


if __name__ == '__main__':
    unittest.main()

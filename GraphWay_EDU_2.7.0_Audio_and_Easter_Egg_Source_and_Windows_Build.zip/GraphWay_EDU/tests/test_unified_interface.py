"""Keep the combined course/building search and left-only sidebar from regressing."""
from pathlib import Path

WEB = Path(__file__).resolve().parents[1] / 'graphway' / 'web'


def test_one_search_field_and_one_sidebar():
    html = (WEB / 'index.html').read_text(encoding='utf-8')
    assert html.count('id="searchInput"') == 1
    assert 'id="lectureInput"' not in html
    assert 'id="placeSearch"' not in html
    assert 'class="rightpane"' not in html
    assert 'id="searchPane"' in html
    assert 'id="resultsPane"' in html
    assert 'id="panelToggleBtn"' in html
    assert 'id="textSizeBtn"' not in html


def test_no_location_guess_labels_in_search_markup():
    html = (WEB / 'index.html').read_text(encoding='utf-8')
    js = (WEB / 'app.js').read_text(encoding='utf-8')
    assert '위치 추정' not in html + js
    assert '지도 위치 확인 필요' not in html + js
    assert '추정 건물로 길찾기' not in html + js
    assert 'building_status === \'candidate\'' in js
    assert 'function routeToLecture(id)' in js


def test_results_switch_keeps_pathfinding_ids():
    html = (WEB / 'index.html').read_text(encoding='utf-8')
    for id_ in ['startSelect', 'goalSelect', 'algoSelect', 'searchBtn',
                'mapSvg', 'resultDistance', 'stepCounter', 'playBtn',
                'nextBtn', 'prevBtn', 'compareBtn']:
        assert f'id="{id_}"' in html

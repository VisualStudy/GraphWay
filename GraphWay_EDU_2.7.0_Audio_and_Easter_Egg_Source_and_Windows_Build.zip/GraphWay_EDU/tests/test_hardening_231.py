"""Release 2.3.1: narrowly-scoped safety and compatibility regression tests."""
import copy
import http.client
import json
import threading
from pathlib import Path

import pytest

from graphway.algorithms import dijkstra
from graphway.model import CampusGraph, Edge, Node
from graphway.sample_data import build_demo_graph
from graphway.server import State, create_server

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def state(tmp_path):
    instance = State(tmp_path / 'campus.db')
    try:
        yield instance
    finally:
        instance.repo.close()


@pytest.fixture
def endpoint(tmp_path):
    server, instance = create_server(0, tmp_path / 'campus.db')
    worker = threading.Thread(target=server.serve_forever, daemon=True)
    worker.start()
    try:
        yield server.server_address[1]
    finally:
        server.shutdown()
        server.server_close()
        worker.join(timeout=5)
        instance.repo.close()


def send(port, method, path, body=None, headers=None, override_host=None):
    conn = http.client.HTTPConnection('127.0.0.1', port, timeout=5)
    if isinstance(body, str):
        body = body.encode('utf-8')
    if override_host is None:
        conn.request(method, path, body=body, headers=headers or {})
    else:
        conn.putrequest(method, path, skip_host=True)
        conn.putheader('Host', override_host)
        for k, v in (headers or {}).items():
            conn.putheader(k, v)
        if body is not None:
            conn.putheader('Content-Length', str(len(body)))
        conn.endheaders(body)
    response = conn.getresponse()
    status, data = response.status, response.read()
    conn.close()
    return status, data


def test_import_rejects_bad_places_without_overwriting_saved_map(state):
    original = state.graph.to_dict()
    changes = (
        lambda data: data['nodes'][0].update(x=1001),
        lambda data: data['nodes'][0].update(y=-1),
        lambda data: data['nodes'][0].update(name='가' * 81),
        lambda data: data['nodes'][0].update(id='한글'),
        lambda data: data['nodes'][0].update(id='NOT_OK'),
    )
    for change in changes:
        altered = copy.deepcopy(original)
        change(altered)
        with pytest.raises(ValueError):
            state.mutate({'action': 'import', 'graph': altered})
        assert state.graph.to_dict() == original
        saved = state.repo.load()
        assert saved.nodes == state.graph.nodes
        assert {key: edge.distance for key, edge in saved.edges.items()} == {
            key: edge.distance for key, edge in state.graph.edges.items()}


def test_add_place_id_rejects_non_ascii(state):
    for code in ('한글', '①', '❶', 'A_1'):
        with pytest.raises(ValueError):
            state.mutate({'action':'add_place','id':code,'name':'새 건물'})


def test_cannot_delete_last_node_or_import_empty_graph(state):
    single = CampusGraph([Node('X1','단일 정점',500,300)], []).to_dict()
    state.mutate({'action':'import', 'graph':single})
    with pytest.raises(ValueError, match='모두 삭제'):
        state.mutate({'action':'delete_place', 'id':'X1'})
    assert set(state.repo.load().nodes) == {'X1'}
    with pytest.raises(ValueError, match='모두 삭제'):
        state.mutate({'action':'import','graph':CampusGraph().to_dict()})
    assert set(state.repo.load().nodes) == {'X1'}


def test_version_two_backup_and_old_version_one_backups(state):
    current = state.graph.to_dict()
    assert current['version'] == 2
    compatible = copy.deepcopy(current)
    compatible['version'] = 1
    # Renaming one building in the user's legitimate old backup is allowed.
    next(n for n in compatible['nodes'] if n['id'] == 'A3')['name'] = '개인적으로 지정한 이름'
    state.mutate({'action':'import','graph':compatible})
    assert state.graph.nodes['A3'].name == '개인적으로 지정한 이름'
    legacy = json.loads((ROOT/'graphway/resources/legacy_v1.json').read_text(encoding='utf-8'))
    with pytest.raises(ValueError, match='건물 번호'):
        state.mutate({'action':'import','graph':legacy})
    with pytest.raises(ValueError, match='버전'):
        state.mutate({'action':'import','graph':{**current,'version':99}})
    assert state.graph.nodes['A3'].name == '개인적으로 지정한 이름'


def test_example_backup_matches_sample_graph():
    example = json.loads((ROOT/'examples/campus_example.graphway.json').read_text(encoding='utf-8'))
    assert example['version'] == 2
    decoded = CampusGraph.from_dict(example)
    sample = build_demo_graph()
    assert decoded.nodes == sample.nodes and decoded.edges == sample.edges


def test_origin_host_and_content_type_checks(endpoint):
    port = endpoint
    payload = json.dumps({'action':'reset'})
    good_headers = {'Content-Type':'application/json'}
    status, _ = send(port, 'GET', '/api/health')
    assert status == 200
    status, _ = send(port,'GET','/api/export',override_host='attacker.example')
    assert status == 403
    status, _ = send(port,'GET','/api/export',override_host=f'127.0.0.1:{port+1}')
    assert status == 403
    status, _ = send(port,'POST','/api/edit',payload,headers={'Content-Type':'text/plain'})
    assert status == 415
    status, _ = send(port,'POST','/api/edit',payload,headers=good_headers | {'Origin':'https://bad.example'})
    assert status == 403
    status, _ = send(port,'POST','/api/edit',payload,headers=good_headers | {'Origin':f'http://127.0.0.1:{port}'})
    assert status == 200
    status, _ = send(port,'POST','/api/search',json.dumps({'start':'A19','goal':'C1'}),
                     headers=good_headers)
    assert status == 200


def test_no_raw_python_errors_leak(endpoint):
    port = endpoint
    headers = {'Content-Type':'application/json'}
    status, raw = send(port,'POST','/api/edit',json.dumps({'action':'delete_place','id':'A99'}),headers=headers)
    assert status == 400 and 'A99' not in json.loads(raw)['error']
    status, raw = send(port,'POST','/api/edit','{invalid json',headers=headers)
    assert status == 400 and 'Expecting' not in json.loads(raw)['error']
    status, raw = send(port,'POST','/api/search',json.dumps({'start':'unknown','goal':'C1'}),headers=headers)
    assert status == 400 and json.loads(raw)['error']


def test_adjacency_cache_invalidated_by_all_topology_edits():
    graph = CampusGraph([Node('A','a',0,0),Node('B','b',1,0),Node('C','c',2,0)],
                        [Edge('A','B',5)])
    assert graph.neighbors('A') == [('B',5)]
    graph.add_node(Node('D','d',3,0))
    assert graph.neighbors('D') == []
    graph.add_edge(Edge('A','D',7))
    assert graph.neighbors('A') == [('B',5),('D',7)]
    graph.add_edge(Edge('A','B',3))
    assert graph.neighbors('A') == [('B',3),('D',7)]
    graph.remove_edge('A','D')
    assert graph.neighbors('A') == [('B',3)]
    graph.remove_node('B')
    assert graph.neighbors('A') == []
    with pytest.raises(KeyError):
        graph.neighbors('B')


def test_route_behavior_and_ui_controls_unchanged():
    graph = build_demo_graph()
    assert dijkstra(graph,'A19','E1').distance == 565
    js = (ROOT/'graphway/web/app.js').read_text(encoding='utf-8')
    html = (ROOT/'graphway/web/index.html').read_text(encoding='utf-8')
    for marker in ('id="firstBtn"','id="officialOverlay"','id="searchInput"','id="resultsPane"'):
        assert marker in html
    assert "$('firstBtn').onclick" in js
    assert "if(evt.key==='F5')" not in js
    assert "pointercancel" in js and 'lostpointercapture' in js

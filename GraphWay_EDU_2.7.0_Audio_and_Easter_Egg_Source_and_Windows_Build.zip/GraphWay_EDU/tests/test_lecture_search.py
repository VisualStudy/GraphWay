"""2026-2 timetable search: integrity, privacy and existing route integration."""
import json
import threading
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import quote
from urllib.request import urlopen

import pytest

from graphway.server import create_server

CATALOG=Path(__file__).resolve().parents[1]/'graphway'/'resources'/'lectures_2026_2.json'


def test_catalog_examples_and_safety():
    catalog=json.loads(CATALOG.read_text(encoding='utf-8'))
    courses=catalog['courses']
    assert catalog['semester']=='2026-2'
    assert len(courses)>1000
    assert any(c['course_name']=='자료구조' and c['course_code']=='CO0628' and
               c['room_raw']=='E40207' and c['building_id']=='E4' for c in courses)
    assert any(c['course_code']=='CO0604' and c['room_raw']=='E30206' for c in courses)
    assert any(c['course_name']=='법과 인권' and c['section']=='02' and
               c['room_raw']=='E80B01' for c in courses)
    assert all(c['building_id'] is None for c in courses if c['room_raw']=='A18104')
    assert all(c['building_status']!='verified' for c in courses)


def test_readonly_search_api_and_search_limits(tmp_path):
    server,state=create_server(0,tmp_path/'campus.db')
    th=threading.Thread(target=server.serve_forever,daemon=True);th.start()
    url=f'http://127.0.0.1:{server.server_address[1]}'
    def search(q):return json.load(urlopen(url+'/api/lectures?q='+quote(q),timeout=5))
    try:
        result=search('자료구조')
        assert any(c['course_code']=='CO0628' for c in result['courses'])
        result=search('E30206')
        assert any(c['course_name']=='데이터베이스' and c['course_code']=='CO0604' for c in result['courses'])
        assert any(c['course_name']=='교육콘텐츠개발' for c in result['courses'])
        result=search('현창훈')
        assert any(c['course_name']=='데이터베이스' for c in result['courses'])
        result=search('법과 인권')
        assert any(c['section']=='01' for c in result['courses'])
        assert any(c['section']=='02' for c in result['courses'])
        result=search('')
        assert result['total']==0 and result['courses']==[]
        assert search('이')['total']>len(search('이')['courses'])
        assert len(search('이')['courses'])==40
        assert len(search('없는없는강의')['courses'])==0
        assert 'search' in urlopen(url+'/').read().decode() or 'GraphWay' in urlopen(url+'/').read().decode()
        with pytest.raises(HTTPError) as bad:
            search('x'*81)
        assert bad.value.code==400
        assert len(state.graph.nodes)==48
    finally:
        server.shutdown();server.server_close();th.join(timeout=5);state.repo.close()

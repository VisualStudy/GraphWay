#define AppName "GraphWay EDU"
#define AppVersion "2.7.0"
#define AppExe "GraphWay EDU.exe"
#define WebView2Id "{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"

[Setup]
AppId={{E1A2DCE1-30EC-46A7-9F8C-4B17E28EF718}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher=GraphWay EDU Contributors
DefaultDirName={localappdata}\Programs\GraphWay EDU
DefaultGroupName=GraphWay EDU
UninstallDisplayIcon={app}\{#AppExe}
OutputDir=..\release
OutputBaseFilename=GraphWay_EDU_{#AppVersion}_Setup
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
WizardStyle=modern
SetupIconFile=..\assets\GraphWay.ico
DisableProgramGroupPage=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
CloseApplications=yes
RestartApplications=no

[Languages]
Name: "korean"; MessagesFile: "compiler:Languages\Korean.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "바탕화면에 GraphWay EDU 바로가기 만들기"; Flags: checkedonce

[Files]
Source: "..\dist\GraphWay EDU\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion
Source: "..\assets\MicrosoftEdgeWebview2Setup.exe"; DestDir: "{tmp}"; Flags: deleteafterinstall

[Icons]
Name: "{autoprograms}\GraphWay EDU"; Filename: "{app}\{#AppExe}"; WorkingDir: "{app}"; IconFilename: "{app}\{#AppExe}"
Name: "{autodesktop}\GraphWay EDU"; Filename: "{app}\{#AppExe}"; WorkingDir: "{app}"; IconFilename: "{app}\{#AppExe}"; Tasks: desktopicon

[Run]
Filename: "{tmp}\MicrosoftEdgeWebview2Setup.exe"; Parameters: "/silent /install"; StatusMsg: "Microsoft WebView2 실행 환경을 확인하고 있습니다..."; Flags: waituntilterminated; Check: not IsWebView2Installed
Filename: "{app}\{#AppExe}"; Description: "GraphWay EDU 실행"; Flags: nowait postinstall skipifsilent; Check: IsWebView2Installed

[Code]
function ValidVersion(Version: String): Boolean;
begin
  Result := (Version <> '') and (Version <> '0.0.0.0');
end;

function IsWebView2Installed: Boolean;
var
  Version: String;
  Key: String;
begin
  Result := False;
  Key := 'Software\Microsoft\EdgeUpdate\Clients\{#WebView2Id}';
  if RegQueryStringValue(HKCU, Key, 'pv', Version) then
    Result := ValidVersion(Version);
  if not Result then
    if RegQueryStringValue(HKLM32, Key, 'pv', Version) then
      Result := ValidVersion(Version);
end;

procedure CurPageChanged(CurPageID: Integer);
begin
  if (CurPageID = wpFinished) and (not IsWebView2Installed) then
    MsgBox('GraphWay EDU 설치가 완료되었지만 Microsoft WebView2 실행 환경을 설치하지 못했습니다.' + #13#10 +
           '인터넷 연결을 확인하고 Microsoft WebView2 Runtime을 설치한 뒤 실행해 주세요.', mbInformation, MB_OK);
end;

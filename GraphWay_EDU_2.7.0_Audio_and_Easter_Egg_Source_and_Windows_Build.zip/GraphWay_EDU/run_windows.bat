@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call "%~dp0check_python_windows.bat"
if errorlevel 1 (
  pause
  exit /b 1
)
%GW_PY% launch.py
if errorlevel 1 (
  echo.
  echo [ERROR] GraphWay EDU did not start. See the message above.
  pause
  exit /b 1
)

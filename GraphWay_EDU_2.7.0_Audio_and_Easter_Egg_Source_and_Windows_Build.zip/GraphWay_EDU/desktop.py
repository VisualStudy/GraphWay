"""GraphWay desktop launcher; no command prompt remains open in frozen builds.

The backend is the same GraphWay 2.1 API, bound to a random loopback port.
The backend thread and database are torn down when the native window closes.
"""
from __future__ import annotations

import os
import sys
import threading
from pathlib import Path

from graphway.server import create_server


class WebviewUnavailable(RuntimeError):
    """Missing native desktop renderer or Python GUI dependencies."""


def show_error(message: str) -> None:
    if os.name == 'nt':
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, message, 'GraphWay EDU', 0x10)
    else:
        print(message, file=sys.stderr)


def run_native_app(webview_module=None, server_factory=create_server):
    """Run GraphWay until the native window closes; dependencies are injectable for tests."""
    if webview_module is None:
        try:
            import webview as webview_module
        except ImportError as exc:
            raise WebviewUnavailable('Windows 앱 화면 구성 요소가 설치되지 않았습니다. 프로그램을 다시 설치해 주세요.') from exc

    # No fixed TCP port: opening multiple app windows cannot collide.
    server, state = server_factory(port=0)
    backend = threading.Thread(target=server.serve_forever,
                               name='GraphWay-local-server', daemon=True)
    backend.start()
    url = f'http://127.0.0.1:{server.server_address[1]}/'
    try:
        webview_module.create_window(
            'GraphWay EDU · 캠퍼스 길찾기', url,
            width=1490, height=930, min_size=(900, 620),
            resizable=True, background_color='#f4f8f6',
            text_select=True, zoomable=True,
        )
        # Disallow legacy MSHTML fallback: it cannot render the SVG app reliably.
        # WebView2 requires a runtime normally provided on modern Windows.
        webview_module.start(gui='edgechromium', debug=False)
    finally:
        server.shutdown()
        backend.join(timeout=5)
        server.server_close()
        state.repo.close()


def main() -> int:
    if os.name != 'nt':
        show_error('데스크톱 실행 파일은 Windows용입니다. 다른 운영체제에서는 launch.py를 이용하세요.')
        return 1
    try:
        run_native_app()
        return 0
    except Exception as exc:
        # The release executable uses --windowed so there is no console for tracebacks.
        show_error(
            'GraphWay EDU를 시작할 수 없습니다.\n\n'
            f'{exc}\n\n'
            'Microsoft Edge WebView2 Runtime 설치 상태를 확인하거나 앱을 다시 설치해 주세요.'
        )
        return 1


if __name__ == '__main__':
    sys.exit(main())

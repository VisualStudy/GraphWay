# GraphWay EDU 2.3.1 — 안정성 개선

GraphWay EDU 2.3.0에 사용자 제공 점검 문서(`GraphWay_fix_1-4.md`, `GraphWay_fix_runtime.md`)를 선별 반영한 유지보수 버전입니다. 2.3.0의 강의·건물 통합 검색, 공식 지도 클릭 길찾기, 알고리즘 학습 기능, Windows 네이티브 런처 및 설치 빌드 설정을 유지합니다.

## 반영

- 지도 불러오기 시 장소 번호·이름 길이·좌표 검증. 실패 시 기존 SQLite 데이터 유지
- 영문·숫자·하이픈으로 장소 코드 제한 (유니코드 코드 우회 예방)
- 예전 1.x 건물 코드/명칭 불일치 감지. 2.0.0 이후 버전 1 백업 호환 유지
- 새로 내보내는 백업 및 예시 데이터 `version: 2`로 변경
- 로컬 서버의 정확한 Host/port, Origin, POST Content-Type 검증
- 사용자에게 Python 내부 오류를 직접 노출하지 않도록 API 오류 메시지 개선
- 인접 리스트 캐시와 추가·삭제 시 캐시 무효화
- 알고리즘 학습의 '처음 단계' 버튼, 드래그 취소 상태 복구, F5 기본 동작 복원
- `pytest.ini`로 pytest 호출 방식 통일, Node.js 선택적 구문 검사
- 명시적인 전시용 `python launch.py --reset` 옵션 추가 (개인 편집 지도 초기화)
- Windows 설치 프로그램과 GitHub Actions 결과물 명칭을 2.3.1로 동기화

## 제외 또는 기존 구현 유지

- 우측 패널 flex 축소 패치: 2.3.0부터 왼쪽 정보 패널 + 지도 2열 구성으로 변경되어 대상 없음
- Python 버전 검사 교체: `check_python_windows.bat`이 이미 Python 3.10+를 실제 실행해 확인
- pip/NetworkX 설치 제거: 일반 실행용 의존성은 이미 없고 개발·빌드용 의존성만 분리됨
- 탐색 단계 거리 데이터 사본 축소: 현 캠퍼스 규모에서 이득이 작고 학습 단계 출력 안정성 우선

## 확인 범위

- Python/HTTP API 등 자동 테스트: 32개 통과 (`python -m pytest -q`, `pytest -q tests/`)
- `node --check graphway/web/app.js`: 통과
- 수정 전 2.3.0 vs 수정 후: 6개 출발·도착 쌍 × Dijkstra/BFS/A* = 총 18건의 탐색 경로·거리·방문 순서·단계 메시지 동일
- Python 컴파일 검사: 통과
- **미확인:** Windows WebView2 실기기 화면, Windows 설치 프로그램 실제 빌드
- **미확인:** Chromium 실제 UI 클릭 테스트 (검증 환경이 로컬 브라우저 접근을 제한함)

## 기존 사용자 데이터

Windows에서 사용자가 직접 편집한 지도는 `%LOCALAPPDATA%\GraphWayEDU\campus.db`에 저장되므로 소스 및 설치 폴더 교체로 삭제되지 않습니다. 1.x에서 추출한 지도 파일은 건물 번호의 의미가 달라 거부될 수 있습니다. 사용자가 저장한 데이터를 유지해야 하는 환경에서는 `--reset`을 사용하지 마세요.

## 구동

- 개발자용 브라우저 실행: `run_windows.bat` (Python 3.10+ 필요)
- 독립형 Windows GUI 설치 프로그램 생성: Windows에서 `build_windows.ps1` 실행 (Python 3.10+ x64, Inno Setup 6 필요)
- 이 ZIP에는 **Windows `.exe`가 포함되지 않으며**, Windows에서 설치 프로그램을 빌드해야 합니다.

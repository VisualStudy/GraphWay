@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call "%~dp0check_python_windows.bat"
if errorlevel 1 (
  pause
  exit /b 1
)
%GW_PY% desktop.py
if errorlevel 1 (
  echo.
  echo [ERROR] Check if pywebview is installed: py -m pip install -r requirements-desktop.txt
  pause
  exit /b 1
)

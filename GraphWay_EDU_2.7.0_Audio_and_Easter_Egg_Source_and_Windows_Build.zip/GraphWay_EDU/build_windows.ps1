# Windows 10/11 x64: builds a self-contained GUI folder and one-time installer.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
Push-Location $PSScriptRoot
try {
    # Some computers have a broken `py` launcher but a working `python`, or vice versa.
    # Try actual interpreters and check their version/architecture before creating the venv.
    $candidates = @(
        @{ Exe = 'py'; Args = @('-3.12') },
        @{ Exe = 'py'; Args = @('-3') },
        @{ Exe = 'python'; Args = @() }
    )
    $created = $false
    foreach ($candidate in $candidates) {
        if (-not (Get-Command $candidate.Exe -ErrorAction SilentlyContinue)) { continue }
        $probe = 'import sys; raise SystemExit(0 if sys.version_info >= (3,10) and sys.maxsize > 2**32 else 1)'
        $exe = $candidate.Exe
        $exeArgs = $candidate.Args
        & $exe @exeArgs -c $probe 2>$null
        if ($LASTEXITCODE -ne 0) { continue }
        & $exe @exeArgs -m venv .build-venv
        if ($LASTEXITCODE -eq 0) { $created = $true; break }
    }
    if (-not $created) { throw 'Python 3.10+ (64-bit) is required to build. Check Python installation and permissions.' }

    $venvPython = Join-Path $PSScriptRoot '.build-venv\Scripts\python.exe'
    & $venvPython -m pip install --disable-pip-version-check -r requirements-build.txt
    if ($LASTEXITCODE -ne 0) { throw 'Build packages could not be installed.' }

    & $venvPython -m PyInstaller --noconfirm --clean --onedir --windowed `
        --name 'GraphWay EDU' `
        --icon 'assets\GraphWay.ico' `
        --add-data 'graphway\web;graphway\web' `
        --add-data 'graphway\resources;graphway\resources' `
        --collect-all 'webview' `
        --hidden-import 'webview.platforms.edgechromium' `
        --hidden-import 'clr' `
        desktop.py
    if ($LASTEXITCODE -ne 0) { throw 'Could not create GraphWay EDU.exe.' }
    $exe = Join-Path $PSScriptRoot 'dist\GraphWay EDU\GraphWay EDU.exe'
    if (!(Test-Path $exe)) { throw 'Bundled executable not found.' }

    # Official, architecture-neutral online bootstrapper (requires Internet
    # only during installer build and on first installation if WebView2 is absent).
    $bootstrapper = Join-Path $PSScriptRoot 'assets\MicrosoftEdgeWebview2Setup.exe'
    if (!(Test-Path $bootstrapper)) {
        Invoke-WebRequest -Uri 'https://go.microsoft.com/fwlink/p/?LinkId=2124703' `
            -OutFile $bootstrapper -MaximumRedirection 10
    }
    if ((Get-Item $bootstrapper).Length -lt 100000) { throw 'Microsoft WebView2 bootstrapper is invalid.' }

    $isccLocations = @(
        "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
        "$env:ProgramFiles\Inno Setup 6\ISCC.exe"
    )
    $iscc = $isccLocations | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $iscc) { throw 'Inno Setup 6 is required. Install from https://jrsoftware.org/isinfo.php' }
    & $iscc 'installer\GraphWay.iss'
    if ($LASTEXITCODE -ne 0) { throw 'Inno Setup could not create the installer.' }
    Write-Host ''
    Write-Host 'Installer: release\GraphWay_EDU_2.7.0_Setup.exe'
} finally {
    Pop-Location
}
